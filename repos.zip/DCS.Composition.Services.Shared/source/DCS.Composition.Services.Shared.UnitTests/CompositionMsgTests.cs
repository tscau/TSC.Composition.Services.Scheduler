using System;
using DCS.Composition.Services.Shared.Contracts;
using Newtonsoft.Json;
using Xunit;

namespace DCS.Composition.Services.Shared.UnitTests
{
    public class CompositionMsgTests
    {
        [Fact]
        public void CompositionMsg_ToString_Success()
        {
            var message = new CompositionMsg()
            {
                BatchId = 9999,
                CampaignScheduldeMsg = new CampaignScheduldeMsg()
                {
                    BAUContacts = new string[] { "BAU Contact" },
                    CompositionStartDt = DateTime.Now,
                    CorresStatusCode = 20,
                    DeliveryChannel = 5,
                    DeliveryStartDt = DateTime.Now,
                    InputFile = "somefile",
                    NatCd = "123.123",
                    PubFile = "somepubfile",
                    RealtimeFolder = "somefolder",
                    ScheduleId = "1",
                    Stage = 1
                },
                ConsolidationMsg = new ConsolidationMsg()
                {
                    IsPdfConsolidation = false,
                    IsPsConsolidation = true,
                    PrintStream = 51,
                    StagingFolderName = "somefolder"
                },
                CorresStatusCode = 20,
                CsvFilePathName = "somefilename",
                CSVPreprocessorMsg = new CSVPreprocessorMsg()
                {
                    BAUContacts = new string[] { "contact" },
                    InputFile = "somefile",
                    NatCd = "432.432"
                },
                DeliveryChannel = 5,
                Flags = new Flags()
                {
                    AllowBdeDelivery = true,
                    AllowDatabaseRetrieve = true,
                    AllowDatabaseUpdate = true,
                    AllowEaiDelivery = true,
                    AllowMyGovDelivery = true,
                    AllowPaperDelivery = true,
                    AllowSmppDelivery = true,
                    AllowSmtpDelivery = true,
                    CorresNotInDb = true,
                    PdfConsolidationRequired = true,
                    PsConsolidationRequired = true,
                    SendPaper = true
                },
                GSScheduleId = Guid.NewGuid(),
                HandleResponse = new HandleResponse()
                {
                    Application = "app",
                    HandleStatus = "20",
                    HfJobid = "1",
                    Message = "some messge"
                },
                IsRealTime = true,
                IsStageForConsolidationJob = false,
                JGScheduleId = Guid.NewGuid(),
                JobPath = "jobpath",
                NatDins = new System.Collections.Generic.List<string>() { "543.543" },
                NumberPerSchedule = 30000,
                Operation = "",
                PubFileId = "1",
                PubFileName = "pubfilename",
                Stage = 1
            };
            var s = message.ToString();

            Assert.NotNull(s);
        }

        [Fact]
        public void CompositionMsg_does_not_initialize_flags_when_constructed()
        {
            var message = new CompositionMsg();
            Assert.Null(message.Flags);
        }

        [Fact]
        public void CompositionMsg_does_not_initialize_csv_preprocessor_msg_when_constructed()
        {
            var message = new CompositionMsg();
            Assert.Null(message.CSVPreprocessorMsg);
        }

        [Fact]
        public void CompositionMsg_can_be_deserialized()
        {
            var sampleCompositionMessage = "{\"GSScheduleId\":\"a39d7e48-0581-49a3-8d6d-6c72e09dee0a\",\"BatchId\":2558,\"NatDins\":[\"73317.375082\"],\"CorresStatusCode\":20,\"JobPath\":\"\",\"Operation\":\"\",\"NumberPerSchedule\":1,\"CSVPreprocessorMsg\":{\"InputFile\":\"\\\\\\\\fileShareDT.dcs.DevTest.atohdtnet.gov.au\\\\DE\\\\DEM\\\\Jobs\\\\Csv\\\\688205c3-3659-43a2-bd1d-a032d3274602_001.csv\",\"NatCd\":\"73317.375082\"},\"Flags\":{\"AllowBdeDelivery\":true,\"AllowDatabaseUpdate\":true,\"AllowEaiDelivery\":true,\"AllowMyGovDelivery\":true,\"AllowPaperDelivery\":true,\"AllowSmppDelivery\":true,\"AllowSmtpDelivery\":true,\"SendPaper\":true,\"CorresNotInDb\":true,\"PdfConsolidationRequired\":true,\"PsConsolidationRequired\":true}}";
            CompositionMsg message = JsonConvert.DeserializeObject<CompositionMsg>(sampleCompositionMessage);

            Assert.Equal(Guid.Parse("a39d7e48-0581-49a3-8d6d-6c72e09dee0a"), message.GSScheduleId);
            Assert.Equal(2558, message.BatchId);
            Assert.Equal(new [] { "73317.375082" }, message.NatDins);
            Assert.Equal(20, message.CorresStatusCode);
            Assert.Equal("", message.JobPath);
            Assert.Equal("", message.Operation);
            Assert.Equal(1, message.NumberPerSchedule);

            Assert.Equal(@"\\fileShareDT.dcs.DevTest.atohdtnet.gov.au\DE\DEM\Jobs\Csv\688205c3-3659-43a2-bd1d-a032d3274602_001.csv", message.CSVPreprocessorMsg.InputFile);
            Assert.Equal("73317.375082", message.CSVPreprocessorMsg.NatCd);
            Assert.Null(message.CSVPreprocessorMsg.BAUContacts);
        }
        [Fact]
        public void CompositionMsg_can_be_deserialized_with_campaignPortalMessage()
        {
            //var sampleCompositionMessage = "{\"GSScheduleId\":\"a39d7e48-0581-49a3-8d6d-6c72e09dee0a\",\"BatchId\":2558,\"NatDins\":[\"73317.375082\"],\"CorresStatusCode\":20,\"JobPath\":\"\",\"Operation\":\"\",\"NumberPerSchedule\":1,\"CSVPreprocessorMsg\":{\"InputFile\":\"\\\\\\\\fileShareDT.dcs.DevTest.atohdtnet.gov.au\\\\DE\\\\DEM\\\\Jobs\\\\Csv\\\\688205c3-3659-43a2-bd1d-a032d3274602_001.csv\",\"NatCd\":\"73317.375082\"},\"Flags\":{\"AllowBdeDelivery\":true,\"AllowDatabaseUpdate\":true,\"AllowEaiDelivery\":true,\"AllowMyGovDelivery\":true,\"AllowPaperDelivery\":true,\"AllowSmppDelivery\":true,\"AllowSmtpDelivery\":true,\"SendPaper\":true,\"CorresNotInDb\":true,\"PdfConsolidationRequired\":true,\"PsConsolidationRequired\":true}}";
            var sampleCompositionMessage = "{\"GSScheduleId\":\"2d471214-1bf8-4699-a8b7-59c2f90c9042\",\"DeliveryChannel\":105,\"BatchId\":2627,\"NatDins\":[\"75231.501626\"],\"CorresStatusCode\":32,\"Stage\":3,\"JobPath\":\"\",\"Operation\":\"\",\"NumberPerSchedule\":1,\"CSVPreprocessorMsg\":{},\"CampaignScheduldeMsg\":{\"InputFile\":\"\\\\\\\\fileShareDT.dcs.DevTest.atohdtnet.gov.au\\\\DE\\\\DEM\\\\Jobs\\\\Realtime\\\\ab16d0e2-7dd9-44e2-979d-caa0f0af868a\\\\Adv-Bulk_communication_(Email)_15.csv\",\"ScheduleId\":\"15\",\"ScheduleDate\":\"2020-10-31T19:04:23.580057+11:00\",\"RealtimeFolder\":\"\\\\\\\\fileShareDT.dcs.DevTest.atohdtnet.gov.au\\\\DE\\\\DEM\\\\Jobs\\\\Realtime\\\\ab16d0e2-7dd9-44e2-979d-caa0f0af868a\",\"NatCd\":\"75231.501626\",\"CorresStatusCode\":32,\"Stage\":3,\"DeliveryChannel\":105},\"Flags\":{\"AllowBdeDelivery\":true,\"AllowDatabaseUpdate\":true,\"AllowEaiDelivery\":true,\"AllowMyGovDelivery\":true,\"AllowPaperDelivery\":true,\"AllowSmppDelivery\":true,\"AllowSmtpDelivery\":true,\"SendPaper\":true,\"CorresNotInDb\":true,\"PdfConsolidationRequired\":true,\"PsConsolidationRequired\":true}}";

            CompositionMsg message = JsonConvert.DeserializeObject<CompositionMsg>(sampleCompositionMessage);

            Assert.Equal(Guid.Parse("2d471214-1bf8-4699-a8b7-59c2f90c9042"), message.GSScheduleId);
            Assert.Equal(2627, message.BatchId);
            Assert.Equal(new[] { "75231.501626" }, message.NatDins);
            Assert.Equal(32, message.CorresStatusCode);
            Assert.Equal("", message.JobPath);
            Assert.Equal("", message.Operation);
            Assert.Equal(1, message.NumberPerSchedule);

            Assert.Null(message.CSVPreprocessorMsg.InputFile);
            Assert.NotNull(message.CampaignScheduldeMsg);

            Assert.Equal(@"\\fileShareDT.dcs.DevTest.atohdtnet.gov.au\DE\DEM\Jobs\Realtime\ab16d0e2-7dd9-44e2-979d-caa0f0af868a\Adv-Bulk_communication_(Email)_15.csv", message.CampaignScheduldeMsg.InputFile);
            Assert.Equal("75231.501626", message.CampaignScheduldeMsg.NatCd);
            Assert.Equal(32, message.CampaignScheduldeMsg.CorresStatusCode);
        }

     
    }
}