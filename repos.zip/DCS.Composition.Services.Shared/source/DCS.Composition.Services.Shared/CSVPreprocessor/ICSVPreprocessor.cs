﻿using System.ComponentModel;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.Queues;
using Hangfire;
using Hangfire.Server;

namespace DCS.Composition.Services.Shared.CSVPreprocessor
{
    public interface ICSVPreprocessor
    {
        [Queue(CSVPreprocessorQueues.CSVPreprocessorStartQueue)]
        [JobDisplayName("CSVPreprocessor Start - {0}")]
        [DisplayName("CSVPreprocessor Start - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void Start(CompositionMsg message, PerformContext context);
    }
}