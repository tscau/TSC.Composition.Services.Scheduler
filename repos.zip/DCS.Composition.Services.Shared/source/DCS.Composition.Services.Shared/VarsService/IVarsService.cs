﻿using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.Queues;
using Hangfire;
using Hangfire.Server;
using System;
using System.ComponentModel;

namespace DCS.Composition.Services.Shared.VarsService
{
    public interface IVarsService
    {
        [Queue(VarsServiceQueues.VarsServiceReadQueue)]
        [JobDisplayName("VarsService Start - {0}")]
        [DisplayName("VarsService Start - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void Start(CompositionMsg message, PerformContext context);
    }
}
