﻿using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.Queues;
using Hangfire;
using Hangfire.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DCS.Composition.Services.Shared.JobService
{
    public interface ICommService
    {
        [Queue(JobServiceQueues.CcsServiceQueue)]
        [JobDisplayName("CommService RequestCcs - {0}")]
        [DisplayName("CommService RequestCcs - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void RequestCcs(CompositionMsg inputParams, PerformContext context);
    }
}
