﻿using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.Queues;
using Hangfire;
using Hangfire.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DCS.Composition.Services.Shared.JobService
{
    public interface IJobService
    {
        [Queue(JobServiceQueues.JobServiceQueue)]
        [JobDisplayName("JobService Start - {0}")]
        [DisplayName("JobService Start - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void Start(CompositionMsg inputParams, PerformContext context);

        [Queue(JobServiceQueues.JobServiceContinueQueue)]
        [JobDisplayName("JobService Continue - {0}")]
        [DisplayName("JobService Continue - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void ContinueEnqueue(CompositionMsg inputParams, PerformContext context);

        [Queue(JobServiceQueues.JobServiceFinalizeQueue)]
        [JobDisplayName("Finalize Continue - {0}")]
        [DisplayName("Finalize Continue - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void Finalize(CompositionMsg inputParams, PerformContext context);

        [Queue(JobServiceQueues.JobServiceHandleResponse)]
        [JobDisplayName("Job Service Handle Response - {0}")]
        [DisplayName("Job Service Handle Response - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void JobServiceHandleResponse(CompositionMsg inputParams, PerformContext context);
    }
}
