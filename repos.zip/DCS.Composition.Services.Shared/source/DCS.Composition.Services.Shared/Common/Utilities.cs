﻿using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

namespace DCS.Composition.Services.Shared.Common
{
    /// <summary>
    /// Method to hold any common methods that can be shared across all services
    /// </summary>
    public static class Utilities
    {
        /// <summary>
        /// Attempts to read all the text in the supplied file. Will retry up to the entered number of times if the file is locked.
        /// </summary>
        /// <param name="fileName">The full path to the file we are attempting to open</param>
        /// <param name="numberOfTries">Number of times to attempt to open the file</param>
        /// <param name="millisecondsBetweenTries">The milliseconds to sleepthe thread for between tries</param>
        /// <returns>The contents of the file as a string OR throws the IOException if the number of attempts exceeds the numberOfTries</returns>
        public static string TryReadAllText(string fileName, int numberOfTries, int millisecondsBetweenTries)
        {
            var tries = 0;

            while (true)
            {
                try
                {
                    return File.ReadAllText(fileName);
                }
                catch (IOException e)
                {
                    if (!IsFileLocked(e))
                    {
                        throw;
                    }
                    else if (++tries > numberOfTries)
                    {
                        throw;
                    }
                    Thread.Sleep(millisecondsBetweenTries);
                }
            }
        }

        private const uint HRFileLocked = 0x80070020;
        private const uint HRPortionOfFileLocked = 0x80070021;

        /// <summary>
        /// Checks to see if the error returned from the IOException is for a locked file 
        /// </summary>
        /// <param name="ioException"></param>
        /// <returns>True if the file is locked false otherwise</returns>
        private static bool IsFileLocked(IOException ioException)
        {
            var errorCode = (uint)Marshal.GetHRForException(ioException);
            return errorCode == HRFileLocked || errorCode == HRPortionOfFileLocked;
        }
    }
}
