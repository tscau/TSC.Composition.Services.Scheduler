﻿
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.Queues;
using Hangfire;
using Hangfire.Server;
using System.ComponentModel;

namespace DCS.Composition.Services.Shared.GlobalScheduler
{
    public interface IGlobalScheduler
    {
        [Queue(GlobalSchedulerQueues.GlobalSchedulerPutQueue)]
        [JobDisplayName("GlobalScheduler RunScheduleByDeliveryChannel - {0}")]
        [DisplayName("GlobalScheduler RunScheduleByDeliveryChannel - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void RunSchedule(CompositionMsg message, PerformContext context);

        [Queue(GlobalSchedulerQueues.GlobalSchedulerPutByNatCdQueue)]
        [JobDisplayName("GlobalScheduler RunScheduleByNatCd - {0}")]
        [DisplayName("GlobalScheduler RunScheduleByNatCd - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void RunScheduleByNatCd(CompositionMsg message, PerformContext context);


        [Queue(GlobalSchedulerQueues.GlobalSchedulerRealtimeBatchQueue)]
        [JobDisplayName("GlobalScheduler RunRealtimeBatchJob - {0}")]
        [DisplayName("GlobalScheduler RunRealtimeBatchJob - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void RunRealtimeBatchJob(RealTimeBatchJobParams message, PerformContext context);
    }
}
