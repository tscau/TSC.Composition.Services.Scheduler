﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DCS.Composition.Services.Shared.Queues
{
    public struct JobServiceQueues
    {
        public const string JobServiceQueue = "f_pp_job_service";
        public const string JobServiceContinueQueue = "c_pp_job_service_continue";
        public const string JobServiceFinalizeQueue = "b_pp_job_service_finalize";
        public const string CcsServiceQueue = "a_pp_ccs";
        public const string JobServiceHandleResponse = "s_pp_job_service_handle_resp";
        public const string JobServiceConfirmationQueue = "zzzz_pp_job_service_confirmation_queue";
    }
}
