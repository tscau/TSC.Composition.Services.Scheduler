﻿namespace DCS.Composition.Services.Shared.Queues
{
    public class VarsServiceQueues
    {
        public const string VarsServiceReadQueue = "e_vars_start_queue";
        public const string VarsServiceResponseQueue = "z_vars_sendresponse_queue";
    }
}
