﻿namespace DCS.Composition.Services.Shared.Queues
{
    public class GlobalSchedulerQueues
    {
        public const string GlobalSchedulerPutQueue = "g_gs_put_queue";
        public const string GlobalSchedulerPutByNatCdQueue = "g_gs_natcd_put_queue";
        public const string GlobalSchedulerRealtimeBatchQueue = "g_gs_realtime_batch_queue";
    }
}
