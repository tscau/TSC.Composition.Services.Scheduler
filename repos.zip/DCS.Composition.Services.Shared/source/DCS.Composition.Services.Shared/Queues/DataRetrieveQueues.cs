﻿namespace DCS.Composition.Services.Shared.Queues
{
    public class DataRetrieveQueues
    {
        public const string DataRetrieveReadQueue = "d_dr_start_queue";
    }
}
