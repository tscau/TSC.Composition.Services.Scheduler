﻿namespace DCS.Composition.Services.Shared.Queues
{
    public class CSVPreprocessorQueues
    {
        public const string CSVPreprocessorStartQueue = "zzzz_csv_start_queue";
    }
}
