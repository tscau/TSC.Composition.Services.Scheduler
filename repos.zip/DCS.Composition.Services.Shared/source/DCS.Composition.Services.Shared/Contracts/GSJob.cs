﻿using DCS.Composition.Services.Shared.Contracts;
using System;

namespace DCS.Composition.Services.GlobalScheduler.Common
{
    /// <summary>
    /// Class to hold the information for a GlobalScheduler job that is submitted to HJangfire. Used by the REST endpoint to return the results of the DoWork Operation
    /// </summary>
    public class GSJob
    {
        /// <summary>
        /// The comma seperated lsit of NatDins that form part of the message to the JobService service
        /// </summary>
        public string NatCds { get; set; }

        /// <summary>
        /// HJow many of the specified Nat/Din are being processed in this job
        /// </summary>
        public int NumberToProcess { get; set; }

        /// <summary>
        /// The message that is sent to the JobService service
        /// </summary>
        public CompositionMsg MessaageToSendToJobService { get; set; }

        /// <summary>
        /// When the Hangfire JobService schedule has been scheduled to run
        /// </summary>
        public DateTime HangfireScheduleDateTime { get; set; }
        /// <summary>
        /// The HangFire JobID that is returned on Schedule
        /// </summary>
        public string HangfireJobServiceJobId { get; set; }

        /// <summary>
        /// Returns the object as a Json string
        /// </summary>
        /// <returns></returns>
        public string ToJson()
        {

            return Newtonsoft.Json.JsonConvert.SerializeObject(this);
        }
    }
}
