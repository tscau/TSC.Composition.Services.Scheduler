﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DCS.Composition.Services.Shared.Contracts
{
    public class HandleResponse
    {
        /// <summary>
        /// Application that threw the error
        /// </summary>
        public string Application { get; set; }

        /// <summary>
        /// Hangfire response Message
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Hangfire Job id
        /// </summary>
        public string HfJobid { get; set; }

        /// <summary>
        /// Status of Failed or completed
        /// </summary>
        public string HandleStatus { get; set; }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(Application == null ? "Application = (null)" : Application);
            sb.Append("|");
            sb.Append(Message == null ? "Message = (null)" : Message);
            sb.Append("|");
            sb.Append(HandleStatus == null ? "HandleStatus = (null)" : HandleStatus);
            sb.Append("|");
            sb.Append(HfJobid == null ? "HfJobid = (null)" : HfJobid);

            return sb.ToString();
        }
    }

}
