﻿using Newtonsoft.Json;
using System;
using System.Text;

namespace DCS.Composition.Services.Shared.Contracts
{
    /// <summary>
    /// 
    /// </summary>
    public class RealTimeBatchJobParams
    {
        /// <summary>
        /// The ID of the schedule that genreated the initial Compoisiton message. Used to trace ALL subsequeuent Composition jobs that were triggered by the GlobalScheduler schedule
        /// </summary>
        public Guid GSScheduleId { get; set; }

        /// <summary>
        /// The ID of the set of jobs that are created for 1 schedule. This will allow us to group all jobs for a given high level Schedule
        /// </summary>
        public Guid JGScheduleId { get; set; }

        /// <summary>
        /// The delivery channel from the GlobalScheduler that this message applies to
        /// </summary>
        public int DeliveryChannel { get; set; }

        /// <summary>
        /// The NatDin of the correspondence to generate
        /// </summary>
        public string NatDin { get; set; }

        /// <summary>
        /// The CorresId of the correspondence to generate. This will have been placed into the OutboundDatbase by DCSRecieve or myDCS. Can also be used to generate correspondece for 1 CorresId
        /// </summary>
        public long CorresId { get; set; }

        /// <summary>
        /// The CorresStatus CODE that the correspondence was place dint othe datbaase at. Used to retrieve from the database, as well as for the VARS service to get the .ctl file for generation
        /// </summary>
        public int CorresStatusCode { get; set; }

        /// <summary>
        /// Flags for composition generation.
        /// </summary>
        public Flags Flags { get; set; }


        /// <summary>
        /// Method to display the object as a pipe delimietd string:
        /// GSScheduleID|JGServiceId|DeliveryChannel|BatchId|NatDins|CorresStatusCode|JobPath|PubFileName|PubFileId|Operation|NumberPerSchedule
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {

            StringBuilder sb = new StringBuilder();
            sb.Append("GSScheduleID = ");
            sb.Append(GSScheduleId.ToString());
            sb.Append("|");
            sb.Append(JGScheduleId);
            sb.Append("|");
            sb.Append(DeliveryChannel);
            sb.Append("|");
            sb.Append(NatDin);
            sb.Append("|");
            sb.Append(CorresId.ToString());
            sb.Append("|");
            sb.Append(CorresStatusCode.ToString());
            return sb.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string ParseCompositionMsgToJsonString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
