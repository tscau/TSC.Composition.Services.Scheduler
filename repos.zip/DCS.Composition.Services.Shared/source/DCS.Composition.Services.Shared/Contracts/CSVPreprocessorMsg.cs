﻿using System.Text;

namespace DCS.Composition.Services.Shared.Contracts
{
    public class CSVPreprocessorMsg
    {
        /// <summary>
        /// Name of the input CSV file
        /// </summary>
        public string InputFile { get; set; }

        /// <summary>
        /// List of contacts for email to BAU
        /// </summary>
        public string[] BAUContacts { get; set; }

        /// <summary>
        /// NAT DIN of the template
        /// </summary>
        public string NatCd { get; set; }

        /// <summary>
        /// Method to display the object as a pipe delimited string:
        /// InputFile|BAUContacts
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            var sb = new StringBuilder();

            sb.Append("CSVPreprocessorMsg = ");
            sb.Append(InputFile);
            sb.Append("|");
            sb.Append(NatCd);
            sb.Append("|");
            sb.Append(BAUContacts == null ? "(null)" : string.Join(",", BAUContacts));

            return sb.ToString();
        }
    }
}