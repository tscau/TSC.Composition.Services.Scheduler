﻿using Newtonsoft.Json;
using System;
using System.Text;

namespace DCS.Composition.Services.Shared.Contracts
{
    public class Flags
    {
        public bool AllowBdeDelivery { get; set; }
        public bool AllowDatabaseRetrieve { get; set; }
        public bool AllowDatabaseUpdate { get; set; }
        public bool AllowEaiDelivery { get; set; }
        public bool AllowMyGovDelivery { get; set; }
        public bool AllowPaperDelivery { get; set; }
        public bool AllowSmppDelivery { get; set; }
        public bool AllowSmtpDelivery { get; set; }
        public bool SendPaper { get; set; }
        public bool CorresNotInDb { get; set; }
        [Obsolete]
        public bool PdfConsolidationRequired { get; set; }
        [Obsolete]
        public bool PsConsolidationRequired { get; set; }

        /// <summary>
        /// Method to display the object as a pipe delimietd string:
        /// GSScheduleID|JGServiceId|DeliveryChannel|BatchId|NatDins|CorresStatusCode|JobPath|PubFileName|PubFileId|Operation|NumberPerSchedule|CSVPreprocessorMsg
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("AllowBdeDelivery = ");
            sb.Append(AllowBdeDelivery.ToString());
            sb.Append("|");
            sb.Append("AllowDatabaseRetrieve = ");
            sb.Append(AllowDatabaseRetrieve.ToString());
            sb.Append("|");
            sb.Append("AllowDatabaseUpdate = ");
            sb.Append(AllowDatabaseUpdate.ToString());
            sb.Append("|");
            sb.Append("AllowEaiDelivery = ");
            sb.Append(AllowEaiDelivery.ToString());
            sb.Append("|");
            sb.Append("AllowMyGovDelivery = ");
            sb.Append(AllowMyGovDelivery.ToString());
            sb.Append("|");
            sb.Append("AllowPaperDelivery = ");
            sb.Append(AllowPaperDelivery.ToString());
            sb.Append("|");
            sb.Append("AllowSmppDelivery = ");
            sb.Append(AllowSmppDelivery.ToString());
            sb.Append("|");
            sb.Append("AllowSmtpDelivery = ");
            sb.Append(AllowSmtpDelivery.ToString());
            sb.Append("|");
            sb.Append("SendPaper = ");
            sb.Append(SendPaper.ToString());
            sb.Append("|");
            sb.Append("CorresNotInDb = ");
            sb.Append(CorresNotInDb.ToString());
            sb.Append("|");
            sb.Append("PdfConsolidationRequired = ");
            sb.Append(PdfConsolidationRequired.ToString());
            sb.Append("|");
            sb.Append("PsConsolidationRequired = ");
            sb.Append(PsConsolidationRequired.ToString());

            return sb.ToString();
        }

        public string ParseCompositionMsgToJsonString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
