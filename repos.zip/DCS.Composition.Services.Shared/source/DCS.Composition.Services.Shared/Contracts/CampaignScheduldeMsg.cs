﻿using System;
using System.Text;

namespace DCS.Composition.Services.Shared.Contracts
{
    public class CampaignScheduldeMsg
    {
        /// <summary>
        /// Name of the input CSV file
        /// </summary>
        public string InputFile { get; set; }
        public string ScheduleId { get; set; }
        /// <summary>
        /// List of contacts for email to BAU
        /// </summary>
        public string[] BAUContacts { get; set; }
        public DateTime CompositionStartDt { get; set; }
        public DateTime DeliveryStartDt { get; set; }
        // Public Property 
        public string RealtimeFolder { get; set; }
        /// <summary>
        /// NAT DIN of the template
        /// </summary>
        public string NatCd { get; set; }
        /// <summary>
        /// The CorresStatus CODE that was used to generate the batch. Used by VARS service to determine which config entries to retrgieve from the VARSCOnfig database
        /// </summary>
        public int CorresStatusCode { get; set; }

        /// <summary>
        /// The Stage will determine if the config files are for MyDCS Realtime or for Batch Flows. The values can be 1, 2 or 3
        /// </summary>
        public int Stage { get; set; }

        /// <summary>
        /// The delivery channel from the GlobalScheduler that this message applies to
        /// </summary>
        public int DeliveryChannel { get; set; }
        public string PubFile { get; set; }
    
    /// <summary>
    /// <summary>
    /// Method to display the object as a pipe delimited string:
    /// InputFile|BAUContacts
    /// </summary>
    /// <returns></returns>
    public override string ToString()
        {
            var sb = new StringBuilder();

            sb.Append("CampaignScheduldeMsg = ");
            sb.Append(InputFile);
            sb.Append("|");
            sb.Append(ScheduleId);
            sb.Append("|");
            sb.Append(BAUContacts == null ? "(null)" : string.Join(",", BAUContacts));
            sb.Append("|");
            sb.Append(CompositionStartDt);
            sb.Append("|");
            sb.Append(DeliveryStartDt);
            sb.Append("|");
            sb.Append(RealtimeFolder);
            sb.Append("|");
            sb.Append(NatCd);
            sb.Append("|");
            sb.Append(CorresStatusCode);
            sb.Append("|");
            sb.Append(Stage);
            sb.Append("|");
            sb.Append(DeliveryChannel);
            sb.Append("|");
            sb.Append(PubFile);
            sb.Append("|");

            return sb.ToString();
        }
    }
}