﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DCS.Composition.Services.Shared.Contracts
{
    public class ConsolidationMsg
    {
        public ConsolidationMsg()
        {

        }

        /// <summary>
        /// Contains the staging folder part for a StageForConsoldiation job. e.g. 51_9.5-DoubleByte. The service that consumes this must combine with a base path to get the full path.
        /// e.g. \\filesharedt.dcs.devtest.atohdtnet.gov.au\DE\DEM\Staging\Computershare\51_9.5-DoubleByte\System
        /// </summary>
        public string StagingFolderName { get; set; }

        /// <summary>
        /// Whether this consolidation job is a PDF consolidation
        /// </summary>
        public bool IsPdfConsolidation { get; set; }

        /// <summary>
        /// Wether the consolidation job is a PS consolidation
        /// </summary>
        public bool IsPsConsolidation { get; set; }

        /// <summary>
        /// The PrintStream ID that i sbeing consolidated
        /// </summary>
        public int PrintStream { get; set; }

        /// <summary>
        /// Method to display the object as a pipe delimited string:
        /// InputFile|BAUContacts
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            var sb = new StringBuilder();

            sb.Append("ConsolidationMsg = ");
            sb.Append(StagingFolderName);
            sb.Append("|");
            sb.Append(IsPdfConsolidation);
            sb.Append("|");
            sb.Append(IsPsConsolidation);
            sb.Append("|");
            sb.Append(PrintStream);

            return sb.ToString();
        }

    }
}
