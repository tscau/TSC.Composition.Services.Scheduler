﻿using System.Collections.Generic;

namespace DCS.Composition.Services.GlobalScheduler.Common
{
    /// <summary>
    /// Class to hold all the responses from the DoWork method
    /// </summary>
    public class RealTimeBatchJobParamsResponse
    {
        /// <summary>
        /// List of log messages that are written to the logs/event log
        /// </summary>
        public List<string> LogMessages { get; set; }

        /// <summary>
        /// The GSJob details that was created
        /// </summary>
        public GSJob Job { get; set; }

        /// <summary>
        /// The BatchIds that was created by the application
        /// </summary>
        public long BatchId { get; set; }

        /// <summary>
        /// The number of records processed by the DoWork method
        /// </summary>
        public int NumberProcessed { get; set; }
    }
}
