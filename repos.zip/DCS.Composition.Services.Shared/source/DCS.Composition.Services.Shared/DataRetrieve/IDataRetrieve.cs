﻿using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.Queues;
using Hangfire;
using Hangfire.Server;
using System;
using System.ComponentModel;

namespace DCS.Composition.Services.Shared.DataRetrieve
{
    public interface IDataRetrieve
    {
        [Queue(DataRetrieveQueues.DataRetrieveReadQueue)]
        [JobDisplayName("DataRetrieve Start - {0}")]
        [DisplayName("DataRetrieve Start - {0}")]
        [AutomaticRetry(Attempts = 0)]
        void Start(CompositionMsg message, PerformContext context);

    }
}
