﻿using DCS.Shared.DataAccess.Outbound.Documents;
using MoreLinq;
using System.Collections.Generic;
using System.Linq;


namespace DCS.Composition.Services.Vars.Documents
{
    static class EngineConfigHelper
    {

        public static bool IsDistinct(this List<EngineConfig> Engines)
        {
            return Engines.DistinctBy(e => new
            {
                e.StatusCode,
                e.EngineName,
                e.EngineKey,
                e.MessageFileName,
                e.TrackIn,
                e.RunMode,
                e.StartDate,
                e.EndDate
            }).Count() == 1;


        }
    }
}
