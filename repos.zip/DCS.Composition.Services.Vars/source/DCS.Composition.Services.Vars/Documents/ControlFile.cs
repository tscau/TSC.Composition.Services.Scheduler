﻿using System.Collections.Generic;

namespace DCS.Composition.Services.Vars.Documents
{
    public class ControlFile
    {
        public string DateTime { get; set; }
        public long BatchId { get; set; }

        public string RealtimeId { get; set; }

        public string JobFolderPath { get; set; }

        public string StagingFilesPath { get; set; }

        public string InputFilesPath { get; set; }

        public string BatchFolderPath { get; set; }
        public string RealtimeFolderPath { get; set; }

        public string PubFilesPath { get; set; }

        public string GSScheduleID { get; set; }

        public string JSServiceId { get; set; }


        public string FileType { get; set; }

        public string ServiceName { get; set; }

        public string Environment { get; set; }

        public string EngineName { get; set; }

        public string EngineKey { get; set; }

        public string RunMode { get; set; }

        public string TrackIn { get; set; }

        public string MessageFileName { get; set; }

        public string StartDate { get; set; }
        public string EndDate { get; set; }



        public string NATCds { get; set; }

        public string PubFileName { get; set; }
        public string PubFileDesc { get; set; }
        public string StatusCode { get; set; }
        public string DiskPubFileName { get; set; }
        public string CASReference { get; set; }

        public string CASVersion { get; set; }

        public string UseAlternativeCASVersionInd { get; set; }

        public string OverriddenCASVersion { get; set; }

        public string UseDiskPubFileNameInd { get; set; }

        public string OverriddenPubFileName { get; set; }

        public string OverrideStartDate { get; set; }

        public string OverrideEndDate { get; set; }

        public string PackageToUse { get; set; }
        public string SortId { get; set; }

        public bool AllowBdeDelivery { get; set; } = true;
        public bool AllowDatabaseRetrieve { get; set; } = true;
        public bool AllowDatabaseUpdate { get; set; } = true;
        public bool AllowEaiDelivery { get; set; } = true;
        public bool AllowMyGovDelivery { get; set; } = true;
        public bool AllowPaperDelivery { get; set; } = true;
        public bool AllowSmppDelivery { get; set; } = true;
        public bool AllowSmtpDelivery { get; set; } = true;
        public bool SendPaper { get; set; } = true;
        public bool CorresNotInDb { get; set; } = true;
        public bool PdfConsolidationRequired { get; set; } = true;
        public bool PsConsolidationRequired { get; set; } = true;
        public string DeliveryChannel { get; set; }

        public string CampaignScheduleId { get; set; }
        public string ControlFileTemplateFile { get; set; }

        public string ControlFileTemplate { get; set; }

        public List<OnlyCorresConfig> CorresConfig { get; set; }

    }
}
