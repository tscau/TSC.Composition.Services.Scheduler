﻿using DCS.Shared.DataAccess.Outbound.Documents;
using MoreLinq;
using System.Collections.Generic;
using System.Linq;

namespace DCS.Composition.Services.Vars.Documents
{
    public static class CorresConfigHelper
    {
        //Checks to see if there's only one set of CorresPackages returned from database
        public static List<OnlyCorresConfig> Distinct(this List<CorresConfig> CorresConfigs)
        {
            return CorresConfigs.DistinctBy(p => new
            {
                p.TmpltSpcfcInd,
                p.FileType,
                p.ConfigType,
                p.ConfigParameter,
                p.ConfigValue
            }).Select(c => new OnlyCorresConfig()
            {
                TmpltSpcfcInd = c.TmpltSpcfcInd,
                FileType = c.FileType,
                ConfigType = c.ConfigType,
                ConfigParameter = c.ConfigParameter,
                ConfigValue = c.ConfigValue
            }
            ).ToList();


        }

    }

    public class OnlyCorresConfig
    {

        public bool? TmpltSpcfcInd { get; set; }

        public char FileType { get; set; }
        public string ConfigType { get; set; }
        public string ConfigParameter { get; set; }

        public string ConfigValue { get; set; }

    }
}
