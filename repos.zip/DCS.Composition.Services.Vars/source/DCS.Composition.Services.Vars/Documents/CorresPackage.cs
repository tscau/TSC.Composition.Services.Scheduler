﻿using DCS.Shared.DataAccess.Outbound.Documents;
using MoreLinq;
using System.Collections.Generic;
using System.Linq;


namespace DCS.Composition.Services.Vars.Documents
{

    public static class CorresPackageHelper
    {
        //Checks to see if there's only one set of CorresPackages returned from database
        public static bool IsDistinct(this List<CorresPackage> CorresPackages)
        {
            return CorresPackages.DistinctBy(p => new
            {
                p.StatusCode,
                p.PubFileName,
                p.PubFileDesc,
                p.CASReference,
                p.CASVersion,
                p.UseAlternativeCASVersionInd,
                p.UseDiskPubFileNameInd,
                p.OverriddenPubFileName,
                p.OverriddenCASVersion,
                p.OverrideStartDate,
                p.OverrideEndDate
            }).Count() == 1;


        }
    }



}
