using DCS.Composition.Services.Vars.Common;
using DCS.Logging.Shared.Infrastructure;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Https;
using Microsoft.Extensions.Hosting;
using Serilog;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Threading.Tasks;

namespace DCS.Composition.Services.Vars
{
    public class Program
    {
        public static async Task Main(string[] args)
        {


            Log.Logger = new LoggerConfiguration()
                  .ReadFrom.AppSettings()
                  .Enrich.WithMachineName()
                  .CreateLogger();

            AppLog.Info()(0, $"Loading {AppConfig.Logging.ServiceName} under user {WindowsIdentity.GetCurrent().Name} on machine {System.Environment.MachineName} from {Common.AssemblyHelpers.GetExecutingAssemblyFullName()} Version {Common.AssemblyHelpers.GetExecutingAssemblyVersion()} on machine {Environment.MachineName} as Process Id {Common.AssemblyHelpers.GetExecutingProcess()}.", new object[] { });

            try
            {
                AppLog.Info()(0, $"Starting Vars Service...", new object[] { });
                await CreateHostBuilder(args).Build().RunAsync();
                AppLog.Info()(0, $"Started Vars Service", new object[] { });
            }
            catch (Exception ex)
            {
                AppLog.Fatal()(0, $"Vars application start-up failed! {ex}", new object[] { });
                throw;
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseSerilog()
                .UseWindowsService()
                 .ConfigureLogging(logging =>
                 {
                     logging.AddSerilog();
                 })
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.ConfigureKestrel(configure =>
                    {
                        if (AppConfig.KestrelSettings.UseCertificateForSSL)
                        {
                            configure.ListenAnyIP(AppConfig.KestrelSettings.RESTAPIPort, listOptions =>
                            {

                                listOptions.UseHttps(httpsOptions =>
                                {
                                    var location = (AppConfig.KestrelSettings.CertificateLocation.ToLower()) switch
                                    {
                                        "currentuser" => StoreLocation.CurrentUser,
                                        "localmachine" => StoreLocation.LocalMachine,
                                        _ => StoreLocation.LocalMachine,
                                    };
                                    var cert = CertificateLoader.LoadFromStoreCert(AppConfig.KestrelSettings.CertificateSubject, AppConfig.KestrelSettings.CertificateStoreName, location, AppConfig.KestrelSettings.CertificateAllowInvalid);
                                    httpsOptions.ServerCertificate = cert;
                                });
                            });
                        }
                        else
                        {
                            configure.ListenAnyIP(AppConfig.KestrelSettings.RESTAPIPort);

                        }
                    });
                    webBuilder.UseStartup<Startup>();
                });

    }
}
