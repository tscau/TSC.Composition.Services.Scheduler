﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DCS.Composition.Services.Vars.Common
{
    public static class ListHelper
    {

        //https://www.techiedelight.com/join-two-lists-csharp/
        public static List<T> Join<T>(this List<T> first, List<T> second)
        {
            if (first == null)
            {
                return second;
            }
            if (second == null)
            {
                return first;
            }

            return first.Concat(second).ToList();
        }

        public static List<string> SplitToList(this string input)
        {

            return input.SplitToArray().ToList();
        }

        public static string[] SplitToArray(this string input)
        {
            var delimiters = new char[] { ',', ';', ' ', '|', '\\', '/' };

            return input.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
        }


    }
}
