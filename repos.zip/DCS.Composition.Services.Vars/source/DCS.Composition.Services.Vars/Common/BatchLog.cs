﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Serilog;
using System.Diagnostics.Contracts;

namespace DCS.Composition.Services.Vars.Common
{
    public static class BatchLog
    {
        //https://stackoverflow.com/questions/14505573/optional-parameters-together-with-an-array-of-parameters
        //https://stackoverflow.com/questions/24936586/mixing-optional-parameters-and-params-when-cant-simply-overload

        [Pure]
        public delegate void LogDelegate(string format, params object[] args);


        public static LogDelegate Fatal(this Serilog.Core.Logger Log, [CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Log.Fatal(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
                Serilog.Log.Fatal(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }

        public static LogDelegate Error(this Serilog.Core.Logger Log, [CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Log.Error(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
                Serilog.Log.Error(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }

        public static LogDelegate Warning(this Serilog.Core.Logger Log, [CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Log.Warning(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }

        public static LogDelegate Info(this Serilog.Core.Logger Log, [CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Log.Information(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }

        public static LogDelegate Debug(this Serilog.Core.Logger Log, [CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Log.Debug(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }

        public static LogDelegate Trace(this Serilog.Core.Logger Log, [CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Log.Verbose(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }



        private static object[] CombineArgs(string callerMemberName, string callerFilePath, int callerLineNumber, object[] args)
        {
            var args2 = new object[args.Length + 3];
            args.CopyTo(args2, 0);
            args2[args.Length] = callerFilePath;
            args2[args.Length + 1] = callerMemberName;
            args2[args.Length + 2] = callerLineNumber;
            return args2;
        }
    }

}
