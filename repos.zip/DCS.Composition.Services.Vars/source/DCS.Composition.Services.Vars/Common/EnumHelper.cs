﻿using System;

namespace DCS.Composition.Services.Vars.Common
{
    public static class EnumHelper
    {

        //https://stackoverflow.com/questions/908543/how-to-convert-from-system-enum-to-base-integer
        public static int ToInt(this Enum enumValue)
        {
            return Convert.ToInt32(enumValue);
        }



        // https://stackoverflow.com/questions/29482/how-can-i-cast-int-to-enum
        public static T ToEnum<T>(this string data) where T : struct
        {
            if (Enum.TryParse(data, true, out T enumVariable))
            {
                if (Enum.IsDefined(typeof(T), enumVariable))
                {
                    return enumVariable;
                }
            }

            return default;
        }

        public static T ToEnum<T>(this int data) where T : struct
        {
            return (T)Enum.ToObject(typeof(T), data);
        }

    }
}
