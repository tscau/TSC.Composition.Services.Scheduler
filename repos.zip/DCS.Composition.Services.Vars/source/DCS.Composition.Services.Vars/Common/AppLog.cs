﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Serilog;
using System.Diagnostics.Contracts;

namespace DCS.Composition.Services.Vars.Common
{
    public static class AppLog
    {
        //https://stackoverflow.com/questions/14505573/optional-parameters-together-with-an-array-of-parameters
        //https://stackoverflow.com/questions/24936586/mixing-optional-parameters-and-params-when-cant-simply-overload

        [Pure]
        public delegate void LogDelegate(string format, params object[] args);


        public static LogDelegate Fatal([CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Serilog.Log.Fatal(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }

        public static LogDelegate Error([CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Serilog.Log.Error(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }

        public static LogDelegate Warning([CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Serilog.Log.Warning(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }

        public static LogDelegate Info([CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Serilog.Log.Information(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }

        public static LogDelegate Debug([CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Serilog.Log.Debug(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }

        public static LogDelegate Trace([CallerMemberName] string callerMemberName = "", [CallerFilePath] string callerFilePath = "", [CallerLineNumber] int callerLineNumber = 0)
        {
            return new LogDelegate((format, args) =>
            {
                Serilog.Log.Verbose(format + $" [{callerFilePath:l}|{callerMemberName:l}()|Line:{callerLineNumber}]", CombineArgs(callerMemberName, callerFilePath, callerLineNumber, args));
            });
        }


        private static object[] CombineArgs(string callerMemberName, string callerFilePath, int callerLineNumber, object[] args)
        {
            var args2 = new object[args.Length + 3];
            args.CopyTo(args2, 0);
            args2[args.Length] = callerFilePath;
            args2[args.Length + 1] = callerMemberName;
            args2[args.Length + 2] = callerLineNumber;
            return args2;
        }
    }

}
