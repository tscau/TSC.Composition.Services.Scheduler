﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace DCS.Composition.Services.Vars.Common
{
    public static class StringHelper
    {

        public static bool ToBool(this string inputString)
        {
            string[] TrueWordList = { "TRUE", "YES", "Y", "1", "ENABLED", "ON" };
            string[] FalseWordList = { "FALSE", "NO", "N", "0", "DISABLED", "OFF" };

            var str = inputString.ToUpperInvariant();

            if (TrueWordList.Contains(str))
            {
                return true;
            }
            else if (FalseWordList.Contains(str))
            {
                return false;
            }
            else
            {
                throw new InvalidOperationException("String value is not a valid boolean choice. InputString:" + inputString);
            }
        }

        public static bool ToBool(this int inputInteger)
        {

            if (Convert.ToBoolean(inputInteger))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static int ToInt32(this string inputString)
        {
            if (String.IsNullOrEmpty(inputString)) return 0;
            return (int.TryParse(inputString, out int outputInteger)) ? outputInteger : 0;
        }

        public static string ToString(this bool? input)
        {
            if (input == null)
            {
                return "null";
            }
            else
            {
                return input.ToString();
            }
        }

        public static bool IsTrue(this bool? input)
        {
            if (input == null)
            {
                return false;
            }
            else if (input == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static string ToString(this int? input)
        {
            if (input == null)
            {
                return "null";
            }
            else
            {
                return input.ToString();
            }
        }

        public static string ToString(this DateTime? input, string dateFormat)
        {
            if (input == null)
            {
                return "null";
            }
            else
            {
                return input?.ToString(dateFormat);
            }
        }

        public static bool IsNullOrWhiteSpace(this string value)
        {
            return value == null || value.Trim().Length == 0;
        }


        //https://stackoverflow.com/questions/11189331/how-to-count-lines-in-a-string
        public static int CountLines(this string str)
        {
            if (str == null)
                throw new ArgumentNullException("str");
            if (str == string.Empty)
                return 0;
            int index = -1;
            int count = 0;
            while (-1 != (index = str.IndexOf(Environment.NewLine, index + 1)))
                count++;

            return count + 1;
        }

        public static string GetLast(this string source, int tail_length)
        {
            if (tail_length >= source.Length)
                return source;
            return source.Substring(source.Length - tail_length);
        }

        //https://social.msdn.microsoft.com/Forums/en-US/e0109782-9c07-48c1-a6d3-dec4cbd4fd99/convert-from-decimalbase10-to-alphanumericbase36
        public static string ToBase36(this long value)
        {
            const string base36 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var sb = new StringBuilder(13);
            do
            {
                sb.Insert(0, base36[(byte)(value % 36)]);
                value /= 36;
            } while (value != 0);
            return sb.ToString();
        }

        //https://stackoverflow.com/questions/19345988/convert-a-list-of-strings-to-a-single-string/19346006
        public static string ToString<T>(this IList<T> list)
        {
            return string.Join(",", list);
        }

        public static bool IsGenericList(this object o)
        {
            var oType = o.GetType();
            return (oType.IsGenericType && (oType.GetGenericTypeDefinition() == typeof(List<>)));
        }

        //https://stackoverflow.com/questions/852181/c-printing-all-properties-of-an-object
        public static string ToDump(this object obj, string propertyseparator = "|")
        {
            var stringDump = "";
            foreach (PropertyDescriptor descriptor in TypeDescriptor.GetProperties(obj))
            {
                string name = descriptor.Name;
                object value;
                value = descriptor.GetValue(obj);

                if (value == null)
                {
                    stringDump += propertyseparator + name + "=" + "null";
                }
                else
                {
                    if (value.IsGenericList())
                    {
                        var IListvalue = (IList<string>)descriptor.GetValue(obj);
                        value = IListvalue.ToString<string>();
                    }
                    stringDump += propertyseparator + name + "=" + value;
                }
            }
            return stringDump + propertyseparator;
        }

        public static string ToSortId(this long value)
        {
            var SortId = value.ToBase36().ToLower();
            if (SortId.Length >= 6)
            {
                return SortId.GetLast(6);
            }
            else
            {
                return SortId.PadLeft(6, '0');
            }
        }
    }
}
