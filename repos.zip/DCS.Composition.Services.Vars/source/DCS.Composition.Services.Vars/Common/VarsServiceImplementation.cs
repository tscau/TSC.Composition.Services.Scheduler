using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.VarsService;
using DCS.Composition.Services.Vars.Documents;
using DCS.Logging.Shared.Infrastructure;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Database;
using DCS.Shared.DataAccess.Outbound.Documents;
using DCS.Shared.DataAccess.Outbound.Enums;
using Hangfire.Server;
using Microsoft.Data.SqlClient;
using System;
using System.Configuration;
using System.Runtime.CompilerServices;
using System.Security.Principal;


namespace DCS.Composition.Services.Vars.Common
{
    public class VarsServiceImplementation : IVarsService
    {
        IOutbound _db;
        readonly IPerBatchLogger _perBatchLogger;

        public VarsServiceImplementation(IPerBatchLogger perBatchLogger)
        {
            _perBatchLogger = perBatchLogger;
        }

        public VarsServiceImplementation(IPerBatchLogger perBatchLogger, IOutbound db)
        {
            _db = db;
            _perBatchLogger = perBatchLogger;
        }

        public void Start(CompositionMsg message, PerformContext context)
        {
            GeneratedControlFiles(message, context);
        }

        public GeneratedControlFilesResult GeneratedControlFiles(CompositionMsg message, PerformContext context, [CallerMemberName] string callerMemberName = "")
        {
            string BatchFolderPath = message.JobPath.TrimEnd('\\').TrimEnd('/');  // remove any extra trailing slashes or backslashes

            if (!_perBatchLogger.LogFileCreated)
            {
                _perBatchLogger.CreateForBatchId("per-batch:serilog:", "write-to:File.path", message.BatchId, message.JobPath, AppConfig.Logging.RelativeJobLogFileLocation, AppConfig.Logging.LogFileName);
            }

            var InputFilesPath = AppConfig.ControlFile.InputFilesPathDefault;
            var StagingFilesPath = AppConfig.ControlFile.StagingFilesPathDefault;

            var StatusCode = message.CorresStatusCode;
            if (StatusCode == 0) StatusCode = AppConfig.ControlFile.StatusCodeDefault;

            var BatchId = message.BatchId;
            var NATCds = string.Join(",", message.NatDins);

            try
            {
                if (callerMemberName != "Start")
                {
                    _perBatchLogger.Info($"Message received from RestAPI. {message.ToDump()}", new object[] { });
                }
                _perBatchLogger.Info($"Message received from {(callerMemberName == "Start" ? "Hangfire" : "RestAPI")}. {message.ToDump()}", new object[] { });
                _perBatchLogger.Info($"Batch Id {BatchId} starting up with following parameters being received. {NATCds}, {StatusCode}, {message.Stage}, {BatchId}, {message.JobPath}, {InputFilesPath}", new object[] { });

                _perBatchLogger.Info($"Service {AppConfig.Logging.ServiceName} running under user {WindowsIdentity.GetCurrent().Name} on machine {System.Environment.MachineName} from {AssemblyHelpers.GetExecutingAssemblyFullName()} Version {AssemblyHelpers.GetExecutingAssemblyVersion()} on machine {Environment.MachineName} as Process Id {AssemblyHelpers.GetExecutingProcess()}.", new object[] { });

                int Stage;
                _perBatchLogger.Info($"Validating Stage {message.Stage}", new object[] { });
                if (message.Stage < 1 || message.Stage > 3)
                {
                    _perBatchLogger.Info($"Invalid Stage so going to use default of 3. {message.Stage}", new object[] { });
                    Stage = 3;
                }
                else
                {
                    _perBatchLogger.Info($"Valid Stage. {message.Stage}", new object[] { });
                    Stage = message.Stage;
                }

                _perBatchLogger.Info($"Connecting to Database using connection string {AppConfig.ConnectionString.OutboundDatabase}", new object[] { });

                if (_db is null)
                {
                    try
                    {
                        _db = new DbContext(() => new SqlConnection(AppConfig.ConnectionString.OutboundDatabase));
                        _perBatchLogger.Info($"Connected to database successfully.", new object[] { });
                    }
                    catch (Exception ex)
                    {
                        AppLog.Error()(ex, message.BatchId, $"Error Connecting to Outbound Database using connection string {AppConfig.ConnectionString.OutboundDatabase}", new object[] { });
                        _perBatchLogger.Error(ex, $"Error Connecting to Outbound Database using connection string {AppConfig.ConnectionString.OutboundDatabase}", new object[] { });
                        throw;
                    }
                }

                UpdateBatchHistory(message, context, message.JGScheduleId, DcsBatchHistoryStatusEnum.CompVarServiceStarted, "VARSSVC");

                var result = new GeneratedControlFilesResult();

                try
                {
                    //Create Batch Folder if it does not exist
                    message.JobPath.CreateSubdirectory(_perBatchLogger);
                }
                catch
                {
                    UpdateBatchHistory(message, context, message.JGScheduleId, DcsBatchHistoryStatusEnum.CompVarServiceFailed, "VARSSVC");
                    throw;
                }

                _perBatchLogger.Info($"Collecting all input parameters.", new object[] { });
                var cf = new ControlFile
                {
                    BatchId = BatchId,
                    RealtimeId = BatchFolderPath.SplitToArray()[^1],
                    NATCds = NATCds,
                    StatusCode = StatusCode.ToString(),

                    InputFilesPath = InputFilesPath,
                    StagingFilesPath = StagingFilesPath,
                    BatchFolderPath = BatchFolderPath,
                    RealtimeFolderPath = BatchFolderPath,
                    PubFilesPath = AppConfig.ControlFile.PubFilesPathDefault,
                    ServiceName = AppConfig.Logging.ServiceName,
                    Environment = AppConfig.Logging.Environment,

                    GSScheduleID = message.GSScheduleId.ToString(),
                    JSServiceId = message.JGScheduleId.ToString(),
                    DeliveryChannel = message.DeliveryChannel.ToString()
                };

                if (message.Flags != null)
                {
                    cf.AllowBdeDelivery = message.Flags.AllowBdeDelivery;
                    cf.AllowDatabaseRetrieve = message.Flags.AllowDatabaseRetrieve;
                    cf.AllowDatabaseUpdate = message.Flags.AllowDatabaseUpdate;
                    cf.AllowEaiDelivery = message.Flags.AllowEaiDelivery;
                    cf.AllowMyGovDelivery = message.Flags.AllowMyGovDelivery;
                    cf.AllowPaperDelivery = message.Flags.AllowPaperDelivery;
                    cf.AllowSmppDelivery = message.Flags.AllowSmppDelivery;
                    cf.AllowSmtpDelivery = message.Flags.AllowSmtpDelivery;
                    cf.SendPaper = message.Flags.SendPaper;
                    cf.CorresNotInDb = message.Flags.CorresNotInDb;
                    cf.PdfConsolidationRequired = message.Flags.PdfConsolidationRequired;
                    cf.PsConsolidationRequired = message.Flags.PsConsolidationRequired;
                }
                else
                {
                    cf.AllowBdeDelivery = true;
                    cf.AllowDatabaseRetrieve = true;
                    cf.AllowDatabaseUpdate = true;
                    cf.AllowEaiDelivery = true;
                    cf.AllowMyGovDelivery = true;
                    cf.AllowPaperDelivery = true;
                    cf.AllowSmppDelivery = true;
                    cf.AllowSmtpDelivery = true;
                    cf.SendPaper = true;
                    cf.CorresNotInDb = true;
                    cf.PdfConsolidationRequired = true;
                    cf.PsConsolidationRequired = true;
                }
                //if the message is a campaign schedule we need to store the campaign schedule id for future reference
                if (message.CampaignScheduldeMsg != null)
                {

                    cf.CampaignScheduleId = message.CampaignScheduldeMsg.ScheduleId;
                }
                else
                {
                    cf.CampaignScheduleId = null;
                }

                _perBatchLogger.Info($"Executing Stored Procedure sptGetCorresPackagebyNATCdStatusCd('{NATCds}', {StatusCode}, {Stage})", new object[] { });
                var CorresPackage = _db.GetCorresPackagebyNATCdStatusCode(NATCds, StatusCode, Stage);



                if (CorresPackage.IsDistinct())
                {
                    _perBatchLogger.Info($"Stored Procedure sptGetCorresPackagebyNATCdStatusCd('{NATCds}', {StatusCode}, {Stage}) returned package details for {CorresPackage[0].PubFileName}", new object[] { });

                    cf.PubFileName = CorresPackage[0].PubFileName;
                    cf.PubFileDesc = CorresPackage[0].PubFileDesc;
                    cf.CASReference = CorresPackage[0].CASReference;
                    cf.UseAlternativeCASVersionInd = CorresPackage[0].UseAlternativeCASVersionInd.ToString();


                    cf.UseDiskPubFileNameInd = CorresPackage[0].UseDiskPubFileNameInd.ToString();
                    cf.OverrideStartDate = CorresPackage[0].OverrideStartDate.ToString("HH:mm dd/MM/yyyy");
                    cf.OverrideEndDate = CorresPackage[0].OverrideEndDate.ToString("HH:mm dd/MM/yyyy");

                    cf.CASReference = CorresPackage[0].CASReference;
                    cf.CASVersion = CorresPackage[0].CASVersion.ToString();
                    cf.OverriddenCASVersion = CorresPackage[0].OverriddenCASVersion.ToString();

                    if (CorresPackage[0].UseDiskPubFileNameInd.IsTrue())
                    {
                        _perBatchLogger.Info($"UseDiskPubFileNameInd is True so using Package File: {CorresPackage[0].OverriddenPubFileName}", new object[] { });
                        cf.OverriddenPubFileName = CorresPackage[0].OverriddenPubFileName;
                        cf.PackageToUse = "-PACKAGEFILE=${OverriddenPubFileName}";
                    }
                    else if (CorresPackage[0].UseAlternativeCASVersionInd.IsTrue())
                    {
                        _perBatchLogger.Info($"UseAlternativeCASVersionInd is True so using alternative CAS Version: {cf.OverriddenCASVersion} for CAS Reference: {cf.CASReference}", new object[] { });
                        cf.PackageToUse = "-CASReference=${CASReference}" + Environment.NewLine;
                        cf.PackageToUse += "-CASVersion=${OverriddenCASVersion}" + Environment.NewLine;
                    }
                    else
                    {
                        _perBatchLogger.Info($"Using default CAS Version: {cf.CASVersion} for CAS Reference: {cf.CASReference}", new object[] { });
                        cf.PackageToUse = "-CASReference=${CASReference}" + Environment.NewLine;
                        cf.PackageToUse += "-CASVersion=${CASVersion}" + Environment.NewLine;

                    }

                }
                else
                {
                    if (CorresPackage.Count > 1) { BatchLog.Fatal()($"Batch failed due to more than one package returned for given set of NATDINs, Status Code & Stage. Was expecting only 1. GetCorresPackagebyNATCdStatusCode('{NATCds}', {StatusCode}, {Stage}) returned {CorresPackage.Count} packages incorrectly."); }
                    if (CorresPackage.Count < 1) { BatchLog.Fatal()($"Batch failed due to no package returned for given set of NATDINs, Status Code & Stage.  Was expecting at least 1. GetCorresPackagebyNATCdStatusCode('{NATCds}', {StatusCode}, {Stage}) returned {CorresPackage.Count} packages."); }
                    UpdateBatchHistory(message, context, message.JGScheduleId, DcsBatchHistoryStatusEnum.CompVarServiceFailed, "VARSSVC");
                    throw new InvalidOperationException($"Batch failed due incorrect packages returned for given set of NATDINs, Status Code & Stage. Was expecting 1. GetCorresPackagebyNATCdStatusCode('{NATCds}', { StatusCode}, { Stage}) returned { CorresPackage.Count} packages incorrectly.");
                }


                _perBatchLogger.Info($"Executing Stored Procedure sptGetCorresCnfgrtnEnginebyNATCdStatusCd('{NATCds}', {StatusCode}, {Stage})", new object[] { });
                var CorresConfigEngine = _db.GetCorresConfigEnginebyNATCdStatusCode(NATCds, StatusCode, Stage);

                if (CorresConfigEngine.IsDistinct())
                {
                    _perBatchLogger.Info($"Stored Procedure sptGetCorresCnfgrtnEnginebyNATCdStatusCd('{NATCds}', {StatusCode}, {Stage}) returned engine details '{CorresConfigEngine[0].EngineName}'", new object[] { });
                    cf.EngineName = CorresConfigEngine[0].EngineName;
                    cf.EngineKey = CorresConfigEngine[0].EngineKey;
                    cf.MessageFileName = CorresConfigEngine[0].MessageFileName;
                    cf.TrackIn = CorresConfigEngine[0].TrackIn ? "ENABLE" : "DISABLE";
                    cf.RunMode = CorresConfigEngine[0].RunMode;
                    cf.StartDate = CorresConfigEngine[0].StartDate.ToString("HH:mm dd/MM/yyyy");
                    cf.EndDate = CorresConfigEngine[0].EndDate.ToString("HH:mm dd/MM/yyyy");
                }
                else
                {
                    _perBatchLogger.Fatal($"Batch failed due to more than one engine returned for given set of NATDINs, Status Code & Stage. GetCorresConfigEnginebyNATCdStatusCode('{NATCds}', {StatusCode}, {Stage}) returned {CorresConfigEngine.Count} engines incorrectly.", new object[] { });
                    UpdateBatchHistory(message, context, message.JGScheduleId, DcsBatchHistoryStatusEnum.CompVarServiceFailed, "VARSSVC");
                    throw new InvalidOperationException($"Batch failed due to more than one engine returned for given set of NATDINs, Status Code & Stage. GetCorresConfigEnginebyNATCdStatusCode('{NATCds}', {StatusCode}, {Stage}) returned {CorresConfigEngine.Count} engines incorrectly.");
                }

                _perBatchLogger.Info($"Executing Stored Procedure sptGetCorresCnfgrtnbyNATCdStatusCd('{NATCds}', {StatusCode}, {Stage})", new object[] { });
                var CorresConfig = _db.GetCorresConfigbyNATCdStatusCode(NATCds, StatusCode, Stage).Distinct();
                if (CorresConfig.Count == 0)
                {
                    _perBatchLogger.Fatal($"Batch failed due to no config variables returned for NATDINs & Status Code. GetCorresConfigbyNATCdStatusCode('{NATCds}', {StatusCode}, {Stage})", new object[] { });
                    UpdateBatchHistory(message, context, message.JGScheduleId, DcsBatchHistoryStatusEnum.CompVarServiceFailed, "VARSSVC");
                    throw new InvalidOperationException($"Batch failed due to no config variables returned for NATDINs & Status Code. GetCorresConfigbyNATCdStatusCode('{NATCds}', {StatusCode}, {Stage})");
                }
                else
                {

                    _perBatchLogger.Info($"Stored Procedure sptGetCorresCnfgrtnbyNATCdStatusCd('{NATCds}', {StatusCode}, {Stage}) returned {CorresConfig.Count} variables.", new object[] { });

                    //DPN_Auto_Fulfillment_Workaround
                    _perBatchLogger.Info($"Checking for DPN_Auto_Fulfillment_Workaround requirement. DPN_Auto_Fulfillment_Workaround {ConfigurationManager.AppSettings.Get("DPN_Auto_Fulfillment_Workaround")}", new object[] { });
                    var DPN_Auto_Fulfillment_Configs = DPN_Auto_Fulfillment_Workaround.GetHardCodedConfig(ConfigurationManager.AppSettings.Get("DPN_Auto_Fulfillment_Workaround").ToBool(), message.NatDins, message.DeliveryChannel, Stage, _perBatchLogger);

                    _perBatchLogger.Info($"CorresConfig has {CorresConfig.Count} vars", new object[] { });
                    _perBatchLogger.Info($"DPN_Auto_Fulfillment_Configs has {DPN_Auto_Fulfillment_Configs.Count} new vars", new object[] { });
                    CorresConfig.AddRange(DPN_Auto_Fulfillment_Configs);
                    _perBatchLogger.Info($"After joining DPN_Auto_Fulfillment_Configs, CorresConfig now has {CorresConfig.Count} vars", new object[] { });

                    _perBatchLogger.Info($"Writing Control Files.", new object[] { });
                    cf.CorresConfig = CorresConfig;

                    try
                    {
                        _perBatchLogger.Info($"Writing Primary Control File.", new object[] { });
                        if (Stage == 1) // For Realtime Stage 1
                        {
                            _perBatchLogger.Info($"Writing Realtime Primary Control File Stage 1.", new object[] { });
                            result.PrimaryControlFile = cf.WriteControFile("Primary", AppConfig.ControlFile.RealtimePrimaryControlFileName, AppConfig.ControlFile.RealtimePrimaryControlFileTemplate, AppConfig.ControlFile.PrimaryFileTypeCode, _perBatchLogger);
                        }
                        if (Stage == 3) // For Batch Stage 3
                        {
                            _perBatchLogger.Info($"Writing Batch Primary Control File.", new object[] { });
                            result.PrimaryControlFile = cf.WriteControFile("Primary", AppConfig.ControlFile.BatchPrimaryControlFileName, AppConfig.ControlFile.BatchPrimaryControlFileTemplate, AppConfig.ControlFile.PrimaryFileTypeCode, _perBatchLogger);
                        }

                        if (result.PrimaryControlFile.IsNullOrWhiteSpace())
                        {
                            _perBatchLogger.Error($"No Primary Control File written as there were no config variables for these NatCds:'{NATCds}' and StatusCode:{StatusCode} and Stage:{Stage}");
                        }
                        else
                        {
                            _perBatchLogger.Info($"Primary Control File Variables written. Control File Lines: {result.PrimaryControlFile.CountLines()}.", new object[] { });
                        }
                    }
                    catch (Exception ex)
                    {
                        _perBatchLogger.Fatal($"Primary Control File had an error during writing. {ex}", new object[] { });
                        UpdateBatchHistory(message, context, message.JGScheduleId, DcsBatchHistoryStatusEnum.CompVarServiceFailed, "VARSSVC");
                        throw;
                    }

                    try
                    {
                        _perBatchLogger.Info($"Writing Secondary Control File.", new object[] { });
                        if (Stage == 2) // For Realtime Stage 1
                        {
                            _perBatchLogger.Info($"Writing Realtime Secondary Control File Stage 2.", new object[] { });
                            result.SecondaryControlFile = cf.WriteControFile("Secondary", AppConfig.ControlFile.RealtimeSecondaryControlFileName, AppConfig.ControlFile.RealtimeSecondaryControlFileTemplate, AppConfig.ControlFile.SecondaryFileTypeCode, _perBatchLogger);
                        }
                        if (Stage == 3) // For Batch Stage 3
                        {
                            _perBatchLogger.Info($"Writing Batch Secondary Control File.", new object[] { });
                            result.SecondaryControlFile = cf.WriteControFile("Secondary", AppConfig.ControlFile.BatchSecondaryControlFileName, AppConfig.ControlFile.BatchSecondaryControlFileTemplate, AppConfig.ControlFile.SecondaryFileTypeCode, _perBatchLogger);
                        }

                        if (result.SecondaryControlFile.IsNullOrWhiteSpace())
                        {
                            _perBatchLogger.Info($"No Secondary Control file written as there were no config variables for these NatCds:'{NATCds}' and StatusCode:{StatusCode} and Stage:{Stage}", new object[] { });
                        }
                        else
                        {
                            _perBatchLogger.Info($"Secondary Control File Variables written. Control File Lines: {result.SecondaryControlFile.CountLines()}.", new object[] { });
                        }
                    }
                    catch (Exception ex)
                    {
                        _perBatchLogger.Fatal($"Secondary Control File had an error during writing. {ex}", new object[] { });
                        UpdateBatchHistory(message, context, message.JGScheduleId, DcsBatchHistoryStatusEnum.CompVarServiceFailed, "VARSSVC");
                        throw;
                    }

                    try
                    {
                        _perBatchLogger.Info($"Writing Job Orchestration Control File.", new object[] { });
                        if (Stage == 1 || Stage == 2) // For Realtime Stage 3
                        {
                            _perBatchLogger.Info($"Writing Orchestration Job Orchestration Control File.", new object[] { });
                            result.JobOrchestrationControlFile = cf.WriteControFile("Job Orchestration", AppConfig.ControlFile.RealtimeJobOrchestrationControlFileName, AppConfig.ControlFile.RealtimeJobOrchestrationControlFileTemplate, AppConfig.ControlFile.JobOrchestrationFileTypeCode, _perBatchLogger);
                        }
                        if (Stage == 3) // For Batch Stage 3
                        {
                            _perBatchLogger.Info($"Writing Batch Job Orchestration Control File.", new object[] { });
                            result.JobOrchestrationControlFile = cf.WriteControFile("Job Orchestration", AppConfig.ControlFile.BatchJobOrchestrationControlFileName, AppConfig.ControlFile.BatchJobOrchestrationControlFileTemplate, AppConfig.ControlFile.JobOrchestrationFileTypeCode, _perBatchLogger);
                        }
                        if (result.JobOrchestrationControlFile.IsNullOrWhiteSpace())
                        {
                            _perBatchLogger.Info($"No Job Orchestration Control File written as there were no config variables for these NatCds:'{NATCds}' and StatusCode:{StatusCode} and Stage:{Stage}", new object[] { });
                        }
                        else
                        {
                            _perBatchLogger.Info($"Job Orchestration Control File Variables written. Control File Lines: {result.JobOrchestrationControlFile.CountLines()}.", new object[] { });
                        }
                    }
                    catch (Exception ex)
                    {
                        _perBatchLogger.Fatal($"Job Orchestration Control File had an error during writing. {ex}", new object[] { });
                        UpdateBatchHistory(message, context, message.JGScheduleId, DcsBatchHistoryStatusEnum.CompVarServiceFailed, "VARSSVC");
                        throw;
                    }


                    _perBatchLogger.Info($"Batch {BatchId} Completed Successfully!", new object[] { });
                }

                UpdateBatchHistory(message, context, message.JGScheduleId, DcsBatchHistoryStatusEnum.CompVarServiceCompleted, "VARSSVC");

                return result;
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, ex.Message, new object[] { });
                throw;
            }
            finally
            {
                if (_perBatchLogger != null)
                {
                    _perBatchLogger.Dispose();
                }
            }
        }

        private void UpdateBatchHistory(CompositionMsg message, PerformContext context, Guid jobGroupServiceId, DcsBatchHistoryStatusEnum statusToRecord, string userToRecordAgainst)
        {
            DcsBatchHistory recordToAdd = new DcsBatchHistory
            {
                BatchId = message.BatchId,
                CreatedDt = DateTime.Now,
                CreatedId = userToRecordAgainst,
                GSScheduleId = message.GSScheduleId
            };
            long temp = 0;
            if (context != null)
            {
                long.TryParse(context.BackgroundJob.Id, out temp);
            }
            recordToAdd.HangfireJobId = temp;
            recordToAdd.JSScheduleId = jobGroupServiceId;
            recordToAdd.NewStatusId = (int)statusToRecord;
            recordToAdd.UpdateMsgTxt = "Created by Var Service";
            _db.AddDcsBatchHistory(recordToAdd);
        }

    }
}