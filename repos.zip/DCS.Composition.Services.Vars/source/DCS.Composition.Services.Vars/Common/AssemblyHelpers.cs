﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;

namespace DCS.Composition.Services.Vars.Common
{
    static public class AssemblyHelpers
    {

        public static DirectoryInfo GetExecutingDirectory()
        {
            var location = new Uri(Assembly.GetEntryAssembly().GetName().CodeBase);
            return new FileInfo(location.AbsolutePath).Directory;
        }

        public static string GetExecutingDirectoryName()
        {
            var location = new Uri(Assembly.GetEntryAssembly().GetName().CodeBase);
            return new FileInfo(location.AbsolutePath).Directory.FullName;
        }

        public static string GetExecutingAssemblyFullName()
        {
            var location = new Uri(Assembly.GetEntryAssembly().GetName().CodeBase);
            return new FileInfo(location.AbsolutePath).FullName;
        }

        public static string GetExecutingAssemblyName()
        {
            var location = new Uri(Assembly.GetEntryAssembly().GetName().CodeBase);
            return new FileInfo(location.AbsolutePath).FullName;
        }

        public static string GetExecutingAssemblyVersion()
        {
            return Assembly.GetEntryAssembly().GetName().Version.ToString();
        }

        public static string GetExecutingProcess()
        {
            var currentProcess = Process.GetCurrentProcess();
            return currentProcess.Id.ToString();
        }
    }
}
