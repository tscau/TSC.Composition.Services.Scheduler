﻿using DCS.Logging.Shared.Infrastructure;
using System;
using System.IO;

namespace DCS.Composition.Services.Vars.Common
{
    static public class FileSystemHelper
    {
        static public void CreateSubdirectory(this string basePath, IPerBatchLogger perBatchLogger)
        {

            if (File.Exists(basePath))
            {
                perBatchLogger.Warn($"Folder path already exists. No need to create a new one. {basePath}", new object[] { });
            }


            try
            {
                perBatchLogger.Info($"Creating new path. {basePath}", new object[] { });
                var di = new DirectoryInfo(basePath);
                di.Create();
            }
            catch (Exception ex)
            {
                perBatchLogger.Error(ex, $"Error creating new path. {basePath}", new object[] { });
                throw;
            }

        }
    }
}
