﻿using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Reflection;

namespace DCS.Composition.Services.Vars.Common
{
    public class AppConfig
    {
        /// <summary>
        /// Returns the version of the application
        /// </summary>
        public Dictionary<string, AssemblyVersionDetails> Versions
        {
            get
            {
                Dictionary<string, AssemblyVersionDetails> versions = new Dictionary<string, AssemblyVersionDetails>();
                AssemblyVersionDetails details = new AssemblyVersionDetails
                {
                    ReleaseBuild = Assembly.GetExecutingAssembly().GetName().Version.ToString(),
                    ReleaseVersion = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                    BuildNumber = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                    ReleaseName = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyProductAttribute>().Product
                };
                versions.Add(Assembly.GetExecutingAssembly().GetName().Name, details);

                Assembly sharedAssembly = Assembly.Load("DCS.Composition.Services.Shared");
                details = new AssemblyVersionDetails
                {
                    ReleaseBuild = sharedAssembly.GetName().Version.ToString(),
                    ReleaseVersion = sharedAssembly.GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                    BuildNumber = sharedAssembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                    ReleaseName = sharedAssembly.GetCustomAttribute<AssemblyProductAttribute>().Product
                };
                versions.Add(sharedAssembly.GetName().Name, details);

                //add the shared assemblies as well
                sharedAssembly = Assembly.Load("DCS.Shared.DataAccess.Outbound");
                details = new AssemblyVersionDetails
                {
                    ReleaseBuild = sharedAssembly.GetName().Version.ToString(),
                    ReleaseVersion = sharedAssembly.GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                    BuildNumber = sharedAssembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                    ReleaseName = sharedAssembly.GetCustomAttribute<AssemblyProductAttribute>().Product
                };
                versions.Add(sharedAssembly.GetName().Name, details);
                return versions;
            }
        }

        public class ConnectionString
        {
            public static string OutboundDatabase => ConfigurationManager.ConnectionStrings["OutboundCorroGen"].ConnectionString;
            public static string HangfireDatabaseConnectionString => ConfigurationManager.ConnectionStrings["Hangfire"].ConnectionString;
        }

        public class Logging
        {
            public static string ServiceName => ConfigurationManager.AppSettings.Get("ServiceName");

            public static string Environment => ConfigurationManager.AppSettings.Get("Environment");

            public static string LogFileName => ConfigurationManager.AppSettings.Get("LogFileName");

            public static string RelativeJobLogFileLocation
            {
                get
                {
                    string temp = ConfigurationManager.AppSettings.Get("RelativeJobLogFileLocation");
                    if (string.IsNullOrWhiteSpace(temp))
                    {
                        temp = "Logs";
                    }
                    return temp;
                }
            }
        }


        public class InputAPI
        {

            public class Hangfire
            {
                public static string SchemaName => ConfigurationManager.AppSettings.Get("SchemaName");
                public static int ThreadsToRun => ConfigurationManager.AppSettings.Get("HangfireThreadsToRun").ToInt32() == 0 ? 10 : ConfigurationManager.AppSettings.Get("HangfireThreadsToRun").ToInt32();

                public static string ServiceName => ConfigurationManager.AppSettings.Get("ServiceName");
            }


        }

        public class ControlFile
        {
            public static string BatchPrimaryControlFileTemplate => File.ReadAllText(AssemblyHelpers.GetExecutingDirectoryName() + ConfigurationManager.AppSettings.Get("BatchPrimaryControlFileTemplate"));

            public static string BatchSecondaryControlFileTemplate => File.ReadAllText(AssemblyHelpers.GetExecutingDirectoryName() + ConfigurationManager.AppSettings.Get("BatchSecondaryControlFileTemplate"));

            public static string BatchJobOrchestrationControlFileTemplate => File.ReadAllText(AssemblyHelpers.GetExecutingDirectoryName() + ConfigurationManager.AppSettings.Get("BatchJobOrchestrationControlFileTemplate"));

            public static string RealtimePrimaryControlFileTemplate => File.ReadAllText(AssemblyHelpers.GetExecutingDirectoryName() + ConfigurationManager.AppSettings.Get("RealtimePrimaryControlFileTemplate"));

            public static string RealtimeSecondaryControlFileTemplate => File.ReadAllText(AssemblyHelpers.GetExecutingDirectoryName() + ConfigurationManager.AppSettings.Get("RealtimeSecondaryControlFileTemplate"));

            public static string RealtimeJobOrchestrationControlFileTemplate => File.ReadAllText(AssemblyHelpers.GetExecutingDirectoryName() + ConfigurationManager.AppSettings.Get("RealtimeJobOrchestrationControlFileTemplate"));


            public static string BatchPrimaryControlFileName => ConfigurationManager.AppSettings.Get("BatchPrimaryControlFileName");
            public static string BatchSecondaryControlFileName => ConfigurationManager.AppSettings.Get("BatchSecondaryControlFileName");
            public static string BatchJobOrchestrationControlFileName => ConfigurationManager.AppSettings.Get("BatchJobOrchestrationControlFileName");

            public static string RealtimePrimaryControlFileName => ConfigurationManager.AppSettings.Get("RealtimePrimaryControlFileName");
            public static string RealtimeSecondaryControlFileName => ConfigurationManager.AppSettings.Get("RealtimeSecondaryControlFileName");
            public static string RealtimeJobOrchestrationControlFileName => ConfigurationManager.AppSettings.Get("RealtimeJobOrchestrationControlFileName");


            public static char BothFileTypeCode => ConfigurationManager.AppSettings.Get("BothFileTypeCode").Trim()[0];
            public static char PrimaryFileTypeCode => ConfigurationManager.AppSettings.Get("PrimaryFileTypeCode").Trim()[0];
            public static char SecondaryFileTypeCode => ConfigurationManager.AppSettings.Get("SecondaryFileTypeCode").Trim()[0];
            public static char JobOrchestrationFileTypeCode => ConfigurationManager.AppSettings.Get("JobOrchestrationFileTypeCode").Trim()[0];

            public static string JobFolderPathDefault => ConfigurationManager.AppSettings.Get("JobFolderPathDefault");

            public static string InputFilesPathDefault => ConfigurationManager.AppSettings.Get("InputFilesPathDefault");
            public static string StagingFilesPathDefault => ConfigurationManager.AppSettings.Get("StagingFilesPathDefault");

            public static string PubFilesPathDefault => ConfigurationManager.AppSettings.Get("PubFilesPathDefault");

            public static int StatusCodeDefault => ConfigurationManager.AppSettings.Get("StatusCodeDefault").ToInt32();


        }

        public class KestrelSettings
        {
            public static int RESTAPIPort
            {
                get
                {
                    int.TryParse(ConfigurationManager.AppSettings.Get("RESTAPIPort"), out int port);
                    return port;
                }
            }

            public static bool UseCertificateForSSL
            {
                get
                {
                    bool.TryParse(ConfigurationManager.AppSettings.Get("UseCertificateForSSL"), out bool useSSL);
                    return useSSL;
                }
            }
            public static string CertificateSubject
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("CertificateSubject");
                }
            }
            public static string CertificateStoreName
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("CertificateStoreName");
                }
            }

            public static string CertificateLocation
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("CertificateLocation");
                }
            }
            public static bool CertificateAllowInvalid
            {
                get
                {
                    bool.TryParse(ConfigurationManager.AppSettings.Get("CertificateAllowInvalid"), out bool allowInvalid);
                    return allowInvalid;
                }
            }
        }
    }
}
