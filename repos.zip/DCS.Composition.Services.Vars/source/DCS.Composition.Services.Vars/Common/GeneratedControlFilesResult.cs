﻿using DCS.Composition.Services.Vars.Documents;

namespace DCS.Composition.Services.Vars.Common
{
    public class GeneratedControlFilesResult
    {
        public ControlFile ControlFileObject { get; set; }

        public string PrimaryControlFile { get; set; }
        public string SecondaryControlFile { get; set; }
        public string JobOrchestrationControlFile { get; set; }


    }
}
