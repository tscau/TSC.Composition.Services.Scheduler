﻿using DCS.Composition.Services.Vars.Documents;
using DCS.Logging.Shared.Infrastructure;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace DCS.Composition.Services.Vars.Common
{
    public static class DPN_Auto_Fulfillment_Workaround
    {
        public static List<OnlyCorresConfig> GetHardCodedConfig(bool DPN_Auto_Fulfillment_Workaround_Enabled, List<string> NatDins, int DeliveryChannel, int stage, IPerBatchLogger perBatchLogger)
        {
            var CorresConfigs = new List<OnlyCorresConfig>();

            if (DPN_Auto_Fulfillment_Workaround_Enabled)    //Feature flag controlled via config
            {
                if (stage == 3)//only apply these varsets if its a batch mode stage 3 in db
                {

                    perBatchLogger.Info($"DPN_Auto_Fulfillment_Workaround is {ConfigurationManager.AppSettings.Get("DPN_Auto_Fulfillment_Workaround")}. Checking if it is one of the affected templates.", new object[] { });
                    var ListofAffectedLocalPrintTemplates = new List<string> { "73075.500008", "73075.500029", "73075.500030", "73075.500031", "73075.500032" };
                    if (NatDins.Any(x => ListofAffectedLocalPrintTemplates.Any(y => x == y)))
                    {
                        perBatchLogger.Info($"Looks like we have to apply the workaround for this list of DPN Templates.", new object[] { });
                        perBatchLogger.Info($"Checking Channel Code for Local_Print=30. Currently: {DeliveryChannel}", new object[] { });
                        if (DeliveryChannel == 30)  //Local Print
                        {
                            perBatchLogger.Info($"For these Local Print DPN Templates, setting Local Print Vars", new object[] { });
                            var Local_Print_Config = new OnlyCorresConfig()
                            {
                                TmpltSpcfcInd = true,
                                FileType = 'P',
                                ConfigType = "VARSET",
                                ConfigParameter = "PUB_MODE",
                                ConfigValue = "LOCAL_PRINT"
                            };
                            CorresConfigs.Add(Local_Print_Config);
                            Local_Print_Config = new OnlyCorresConfig()
                            {
                                TmpltSpcfcInd = true,
                                FileType = 'S',
                                ConfigType = "VARSET",
                                ConfigParameter = "PUB_MODE",
                                ConfigValue = "LOCAL_PRINT"
                            };
                            CorresConfigs.Add(Local_Print_Config);

                        }
                        else //Bulk Print
                        {
                            perBatchLogger.Info($"For these non-Local Print DPN Templates, using Batch Vars", new object[] { });
                            var Batch_Print_Config = new OnlyCorresConfig()
                            {
                                TmpltSpcfcInd = true,
                                FileType = 'P',
                                ConfigType = "VARSET",
                                ConfigParameter = "PUB_MODE",
                                ConfigValue = "BATCH_PRINT"
                            };
                            CorresConfigs.Add(Batch_Print_Config);
                            Batch_Print_Config = new OnlyCorresConfig()
                            {
                                TmpltSpcfcInd = true,
                                FileType = 'S',
                                ConfigType = "VARSET",
                                ConfigParameter = "PUB_MODE",
                                ConfigValue = "BATCH_PRINT"
                            };
                            CorresConfigs.Add(Batch_Print_Config);
                        }
                    }
                }
            }
            //DPN_Auto_Fulfillment_Workaround END
            return CorresConfigs;
        }
    }
}
