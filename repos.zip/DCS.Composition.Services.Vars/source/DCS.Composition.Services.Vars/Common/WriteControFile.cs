﻿using DCS.Composition.Services.Vars.Documents;
using DCS.Logging.Shared.Infrastructure;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace DCS.Composition.Services.Vars.Common
{
    public static class WriteControFileHelper
    {
        internal static string WriteControFile(this ControlFile cf, string ControlFileName, string ControlFileNamePath, string ControlFileTemplate, char FileTypeCode, IPerBatchLogger perBatchLogger)
        {
            IEnumerable<OnlyCorresConfig> vars;
            if (FileTypeCode == AppConfig.ControlFile.JobOrchestrationFileTypeCode)
            {
                perBatchLogger.Info($"Filtering Vars for Job Orchestration FileType Code", new object[] { });
                vars = cf.CorresConfig.Where(c => (c.FileType == FileTypeCode));
                perBatchLogger.Info($"This number of {vars.Count()} Vars found for JobOrchestrationFileTypeCode", new object[] { });
            }
            else
            {
                perBatchLogger.Info($"Filtering Vars for {ControlFileName} and Both FileType Codes", new object[] { });
                vars = cf.CorresConfig.Where(c => (c.FileType == FileTypeCode) || (c.FileType == AppConfig.ControlFile.BothFileTypeCode));
                perBatchLogger.Info($"This number of {vars.Count()} Vars found for {ControlFileName} and BothFileTypeCode", new object[] { });
            }


            if (cf.CorresConfig.Count == 0)
            {
                perBatchLogger.Info($"No config variables found in database, but will still write control file.", new object[] { });
            }

            cf.FileType = ControlFileName;
            cf.DateTime = DateTime.Now.ToString("HH:mm.fff dd/MM/yyyy");
            cf.SortId = cf.BatchId.ToSortId();

            var cft = ControlFileTemplate;

            cft = cft.Replace("${PackageToUse}", cf.PackageToUse);



            //set any campaign portal schedule ids in the job_orchestration file
            if (cf.CampaignScheduleId != null)
            {
                cft = cft.Replace("${CampaignScheduleId}", $"*CAMPAIGNSCHEDULEID={cf.CampaignScheduleId}");
            }
            else
            {
                cft = cft.Replace("${CampaignScheduleId}", "");
            }


            if (!cft.EndsWith(Environment.NewLine)) cft += Environment.NewLine;

            perBatchLogger.Info($"Sorting config vars so that generic ones come first then template specific ones.", new object[] { });
            vars = vars.OrderBy(v => v.TmpltSpcfcInd);
            perBatchLogger.Info($"Sorting done.", new object[] { });

            // Populate the config lines
            perBatchLogger.Info($"Populate the config lines. {vars.Count()} variables found.", new object[] { });
            foreach (OnlyCorresConfig varline in vars)
            {
                var DuplicateCheckConfigLine = NewFormattedConfigLine(varline.ConfigType, varline.ConfigParameter);
                if (cft.Contains(DuplicateCheckConfigLine, StringComparison.InvariantCultureIgnoreCase))       //Check for duplicate lines
                {
                    perBatchLogger.Info($"Found a duplicate variable config line {DuplicateCheckConfigLine} so overriding it by commenting it out.", new object[] { });
                    cft = cft.Replace(DuplicateCheckConfigLine, "*" + DuplicateCheckConfigLine, StringComparison.InvariantCultureIgnoreCase);
                }
                var NewConfigLine = NewFormattedConfigLine(varline.ConfigType, varline.ConfigParameter, varline.ConfigValue);
                cft += NewConfigLine + Environment.NewLine;
            }

            // Replace all the ${Tags}
            perBatchLogger.Info("Replacing ${Tags}.", new object[] { });
            ReplaceTagsWithControlFileValues(ref cft, cf, perBatchLogger);
            perBatchLogger.Info("Completed replacing ${Tags}.", new object[] { });



            var controlFilePath = new System.IO.FileInfo(cf.BatchFolderPath + ControlFileNamePath);

            if (!controlFilePath.Exists)
            {
                perBatchLogger.Info($"Creating controlFilePath folder. {controlFilePath}", new object[] { });
                System.IO.Directory.CreateDirectory(controlFilePath.Directory.FullName);
            }
            perBatchLogger.Info($"Writing Control File {ControlFileName}...", new object[] { });
            File.WriteAllText(controlFilePath.FullName, cft);
            perBatchLogger.Info($"Completed writing Control File {ControlFileName}.", new object[] { });
            return cft;
        }

        public static string NewFormattedConfigLine(string ConfigType, string ConfigParameter, string ConfigValue = null)
        {
            var NewConfigLine = "-" + ConfigType + "=";
            if (ConfigParameter.Trim() != string.Empty) NewConfigLine += ConfigParameter + ",";
            if (ConfigValue?.Trim() != string.Empty) NewConfigLine += ConfigValue;

            return NewConfigLine;
        }

        public static void ReplaceTagsWithControlFileValues(ref string cft, ControlFile cf, IPerBatchLogger perBatchLogger)
        {
            var loopthroughembeddedtags = 0;
            do
            {
                foreach (PropertyInfo prop in cf.GetType().GetProperties())
                {
                    var type = Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType;
                    if (type == typeof(String) || type == typeof(long) || type == typeof(bool))
                    {
                        if (prop.GetValue(cf) != null)
                        {
                            cft = cft.Replace("${" + prop.Name + "}", prop.GetValue(cf, null).ToString(), StringComparison.InvariantCultureIgnoreCase);
                        }
                        else
                        {
                            cft = cft.Replace("${" + prop.Name + "}", "null", StringComparison.InvariantCultureIgnoreCase);
                        }
                    }
                }
                loopthroughembeddedtags++;
                perBatchLogger.Info($"Replaced ${{Tags}} {loopthroughembeddedtags} number of times.", new object[] { });
            }
            while (cft.Contains("${", StringComparison.InvariantCultureIgnoreCase) && loopthroughembeddedtags <= 3);    //Repeat until all ${Tags} are done or we've done it twice at least

            if (loopthroughembeddedtags >= 3)
            {
                BatchLog.Fatal()($"Could not replace all ${{Tag}}. Went through the maximum number of retries. Please check the Tags and the Control File Properties. Something is not getting replaced or there are some unknown ${{Tags}}.");
                throw new InvalidOperationException($"Could not replace all ${{Tag}}. Went through the maximum number of retries. Please check the Tags and the Control File Properties. Something is not getting replaced or there are some unknown ${{Tags}}.");
            }
        }

    }
}
