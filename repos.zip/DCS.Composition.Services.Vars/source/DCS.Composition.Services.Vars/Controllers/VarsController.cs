﻿using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.VarsService;
using DCS.Composition.Services.Vars.Common;
using DCS.Logging.Shared.Infrastructure;
using Hangfire;
using Microsoft.AspNetCore.Mvc;
using System;

namespace DCS.Composition.Services.Vars.Controllers
{
    /// <summary>
    /// Controller to allow for low volume access to the service implementation
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class VarsController : ControllerBase
    {
        readonly AppConfig cfg = new AppConfig();
        readonly IPerBatchLogger _perBatchLogger;

        public VarsController(IPerBatchLogger perBatchLogger)
        {
            _perBatchLogger = perBatchLogger;
        }


        /// <summary>
        /// REST call to perform a data retrieve based on the input parameters. 
        /// </summary>
        /// <param name="message">The <seealso cref="CompositionMsg"></seealso>/> containing the message sent.</param>
        /// <returns></returns>
        [Route("CallVarsServiceViaHangfire")]
        [HttpPost]
        public ActionResult<string> CallVarsServiceViaHangfire(CompositionMsg message)
        {
            try
            {
                var jobId = BackgroundJob.Enqueue<IVarsService>(x => x.Start(message, null));
                return "Vars Service message placed on Hangfire Queue. JobID: " + jobId;
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, ex.Message, new object[] { });
                throw;
            }
            finally
            {
                if (_perBatchLogger != null)
                {
                    _perBatchLogger.Dispose();
                }
            }
        }

        /// <summary>
        /// REST call to perform a data retrieve based on the input parameters. 
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        [Route("CallVarsService")]
        [HttpPost]
        public JsonResult CallVarsService(CompositionMsg message)
        {
            try
            {
                var vars = new VarsServiceImplementation(_perBatchLogger);
                var result = vars.GeneratedControlFiles(message, null);

                return new JsonResult(result);
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, ex.Message, new object[] { });
                throw;
            }
            finally
            {
                if (_perBatchLogger != null)
                {
                    _perBatchLogger.Dispose();
                }
            }
        }


        /// <summary>
        /// Method to get the current config entries for the application. Returns as a string.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetCurrentConfig")]
        public JsonResult GetCurrentConfig()
        {
            return new JsonResult(cfg);
        }

        /// <summary>
        /// REST end point to get the version of the application and any shared components that make sense to report on
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("VersionInfo")]
        public JsonResult VersionInfo()
        {
            return new JsonResult(cfg.Versions);
        }


        /// <summary>
        /// Method to get the heartbeat of the service. Provided so that other apps can query the service
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("Heartbeat")]
        public JsonResult Heartbeat()
        {
            return new JsonResult("running");
        }
    }
}
