using DCS.Composition.Services.Vars.Common;
using DCS.Composition.Services.Vars.Documents;
using DCS.Logging.Shared.Infrastructure;
using Moq;
using Xunit;

namespace DCS.Composition.Services.Vars.UnitTests
{
    public class WriteControlFileTests
    {
        [Theory]
        [InlineData("POSTSORTQUEUE", "", "ALL", "-POSTSORTQUEUE=ALL")]
        [InlineData("FILEMAP", "MASTER-INITIALISATION", @"${InputFilesPath}\MasterInitialisationFile.xml", @"-FILEMAP=MASTER-INITIALISATION,${InputFilesPath}\MasterInitialisationFile.xml")]
        [InlineData("SORTID", "", "000002", "-SORTID=000002")]
        [InlineData("FILEMAP", "POSTSORT_PS_FileID", "PS_IDS.csv", "-FILEMAP=POSTSORT_PS_FileID,PS_IDS.csv")]
        [InlineData("FILEMAP", "ps", "", "-FILEMAP=ps,")]

        public void EnsureTheNewFormattedConfigLineReturnsCorrectResults(string ConfigType, string ConfigParameter, string ConfigValue, string ExpectedValue)
        {
            var TestResult = WriteControFileHelper.NewFormattedConfigLine(ConfigType, ConfigParameter, ConfigValue);

            Assert.Equal(ExpectedValue, TestResult);
        }



        [Theory]
        [InlineData(@"-FILEMAP=MASTER-INITIALISATION,${InputFilesPath}\MasterInitialisationFile.xml", "InputFilesPath", @"\\DCSXFLS00009DE.devtest.atohdtnet.gov.au\DCSCORRES_DE\TEMP_TEST\DEM\InputFiles",
                    @"-FILEMAP=MASTER-INITIALISATION,\\DCSXFLS00009DE.devtest.atohdtnet.gov.au\DCSCORRES_DE\TEMP_TEST\DEM\InputFiles\MasterInitialisationFile.xml")]

        [InlineData(@"-FILEMAP=DRIVER,${BatchFolderPath}\DRIVER.xml", "BatchFolderPath", @"E:\ATOApplications\Exstream\Command-Center\var\jobs\1",
                    @"-FILEMAP=DRIVER,E:\ATOApplications\Exstream\Command-Center\var\jobs\1\DRIVER.xml")]
        [InlineData(@"*DELIVERY_CHANNEL=${DeliveryChannel}", "DeliveryChannel", "105", @"*DELIVERY_CHANNEL=105")]

        public void TestReplaceTagsWithControlFileValues(string template, string controlfileproperty, string stringcontrolfilevalue, string ExpectedValue)
        {

            var mockPerBatchLogger = new Mock<IPerBatchLogger>();

            var cft = template;
            var cf = new ControlFile();

            typeof(ControlFile).GetProperty(controlfileproperty).SetValue(cf, stringcontrolfilevalue);

            WriteControFileHelper.ReplaceTagsWithControlFileValues(ref cft, cf, mockPerBatchLogger.Object);


            Assert.Equal(ExpectedValue, cft);
        }
    }
}
