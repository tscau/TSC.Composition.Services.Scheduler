﻿using Xunit;

namespace DCS.Composition.Services.Vars.UnitTests.Helpers
{
    enum DataIs
    {
        Good,
        Bad
    }

    static class Test
    {
        public static void Fail(string message)
        {
            Assert.True(false, message);
        }

        public static void Pass(string message)
        {
            Assert.True(true, message);
        }

    }
}
