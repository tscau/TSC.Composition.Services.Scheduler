﻿using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Vars.Common;
using DCS.Logging.Shared.Infrastructure;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Documents;
using DCS.Shared.DataAccess.Outbound.Enums;
using Moq;
using NSubstitute;
using System;
using System.Collections.Generic;
using Xunit;

namespace DCS.Composition.Services.Vars.UnitTests.Common
{
    public class VarsServiceImplementationTests
    {
        [Fact]
        public void GivenVarsService_WhenInvalidJobPath_ThenErrorWrittenToDCSBatchHistory()
        {

            var database = Substitute.For<IOutbound>();

            var mockPerBatchLogger = new Mock<IPerBatchLogger>();


            var varsService = new VarsServiceImplementation(mockPerBatchLogger.Object, database);

            var message = new CompositionMsg()
            {
                GSScheduleId = Guid.Parse("1c82fc78-39fc-4bd3-8b57-a02bbfaa6705"),
                JGScheduleId = Guid.Parse("07cf6e3c-1f97-466f-9f8d-b9b45154a366"),
                DeliveryChannel = 70,
                BatchId = 9681,
                NatDins = new List<string>() { "70571.103783" },
                CorresStatusCode = 20,
                JobPath = "", // Should throw error for this being empty
                NumberPerSchedule = 30000,
                Flags = new Flags()
                {
                    AllowBdeDelivery = true,
                    AllowDatabaseRetrieve = true,
                    AllowDatabaseUpdate = true,
                    AllowEaiDelivery = false,
                    AllowMyGovDelivery = false,
                    AllowPaperDelivery = false,
                    AllowSmppDelivery = false,
                    AllowSmtpDelivery = false,
                    SendPaper = false,
                    CorresNotInDb = true,
                    PdfConsolidationRequired = false,
                    PsConsolidationRequired = false
                },
            };

            ArgumentException ex = null;
            try
            {

                var result = varsService.GeneratedControlFiles(message, null);
            }
            catch (ArgumentException exception)
            {
                ex = exception;
            }

            Assert.Equal("The path is empty. (Parameter 'path')", ex.Message);
            database.Received().AddDcsBatchHistory(Arg.Is<DcsBatchHistory>(x => CheckDcsBatchHistoryArgument(x)));
        }

        bool CheckDcsBatchHistoryArgument(DcsBatchHistory dcsBatchHistory)
        {
            Assert.Equal((int)DcsBatchHistoryStatusEnum.CompVarServiceFailed, dcsBatchHistory.NewStatusId);
            Assert.Equal("VARSSVC", dcsBatchHistory.CreatedId);
            return true;
        }
    }
}
