using DCS.Composition.Services.Vars.Common;
using Xunit;

namespace DCS.Composition.Services.Vars.UnitTests
{
    public class SortIdTest
    {
        [Theory]
        [InlineData(992295, "00l9nr")]
        [InlineData(0, "000000")]
        [InlineData(1, "000001")]
        [InlineData(35, "00000z")]
        [InlineData(36, "000010")]
        [InlineData(long.MaxValue, "32e8e7")]

        public void SortIdReturnsCorrectFormatForBase36lowercasedandsixcharsinlength(long BatchId, string ExpectedSortId)
        {
            var CalculatedSortId = BatchId.ToSortId();

            Assert.Equal(ExpectedSortId, CalculatedSortId);
        }
    }
}
