using DCS.Composition.Services.GlobalScheduler.Common;
using DCS.Composition.Services.GlobalScheduler.Config;
using DCS.Composition.Services.GlobalScheduler.UnitTests.Builders;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Documents;
using FluentAssertions;
using Moq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Xunit;

namespace DCS.Composition.GlobalScheduler.UnitTests
{
    public class GlobalSchedulerImplementationTests
    {
        [Fact]
        public void Scheduling_NumberOfCorres_GreaterThan_NumberPerSchedule_DifferentPriorities_DifferentPubIds_NonElectronic()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
                .With(11).CorresForNatCd("70571.501042").HavingSchedulingPriority(5).AndCorresPubId(2)
                .With(12).CorresForNatCd("70571.501043").HavingSchedulingPriority(1).AndCorresPubId(3)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 20,
                Flags = new Flags(),
                NatDins = new List<string>(),
                DeliveryChannel = 5
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(2);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041", 10);
            VerifyJob(db, jobs[1], "70571.501042", 10);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_GreaterThan_NumberPerSchedule_DifferentPriorities_DifferentPubIds_Electronic()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
                .With(11).CorresForNatCd("70571.501042").HavingSchedulingPriority(5).AndCorresPubId(2)
                .With(12).CorresForNatCd("70571.501043").HavingSchedulingPriority(1).AndCorresPubId(3)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 20,
                Flags = new Flags(),
                NatDins = new List<string>(),
                DeliveryChannel = 100
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(2);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041", 10);
            VerifyJob(db, jobs[1], "70571.501042", 10);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_GreaterThan_NumberPerSchedule_SamePriorities_DifferentPubIds_ProdExample()
        {
            var db = new MockDatabaseBuilder()
                .With(63389).CorresForNatCd("74831.392384").HavingSchedulingPriority(1).AndCorresPubId(1)
                .With(284).CorresForNatCd("74867.397460").HavingSchedulingPriority(1).AndCorresPubId(2)
                .With(46).CorresForNatCd("74867.398339").HavingSchedulingPriority(1).AndCorresPubId(3)
                .With(34).CorresForNatCd("74867.500772").HavingSchedulingPriority(1).AndCorresPubId(4)
                .With(1).CorresForNatCd("74867.501839").HavingSchedulingPriority(1).AndCorresPubId(5)
                .With(960).CorresForNatCd("74955.500861").HavingSchedulingPriority(1).AndCorresPubId(6)
                .With(60).CorresForNatCd("74973.500923").HavingSchedulingPriority(1).AndCorresPubId(7)
                .With(619).CorresForNatCd("74973.500924").HavingSchedulingPriority(1).AndCorresPubId(8)
                .With(112).CorresForNatCd("74976.500926").HavingSchedulingPriority(1).AndCorresPubId(9)
                .With(6).CorresForNatCd("75145.501296").HavingSchedulingPriority(1).AndCorresPubId(10)
                .With(3).CorresForNatCd("75145.501297").HavingSchedulingPriority(1).AndCorresPubId(11)
                .With(65).CorresForNatCd("75161.501401").HavingSchedulingPriority(1).AndCorresPubId(12)
                .With(65).CorresForNatCd("75161.501402").HavingSchedulingPriority(0).AndCorresPubId(13)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 30000,
                Flags = new Flags(),
                NatDins = new List<string>()
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(1);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "74831.392384", 30000);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_GreaterThan_NumberPerSchedule_SamePriorities_DifferentPubIds()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
                .With(11).CorresForNatCd("70571.501042").HavingSchedulingPriority(9).AndCorresPubId(2)
                .With(12).CorresForNatCd("70571.501043").HavingSchedulingPriority(9).AndCorresPubId(3)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 20,
                Flags = new Flags(),
                NatDins = new List<string>()
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(2);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041", 10);
            VerifyJob(db, jobs[1], "70571.501042", 10);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_GreaterThan_NumberPerSchedule_SamePriorities_SamePubIds()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
                .With(11).CorresForNatCd("70571.501042").HavingSchedulingPriority(9).AndCorresPubId(1)
                .With(12).CorresForNatCd("70571.501043").HavingSchedulingPriority(9).AndCorresPubId(1)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 20,
                Flags = new Flags(),
                NatDins = new List<string>()
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(1);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041,70571.501042", 20);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_GreaterThan_NumberPerSchedule_SinglePub()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 5,
                Flags = new Flags(),
                NatDins = new List<string>()
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(1);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041", 5);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_GreaterThan_NumberPerSchedule_TwoWithSamePubIds()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
                .With(11).CorresForNatCd("70571.501042").HavingSchedulingPriority(1).AndCorresPubId(2)
                .With(12).CorresForNatCd("70571.501043").HavingSchedulingPriority(9).AndCorresPubId(1)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 25,
                Flags = new Flags(),
                NatDins = new List<string>()
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(2);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041,70571.501043", 22);
            VerifyJob(db, jobs[1], "70571.501042", 3);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_LessThan_NumberPerSchedule_DifferentPriorities_DifferentPubIds()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
                .With(11).CorresForNatCd("70571.501042").HavingSchedulingPriority(5).AndCorresPubId(2)
                .With(12).CorresForNatCd("70571.501043").HavingSchedulingPriority(1).AndCorresPubId(3)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 100,
                Flags = new Flags(),
                NatDins = new List<string>()
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(3);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041", 10);
            VerifyJob(db, jobs[1], "70571.501042", 11);
            VerifyJob(db, jobs[2], "70571.501043", 12);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_LessThan_NumberPerSchedule_SamePriorities_DifferentPubIds()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
                .With(11).CorresForNatCd("70571.501042").HavingSchedulingPriority(9).AndCorresPubId(2)
                .With(12).CorresForNatCd("70571.501043").HavingSchedulingPriority(9).AndCorresPubId(3)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 100,
                Flags = new Flags(),
                NatDins = new List<string>()
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(3);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041", 10);
            VerifyJob(db, jobs[1], "70571.501042", 11);
            VerifyJob(db, jobs[2], "70571.501043", 12);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_LessThan_NumberPerSchedule_SamePriorities_SamePubIds()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
                .With(11).CorresForNatCd("70571.501042").HavingSchedulingPriority(9).AndCorresPubId(1)
                .With(12).CorresForNatCd("70571.501043").HavingSchedulingPriority(9).AndCorresPubId(1)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 100,
                Flags = new Flags(),
                NatDins = new List<string>()
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(1);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041,70571.501042,70571.501043", 33);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_LessThan_NumberPerSchedule_SinglePub()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 100,
                Flags = new Flags(),
                NatDins = new List<string>()
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(1);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041", 10);
        }

        [Fact]
        public void Scheduling_NumberOfCorres_LessThan_NumberPerSchedule_SinglePub_Priority_0()
        {
            var db = new MockDatabaseBuilder()
                .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(0).AndCorresPubId(1)
                .Build();

            var message = new CompositionMsg
            {
                NumberPerSchedule = 100,
                Flags = new Flags(),
                NatDins = new List<string>()
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            var response = new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .DoWork(message, null, db.Object, false);

            var jobs = response.Jobs.ToArray();
            response.Jobs.Should().HaveCount(1);
            response.Jobs.Sum(job => job.NumberToProcess).Should().BeLessOrEqualTo(message.NumberPerSchedule);

            VerifyJob(db, jobs[0], "70571.501041", 10);
        }

        [Fact]
        public void RunBdv_SingleBetId()
        {
            var db = new MockDatabaseBuilder()
               .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
               .Build();

            List<long> BetIds = new List<long>() { 123123123 };
            Flags flags = new Flags
            {
                AllowBdeDelivery = false,
                AllowDatabaseRetrieve = true,
                AllowDatabaseUpdate = false,
                AllowEaiDelivery = false,
                AllowMyGovDelivery = false,
                AllowPaperDelivery = false,
                AllowSmppDelivery = false,
                AllowSmtpDelivery = false,
                CorresNotInDb = false,
                PdfConsolidationRequired = false,
                PsConsolidationRequired = false,
                SendPaper = false
            };

            ProcessBdvRequest request = new ProcessBdvRequest
            {
                BetIds = BetIds,
                DeliveryChannel = 5,
                Status = 12,
                StatusToProcess = 20,
                NatCd = "70571.501041",
                Flags = flags,
                RunAt = new DateTimeOffset(),
                CallHangfire = false
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .RunBdv(request);

            VerifyBdvJob(db);
        }

        [Fact]
        public void RunBdv_SingleBetId_NatCdNotFound()
        {
            var db = new MockDatabaseBuilder()
               .With(10).CorresForNatCd("70571.12313").HavingSchedulingPriority(9).AndCorresPubId(1)
               .Build();

            List<long> BetIds = new List<long>() { 123123123 };
            Flags flags = new Flags
            {
                AllowBdeDelivery = false,
                AllowDatabaseRetrieve = true,
                AllowDatabaseUpdate = false,
                AllowEaiDelivery = false,
                AllowMyGovDelivery = false,
                AllowPaperDelivery = false,
                AllowSmppDelivery = false,
                AllowSmtpDelivery = false,
                CorresNotInDb = false,
                PdfConsolidationRequired = false,
                PsConsolidationRequired = false,
                SendPaper = false
            };

            ProcessBdvRequest request = new ProcessBdvRequest
            {
                BetIds = BetIds,
                DeliveryChannel = 5,
                Status = 12,
                StatusToProcess = 20,
                NatCd = "70571.501041",
                Flags = flags,
                RunAt = new DateTimeOffset(),
                CallHangfire = false
            };
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            new GlobalSchedulerImplementation(new AppConfig(), db.Object, mockRegistry)
                .RunBdv(request);

            db.Verify(x => x.UpdateBatchByBetId(It.IsAny<UpdateBatchByBetId>()), Times.Never());
        }


        private void VerifyJob(Mock<IOutbound> mock, GSJob job, string natCds, int numberToProcess)
        {
            job.NumberToProcess.Should().Be(numberToProcess);
            job.NatCds.Should().Be(natCds);

            mock.Verify(x => x.UpdateCorresRequestStatusAndBatchByDeliveryChannel(
                natCds,
                It.IsAny<string>(),
                It.IsAny<int>(),
                numberToProcess,
                It.IsAny<int>(),
                It.IsAny<DateTime>(),
                It.IsAny<DateTime>(),
                It.IsAny<int>()
            ), Times.Once());
        }

        private void VerifyBdvJob(Mock<IOutbound> mock)
        {
            mock.Verify(x => x.UpdateBatchByBetId(It.IsAny<UpdateBatchByBetId>()), Times.Once());
        }

        [Fact]
        public void WhenConsolidationJob_ThenShouldCreateBatchUsingElectronicBatch()
        {
            //Arrange
            string currentExecutingFolder = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName;

            var db = new MockDatabaseBuilder()
               //.WithBPMList().HavingBarcodeSortPlanId(2).AndBPMVendorId(5).AndBulkPrintBatchId(5).AndPostalClassificationCd("CLEN").AndPrintLocationId(2).AndPrintPlanNm("NAT").AndPrintStreamId(51)
               .Build();

            ConsolidationMsg consolidationMsg = new ConsolidationMsg()
            {
                IsPdfConsolidation = false,
                IsPsConsolidation = true,
                PrintStream = 51,
                StagingFolderName = "TestStaging"
            };

            var message = new CompositionMsg
            {
                IsStageForConsolidationJob = true,
                NumberPerSchedule = 100,
                NatDins = new List<string>(),
                CorresStatusCode = 20,
                DeliveryChannel = 5,
                GSScheduleId = Guid.NewGuid(),
                JGScheduleId = Guid.NewGuid(),
                JobPath = Path.Combine(currentExecutingFolder, ""),
                ConsolidationMsg = consolidationMsg,
                Flags = new Flags
                {
                    AllowBdeDelivery = true,
                    AllowDatabaseRetrieve = true,
                    AllowDatabaseUpdate = true,
                    AllowEaiDelivery = true,
                    AllowMyGovDelivery = true,
                    AllowPaperDelivery = true,
                    AllowSmppDelivery = true,
                    AllowSmtpDelivery = true,
                    PdfConsolidationRequired = true,
                    PsConsolidationRequired = true,
                    SendPaper = true
                }
            };
            var mockAppConfig = MockAppConfigBuilder.SetupAppConfig();
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            //Act
            var gsimpl = new GlobalSchedulerImplementation(mockAppConfig, db.Object, mockRegistry);
            var response = gsimpl.DoWork(message, null, db.Object, false);

            //Assert
            response.Should().NotBeNull();
            response.Jobs.Should().HaveCount(1);
            response.Jobs[0].HangfireJobServiceJobId.Should().Be("None Triggered - triggerJobService set to false");
            response.LogMessages.Contains("Batch created with CreateBulkPrintBatch");
        }


        [Fact]
        public void WhenNotConsolidationJob_AndIsNotElectronicCorres_ThenShouldCreateBatchWithCreateBulkPrintBatch()
        {
            string currentExecutingFolder = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName;

            var db = new MockDatabaseBuilder()
               //.WithBPMList().HavingBarcodeSortPlanId(2).AndBPMVendorId(5).AndBulkPrintBatchId(5).AndPostalClassificationCd("CLEN").AndPrintLocationId(2).AndPrintPlanNm("NAT").AndPrintStreamId(51)
               .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
               .With(11).CorresForNatCd("70571.501042").HavingSchedulingPriority(9).AndCorresPubId(1)
               .With(12).CorresForNatCd("70571.501043").HavingSchedulingPriority(9).AndCorresPubId(1)
               .Build();

            var message = new CompositionMsg
            {
                IsStageForConsolidationJob = false,
                NumberPerSchedule = 100,
                NatDins = new List<string>(),
                CorresStatusCode = 20,
                DeliveryChannel = 5,
                GSScheduleId = Guid.NewGuid(),
                JGScheduleId = Guid.NewGuid(),
                JobPath = Path.Combine(currentExecutingFolder, ""),
                Flags = new Flags
                {
                    AllowBdeDelivery = true,
                    AllowDatabaseRetrieve = true,
                    AllowDatabaseUpdate = true,
                    AllowEaiDelivery = true,
                    AllowMyGovDelivery = true,
                    AllowPaperDelivery = true,
                    AllowSmppDelivery = true,
                    AllowSmtpDelivery = true,
                    PdfConsolidationRequired = true,
                    PsConsolidationRequired = true,
                    SendPaper = true
                }
            };
            var mockAppConfig = MockAppConfigBuilder.SetupAppConfig();
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            //Act
            var gsimpl = new GlobalSchedulerImplementation(mockAppConfig, db.Object, mockRegistry);
            var response = gsimpl.DoWork(message, null, db.Object, false);

            //Assert
            response.Should().NotBeNull();
            response.Jobs.Should().HaveCount(1);
            response.Jobs[0].HangfireJobServiceJobId.Should().Be("None Triggered");
            response.LogMessages.Contains("Batch created with CreateBulkPrintBatch");
        }

        [Fact]
        public void WhenNotConsolidationJob_AndIsElectronicCorres_ThenShouldCreateBatchWithCreateElectronic()
        {
            string currentExecutingFolder = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName;

            var db = new MockDatabaseBuilder()
               .With(10).CorresForNatCd("70571.501041").HavingSchedulingPriority(9).AndCorresPubId(1)
               .With(11).CorresForNatCd("70571.501042").HavingSchedulingPriority(5).AndCorresPubId(2)
               .With(12).CorresForNatCd("70571.501043").HavingSchedulingPriority(1).AndCorresPubId(3)
               .Build();

            var message = new CompositionMsg
            {
                IsStageForConsolidationJob = false,
                NumberPerSchedule = 5,
                NatDins = new List<string>(),
                CorresStatusCode = 20,
                DeliveryChannel = 105,
                GSScheduleId = Guid.NewGuid(),
                JGScheduleId = Guid.NewGuid(),
                JobPath = Path.Combine(currentExecutingFolder, ""),
                Flags = new Flags
                {
                    AllowBdeDelivery = true,
                    AllowDatabaseRetrieve = true,
                    AllowDatabaseUpdate = true,
                    AllowEaiDelivery = true,
                    AllowMyGovDelivery = true,
                    AllowPaperDelivery = true,
                    AllowSmppDelivery = true,
                    AllowSmtpDelivery = true,
                    PdfConsolidationRequired = true,
                    PsConsolidationRequired = true,
                    SendPaper = true
                }
            };
            var mockAppConfig = MockAppConfigBuilder.SetupAppConfig();
            var mockRegistry = MockPollyRegistryBuilder.SetupPollyRegistry();

            //Act
            var gsimpl = new GlobalSchedulerImplementation(mockAppConfig, db.Object, mockRegistry);
            var response = gsimpl.DoWork(message, null, db.Object, false);

            //Assert
            response.Should().NotBeNull();
            response.Jobs.Should().HaveCount(1);
            response.Jobs[0].HangfireJobServiceJobId.Should().Be("None Triggered");
            response.LogMessages.Contains("Batch created with CreateElectronicBatch");
        }
    }
}