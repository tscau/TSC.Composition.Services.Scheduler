﻿using DCS.Composition.Services.GlobalScheduler.Config;
using Moq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace DCS.Composition.Services.GlobalScheduler.UnitTests.Builders
{
    public class MockAppConfigBuilder
    {
        public static IAppConfig SetupAppConfig()
        {
            string currentExecutingFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

            Dictionary<string, AssemblyVersionDetails> versions = new Dictionary<string, AssemblyVersionDetails>
            {
                {
                    "DCS.Composition.Services.GlobalScheduler",
                    new AssemblyVersionDetails()
                    {
                        BuildNumber = "1",
                        ReleaseBuild = "1",
                        ReleaseName = "1",
                        ReleaseVersion = "1"
                    }
                }
            };

            var mockAppConfig = new Mock<IAppConfig>();
            mockAppConfig.Setup(x => x.AppSettings.BaseStagingFolder).Returns(Path.Combine(currentExecutingFolder, "[REPLACEWITHSTAGINGFOLDER]"));
            mockAppConfig.Setup(x => x.AppSettings.CorresBatchHistoryInsertSize).Returns(500);
            mockAppConfig.Setup(x => x.AppSettings.DaysToFilter).Returns(90);
            mockAppConfig.Setup(x => x.AppSettings.DelayBetweenCsvSchedules).Returns(new TimeSpan(75));
            mockAppConfig.Setup(x => x.AppSettings.Environment).Returns("DEV");
            mockAppConfig.Setup(x => x.AppSettings.HangfirePutQueueWorkerCount).Returns(1);
            mockAppConfig.Setup(x => x.AppSettings.HangfireRealtimeBatchQueueWorkerCount).Returns(1);
            mockAppConfig.Setup(x => x.AppSettings.JobFolderRootPath).Returns("");
            mockAppConfig.Setup(x => x.AppSettings.MaxRecordsPerCsvFile).Returns(1);
            mockAppConfig.Setup(x => x.AppSettings.NonElectronicStatusList).Returns(new List<int>() { 5, 30 });
            mockAppConfig.Setup(x => x.AppSettings.Server).Returns("");
            mockAppConfig.Setup(x => x.AppSettings.UserToRecordAgainst).Returns("UNITTST");
            mockAppConfig.Setup(X => X.AppSettings.Versions).Returns(versions);

            mockAppConfig.Setup(x => x.Logging.LogServiceUrl).Returns("");

            return mockAppConfig.Object;
        }
    }
}
