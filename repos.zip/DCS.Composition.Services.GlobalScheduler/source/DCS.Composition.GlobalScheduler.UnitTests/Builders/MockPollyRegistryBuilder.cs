﻿using DCS.Shared.DataAccess.Outbound.Extensions;
using Microsoft.Data.SqlClient;
using Polly;
using Polly.Contrib.WaitAndRetry;
using Polly.Registry;
using Polly.Retry;
using System;
using System.Collections.Generic;
using System.Text;

namespace DCS.Composition.Services.GlobalScheduler.UnitTests.Builders
{
    public static class MockPollyRegistryBuilder
    {
        public static IReadOnlyPolicyRegistry<string> SetupPollyRegistry()
        {
            var delay = Backoff.DecorrelatedJitterBackoffV2(medianFirstRetryDelay: TimeSpan.FromSeconds(5), retryCount: 3);
            RetryPolicy retryPolicy = Policy.Handle<SqlException>(ex => SqlServerTransientExceptionDetector.ShouldRetryOn(ex))
                    .WaitAndRetry(delay);

            PolicyRegistry registry = new PolicyRegistry()
            {
                { "SqlTimeOutPolicy",  retryPolicy}
            };
            return registry;
        }
    }
}
