﻿using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Documents;
using Moq;
using System.Collections.Generic;

namespace DCS.Composition.Services.GlobalScheduler.UnitTests.Builders
{
    public class MockDatabaseBuilder :
        IWithAndBuildSyntax,
        ICorresForNatCdSyntax,
        IHavingSchedulingPrioritySyntax,
        IAndCorresPubId

    {
        private readonly List<CorresReadyForDCSByDeliveryChannel> _corresReadyForDCSByDeliveryChannel = new List<CorresReadyForDCSByDeliveryChannel>();
        private readonly List<PubFileNatCdsAndPriorities> _pubFileNatCdsAndPriorities = new List<PubFileNatCdsAndPriorities>();

        private int _currentCount;
        private string _currentNatCd;
        private int _schedulingPriority;

        #region GetReady Implementations
        IAndCorresPubId IHavingSchedulingPrioritySyntax.HavingSchedulingPriority(int priority)
        {
            _schedulingPriority = priority;
            return this;
        }

        IWithAndBuildSyntax IAndCorresPubId.AndCorresPubId(int corresPubId)
        {
            _corresReadyForDCSByDeliveryChannel.Add(new CorresReadyForDCSByDeliveryChannel
            {
                Count = _currentCount,
                NatCd = _currentNatCd
            });

            _pubFileNatCdsAndPriorities.Add(new PubFileNatCdsAndPriorities()
            {
                SchedulingPriorityNum = _schedulingPriority,
                NATCd = _currentNatCd,
                CorresPubId = corresPubId
            });

            return this;
        }

        IHavingSchedulingPrioritySyntax ICorresForNatCdSyntax.CorresForNatCd(string natCd)
        {
            _currentNatCd = natCd;
            return this;
        }

        public ICorresForNatCdSyntax With(int count)
        {
            _currentCount = count;
            return this;
        }
        #endregion

        public Mock<IOutbound> Build()
        {
            var mockDbContext = new Mock<IOutbound>();

            // GetCorresReadyForDCSByDeliveryChannel
            mockDbContext
                .Setup(x => x.GetCorresReadyForDCSByDeliveryChannel(It.IsAny<int>(), It.IsAny<byte>(), It.IsAny<int>(), It.IsAny<bool>()))
                .Returns(_corresReadyForDCSByDeliveryChannel);

            // GetPrintStreamIdByNatCd
            mockDbContext
                .Setup(x => x.GetPrintStreamIdByNatCd(It.IsAny<string>()))
                .Returns(51);

            // CreateElectronicBatch
            mockDbContext
                .Setup(x => x.CreateElectronicBatch(It.IsAny<int>(), It.IsAny<string>()))
                .Returns(9999);

            // AddDcsBatchHistory
            mockDbContext
                .Setup(x => x.AddDcsBatchHistory(It.IsAny<DcsBatchHistory>()))
                .Returns(1);

            // GetPubFileNatCdsAndPriorities
            mockDbContext
                .Setup(x => x.GetPubFileNatCdsAndPriorities(It.IsAny<int>()))
                .Returns(_pubFileNatCdsAndPriorities);

            mockDbContext
                .Setup(x => x.CreateBulkPrintBatch(It.IsAny<short>(), It.IsAny<short>(), It.IsAny<byte>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .Returns(9998);

            mockDbContext
                .Setup(x => x.AddDcsBulkPrintBatch(It.IsAny<DcsBulkPrintBatch>()))
                .Verifiable();

            return mockDbContext;
        }
    }

    public interface IWithAndBuildSyntax
    {
        ICorresForNatCdSyntax With(int count);

        Mock<IOutbound> Build();
    }

    #region CorresRequest Interfaces
    public interface ICorresForNatCdSyntax
    {
        IHavingSchedulingPrioritySyntax CorresForNatCd(string natCd);
    }

    public interface IHavingSchedulingPrioritySyntax
    {
        IAndCorresPubId HavingSchedulingPriority(int priority);
    }

    public interface IAndCorresPubId
    {
        IWithAndBuildSyntax AndCorresPubId(int corresPubId);
    }
    #endregion


}