﻿using DCS.Composition.Services.GlobalScheduler.Common;
using DCS.Composition.Services.GlobalScheduler.UnitTests.Builders;
using DCS.Composition.Services.Shared.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace DCS.Composition.Services.GlobalScheduler.UnitTests
{
    public class RunRealtimeBatchJobTests
    {
        [Fact]
        public void CreateCampaignSchedule_Success()
        {
            var mockAppConfig = MockAppConfigBuilder.SetupAppConfig();
            var mockDbContext = new MockDatabaseBuilder()
               .With(10).CorresForNatCd("70571.12313").HavingSchedulingPriority(9).AndCorresPubId(1)
               .Build();
            var mockPolly = MockPollyRegistryBuilder.SetupPollyRegistry();
            RealTimeBatchJobParams schedule = new RealTimeBatchJobParams()
            {
                CorresId = 123456789,
                CorresStatusCode = 20,
                DeliveryChannel = 105,
                Flags = new Flags()
                {
                    AllowBdeDelivery = true,
                    AllowDatabaseRetrieve = true,
                    AllowDatabaseUpdate = true,
                    AllowEaiDelivery = true,
                    AllowMyGovDelivery = true,
                    AllowPaperDelivery = true,
                    AllowSmppDelivery = true,
                    AllowSmtpDelivery = true,
                    CorresNotInDb = true,
                    PdfConsolidationRequired = false,
                    PsConsolidationRequired = false,
                    SendPaper= false
                },
                GSScheduleId = Guid.NewGuid(),
                JGScheduleId = Guid.NewGuid(),
                NatDin  = "70571.12313"
            };

            GlobalSchedulerImplementation gsimpl = new GlobalSchedulerImplementation(mockAppConfig, mockDbContext.Object, mockPolly);


            gsimpl.RunRealtimeBatchJob(schedule, null);
        }
    }
}
