﻿using DCS.Composition.Services.GlobalScheduler.Common;
using DCS.Composition.Services.GlobalScheduler.UnitTests.Builders;
using DCS.Composition.Services.Shared.Contracts;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace DCS.Composition.Services.GlobalScheduler.UnitTests
{
    public  class CampaignMonitorTests
    {
        [Fact]
        public void CreateCampaignSchedule_Success()
        {
            var mockAppConfig = MockAppConfigBuilder.SetupAppConfig();
            var mockDbContext = new MockDatabaseBuilder()
               .With(10).CorresForNatCd("70571.12313").HavingSchedulingPriority(9).AndCorresPubId(1)
               .Build();
            var mockPolly = MockPollyRegistryBuilder.SetupPollyRegistry();
            CampaignScheduldeMsg schedule = new CampaignScheduldeMsg()
            {
                BAUContacts = new string[] { "" },
                CompositionStartDt = DateTime.Now,
                CorresStatusCode = 20,
                DeliveryChannel = 105,
                DeliveryStartDt = DateTime.Now,
                InputFile = "",
                NatCd = "",
                PubFile = "",
                RealtimeFolder = "",
                ScheduleId = "",
                Stage = 1
            };

            GlobalSchedulerImplementation gsimpl = new GlobalSchedulerImplementation(mockAppConfig, mockDbContext.Object, mockPolly);


            var response =  gsimpl.CreateCampaignSchedule(schedule, mockDbContext.Object, false, true);

            response.Should().NotBeNull();
        }
    }
}
