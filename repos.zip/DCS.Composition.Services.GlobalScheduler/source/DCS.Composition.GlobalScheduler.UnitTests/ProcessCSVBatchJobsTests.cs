﻿using DCS.Composition.Services.GlobalScheduler.Common;
using DCS.Composition.Services.GlobalScheduler.UnitTests.Builders;
using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace DCS.Composition.Services.GlobalScheduler.UnitTests
{
    public class ProcessCSVBatchJobsTests
    {
        [Fact]
        public void ProcessCSVBatchJobs_Success()
        {
            var mockAppConfig = MockAppConfigBuilder.SetupAppConfig();
            var mockDbContext = new MockDatabaseBuilder()
               .With(10).CorresForNatCd("70571.12313").HavingSchedulingPriority(9).AndCorresPubId(1)
               .Build();
            var mockPolly = MockPollyRegistryBuilder.SetupPollyRegistry();
            CsvProcessingRequest.CsvBatchJob[] jobs = new CsvProcessingRequest.CsvBatchJob[]
            {
               new CsvProcessingRequest.CsvBatchJob()
               {
                   BAUContacts = new string[]{ },
                   Id = Guid.NewGuid(),
                   InputFile = "",
                   NatCd = "",
                   ScheduledDateTime = DateTime.Now
               }
            };

            GlobalSchedulerImplementation gsimpl = new GlobalSchedulerImplementation(mockAppConfig, mockDbContext.Object, mockPolly);

            var response = gsimpl.ProcessCSVBatchJobs(jobs, mockDbContext.Object, false, true);

            response.Should().NotBeNull();
        }
    }
}
