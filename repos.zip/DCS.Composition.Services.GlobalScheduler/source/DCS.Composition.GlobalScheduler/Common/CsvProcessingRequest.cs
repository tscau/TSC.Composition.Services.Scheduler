﻿using System;

namespace DCS.Composition.Services.GlobalScheduler.Common
{
    /// <summary>
    /// </summary>
    public class CsvProcessingRequest
    {
        /// <summary>
        /// </summary>
        public CsvBatchJob[] CsvBatchJobs { get; set; } = Array.Empty<CsvBatchJob>();

        /// <summary>
        /// </summary>
        public class CsvBatchJob
        {
            /// <summary>
            /// Guid used to identifier this job
            /// </summary>
            public Guid Id { get; set; }

            /// <summary>
            /// The path of the uploaded csv file to process
            /// </summary>
            public string InputFile { get; set; }

            /// <summary>
            /// A list of email address to notify if processing fails
            /// </summary>
            public string[] BAUContacts { get; set; }

            /// <summary>
            /// The NatCd of the template to be processed
            /// </summary>
            public string NatCd { get; set; }

            /// <summary>
            /// The date and time to schedule this batch
            /// </summary>
            public DateTime? ScheduledDateTime { get; set; }
        }
    }
}
