﻿using DCS.Composition.Services.GlobalScheduler.Config;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.GlobalScheduler;
using DCS.Composition.Services.Shared.JobService;
using DCS.Logging.Shared.Common;
using DCS.Logging.Shared.Infrastructure;
using DCS.PostComposition.Services.Shared.Contracts;
using DCS.PostComposition.Services.Shared.Interfaces;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Database;
using DCS.Shared.DataAccess.Outbound.Documents;
using DCS.Shared.DataAccess.Outbound.Enums;
using Hangfire;
using Hangfire.JobsLogger;
using Hangfire.Server;
using Hangfire.SqlServer;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Polly.Registry;
using Polly.Retry;
using Serilog.Context;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using DcsBatchType = DCS.Shared.DataAccess.Outbound.Enums.DcsBatchType;

namespace DCS.Composition.Services.GlobalScheduler.Common
{
    /// <summary>
    /// Class to do the bulk of the Global scheduler work
    /// </summary>
    public class GlobalSchedulerImplementation : IGlobalScheduler
    {
        readonly IAppConfig _appConfig;
        private readonly IOutbound _db;
        const int DEFAULT_NUMBER_PER_SCHEDULE = 20000;
        private const string DEFAULT_USER_TO_RECORD_AGAINST = "GLBLSCHD";

        int batchId = 0;
        readonly int daysToFilterBy;
        readonly string userToRecordAgainst;
        readonly IReadOnlyPolicyRegistry<string> _registry;
        readonly RetryPolicy _retryPolicy;
        private List<PubFileNatCdsAndPriorities> cachedTemplates;

        /// <summary>
        /// Constructor that sets the logger and the default days to filter by and user
        /// </summary>
        /// <param name="appConfig"></param>
        /// <param name="db"></param>
        /// <param name="registry"></param>
        public GlobalSchedulerImplementation(IAppConfig appConfig, IOutbound db, IReadOnlyPolicyRegistry<string> registry)
        {
            _appConfig = appConfig;
            this._db = db;
            AppLog.Debug()(0, "Testing Debug Logging");
            daysToFilterBy = _appConfig.AppSettings.DaysToFilter;

            userToRecordAgainst = _appConfig.AppSettings.UserToRecordAgainst;

            if (string.IsNullOrWhiteSpace(userToRecordAgainst))
            {
                userToRecordAgainst = DEFAULT_USER_TO_RECORD_AGAINST;
            }
            _registry = registry;
            _retryPolicy = _registry.Get<RetryPolicy>("SqlTimeOutPolicy");
        }

        /// <summary>
        /// Method that is called when Hangfire wants us to do something
        /// </summary>
        /// <param name="message">The message passed from Hangfire</param>
        /// <param name="context">The Hangfire PerformContext.</param>
        [JobDisplayName("GlobalScheduler RunSchedule - {0}")]
        [DisplayName("GlobalScheduler RunSchedule - {0}")]
        public void RunSchedule(CompositionMsg message, PerformContext context)
        {
            IOutbound db = new DbContext(() => new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen));

            _ = DoWork(message, context, db, true, true);
        }

        /// <summary>
        /// Method that is called when Hangfire wants us to do something
        /// </summary>
        /// <param name="message">The message passed from Hangfire</param>
        /// <param name="context">The Hangfire PerformContext.</param>
        [JobDisplayName("GlobalScheduler RunScheduleByNatCd - {0}")]
        [DisplayName("GlobalScheduler RunScheduleByNatCd - {0}")]
        public void RunScheduleByNatCd(CompositionMsg message, PerformContext context)
        {
            IOutbound db = new DbContext(() => new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen));
            //Check if there is more than 1 nat din - throw error if so
            if (message.NatDins == null || message.NatDins.Count > 1)
            {
                throw new ArgumentException("An invalid NatCd was sent to the RunScheduleRunScheduleByNatCd methid. Expected only 1 NatCd");
            }
            _ = DoWork(message, context, db, true, true, message.NatDins[0]);
        }

        /// <summary>
        /// Method to actually do the work
        /// </summary>
        /// <param name="message"></param>
        /// <param name="context"></param>
        /// <param name="triggerJobService"></param>
        /// <param name="updateDb"></param>
        /// <param name="natCd"></param>
        /// <param name="db"></param>
        /// <returns></returns>
        public DoWorkResponse DoWork(CompositionMsg message, PerformContext context, IOutbound db, bool triggerJobService = true, bool updateDb = true, string natCd = "")
        {

            Guid jobGroupScheduleId = Guid.NewGuid();
            message.JGScheduleId = jobGroupScheduleId;
            DCSLogMsg logMsg = new DCSLogMsg
            {
                Application = "DCS.Composition.Services.GlobalScheduler",
                Server = _appConfig.AppSettings.Server,
                ApplicationVersion = _appConfig.AppSettings.Versions[Assembly.GetExecutingAssembly().GetName().Name].ReleaseBuild,
                GSScheduleId = message.GSScheduleId,
                JGScheduleId = jobGroupScheduleId,
                DeliveryChannel = message.DeliveryChannel,
                NatDins = string.Join(",", message.NatDins),
                BatchId = message.BatchId,
                LogDatetime = DateTime.Now,
                LogLevel = LogLevel.Information
            };
            string messageAsJson = JsonSerializer.Serialize(message);

            DoWorkResponse doWorkResponse = new DoWorkResponse
            {
                Jobs = new List<GSJob>(),
                LogMessages = new List<string>(),
                BatchIds = new List<long>(),
                NumberProcessed = 0
            };


            if (context != null)
            {
                context.LogInformation($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Processing {messageAsJson}");
            }


            //WARNING: TERRIBLE HACK AHEAD - THIS NEEDS TO BE REFACTORED AS SOON AS POSSIBLE - OPSPORTAL NEEDS TO STORE THE STAGING FOLDER FOR THE JOB AND SET IsStageFOrConsolidation
            //Schedule Name in DcsCOrresSchedule MUST be in this format: short name - staging folder path. e.g. Consolidation - 51_9.5-DoubleByte\System
            try
            {
                if (message.IsStageForConsolidationJob)
                {

                    GSJob gsJob = new GSJob
                    {
                        NatCds = string.Join(",", message.NatDins),
                        NumberToProcess = 1
                    };

                    //Create a batch id using the status as the print stream
                    if (updateDb)
                    {
                        batchId =  _retryPolicy.Execute(() => db.CreateBulkPrintBatch(Convert.ToInt16(message.ConsolidationMsg.PrintStream), null, 2, "DCSBP", "BP", _appConfig.AppSettings.UserToRecordAgainst));
                        AppLog.Info()(batchId, "Batch created with CreateBulkPrintBatch");
                        doWorkResponse.LogMessages.Add("Batch created with CreateBulkPrintBatch");
                       
                        AppLog.Info()(0, "Creating batch {batchId} for type {batchType} and channel {deliveryChannel}", batchId, DcsBatchType.Batch, message.DeliveryChannel);

                        _retryPolicy.Execute(() => db.AddDcsBulkPrintBatch(new DcsBulkPrintBatch()
                        {
                            BulkPrintBatchId = batchId,
                            CreatedId = userToRecordAgainst,
                            DcsBatchHistoryCodesId = (int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerConsolidationStarted,
                            DcsBatchTypeId = (int)DcsBatchType.PaperConsolidationBatch,
                            DeliveryChannelCd = message.DeliveryChannel
                        })
                        );
                    }
                    else
                    {
                        batchId = -1;
                    }

                    logMsg.BatchId = batchId;
                    message.BatchId = batchId;
                    if (updateDb && batchId > 0)
                    {
                        UpdateBatchHistory(db, message, context, DcsBatchHistoryStatusEnum.CompGlobalSchedulerConsolidationStarted, _appConfig.AppSettings.UserToRecordAgainst);
                    }

                    doWorkResponse.BatchIds.Add(batchId);
                    PostCompositionMsg stageForConsolMsg = new PostCompositionMsg();
                    //Does this need to create a batch folder????
                    string jobPath = CreateBatchFolder(batchId);

                    if (string.IsNullOrWhiteSpace(_appConfig.AppSettings.BaseStagingFolder))
                    {
                        //log error and return
                        using (LogContext.PushProperty("BatchId", batchId))
                        {
                            AppLog.Error()(null, batchId, "BaseStagingFolder in config is empty. Cannot be empty");
                        }
                        doWorkResponse.LogMessages.Add("BaseStagingFolder in config is empty. Cannot be empty");
                        doWorkResponse.Success = false;

                        if (updateDb && batchId > 0)
                        {
                            UpdateBatchHistory(db, message, context, DcsBatchHistoryStatusEnum.CompGlobalSchedulerConsolidationFailed, _appConfig.AppSettings.UserToRecordAgainst);
                        }
                    }

                    stageForConsolMsg.BatchId = batchId;
                    stageForConsolMsg.CorresStatusCode = message.CorresStatusCode;
                    stageForConsolMsg.DeliveryChannel = message.DeliveryChannel;
                    stageForConsolMsg.GSScheduleID = message.GSScheduleId;
                    stageForConsolMsg.JGScheduleId = message.JGScheduleId;
                    stageForConsolMsg.JobPath = jobPath;
                    stageForConsolMsg.NatDins = message.NatDins;
                    stageForConsolMsg.StagingFolder = _appConfig.AppSettings.BaseStagingFolder.Replace("[REPLACEWITHSTAGINGFOLDER]", message.ConsolidationMsg.StagingFolderName);
                    stageForConsolMsg.IsPdfConsolidation = message.ConsolidationMsg.IsPdfConsolidation;
                    stageForConsolMsg.IsPsConsolidation = message.ConsolidationMsg.IsPsConsolidation;
                    stageForConsolMsg.PrintStream = message.ConsolidationMsg.PrintStream;
                    stageForConsolMsg.Flags = new PostComposition.Services.Shared.Common.Flags
                    {
                        AllowBdeDelivery = message.Flags.AllowBdeDelivery,
                        AllowDatabaseRetrieve = message.Flags.AllowDatabaseRetrieve,
                        AllowDatabaseUpdate = message.Flags.AllowDatabaseUpdate,
                        AllowEaiDelivery = message.Flags.AllowEaiDelivery,
                        AllowMyGovDelivery = message.Flags.AllowMyGovDelivery,
                        AllowPaperDelivery = message.Flags.AllowPaperDelivery,
                        AllowSmppDelivery = message.Flags.AllowSmppDelivery,
                        AllowSmtpDelivery = message.Flags.AllowSmtpDelivery,
                        PdfConsolidationRequired = message.Flags.PdfConsolidationRequired,
                        PsConsolidationRequired = message.Flags.PsConsolidationRequired,
                        SendPaper = message.Flags.SendPaper
                    };
                    if (stageForConsolMsg.IsPdfConsolidation.HasValue && stageForConsolMsg.IsPdfConsolidation.Value)
                    {
                        stageForConsolMsg.PaperDeliveryType = "PDF";
                    }
                    else
                    {
                        stageForConsolMsg.PaperDeliveryType = "PS";
                    }

                    if (triggerJobService)
                    {
                        SqlServerStorage deliveryJobStorage = new SqlServerStorage(_appConfig.ConnectionStrings.HangfireDeliveryDb);
                        BackgroundJobClient cli = new BackgroundJobClient(deliveryJobStorage);
                        gsJob.HangfireJobServiceJobId = cli.Enqueue<IConsolidationJobService>(x => x.Start(stageForConsolMsg, null));
                    }
                    else
                    {
                        gsJob.HangfireJobServiceJobId = "None Triggered - triggerJobService set to false";
                    }

                    doWorkResponse.Jobs.Add(gsJob);
                    doWorkResponse.Success = true;

                    if (updateDb && batchId > 0)
                    {
                        UpdateBatchHistory(db, message, context, DcsBatchHistoryStatusEnum.CompGlobalSchedulerConsolidationCompleted, _appConfig.AppSettings.UserToRecordAgainst);
                    }

                    return doWorkResponse;
                }
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, "Error occured scheduling stage for consolidation - {message}; {stacktrace}", ex.Message, ex.StackTrace);
                doWorkResponse.LogMessages.Add(string.Format("Error occured scheduling stage for consolidation - {0}; {1}", ex.Message, ex.StackTrace));
                doWorkResponse.Success = false;

                if (updateDb && batchId > 0)
                {
                    UpdateBatchHistory(db, message, context, DcsBatchHistoryStatusEnum.CompGlobalSchedulerConsolidationFailed, _appConfig.AppSettings.UserToRecordAgainst);
                }
                return doWorkResponse;
            }

            //END HACK WARNING

            cachedTemplates = _retryPolicy.Execute(() => db.GetPubFileNatCdsAndPriorities(message.CorresStatusCode));

            logMsg.Message = $"{_appConfig.AppSettings.Server} - Processing {messageAsJson}";
            doWorkResponse.LogMessages.Add($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Processing {messageAsJson}");
            AppLog.Info()(message.BatchId, "Processing {messageAsJson}", messageAsJson);
            logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{_appConfig.AppSettings.Server} - Processing {messageAsJson}", null);

            try
            {
                if (message.NumberPerSchedule == 0)
                {
                    message.NumberPerSchedule = DEFAULT_NUMBER_PER_SCHEDULE;
                }
                int currentNumberProcessed = 0;

                //Get the list of Corres ready to process

                var natDins = message.NatDins == null ? "" : string.Join(',', message.NatDins);
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Getting list of corres for NatCds {natDins} and CorresStatusCode {message.CorresStatusCode}");

                List<CorresReadyForDCSByDeliveryChannel> results = new List<CorresReadyForDCSByDeliveryChannel>();
                if (string.IsNullOrEmpty(natCd))
                {
                    // NOTE: Have to cast to byte for status because DBCC forced Sp to be TINYINT - this is techdebt --> CompositionMsg should be changed to byte
                    // but that will affect a number of applications and require re-deploy of all Composition (+OpsPortal) applications. Also due to DBCC being VERY 
                    // inconsistent with their requirements we now have a number of stored procedures that use use different types for the Status code.
                    bool electronicCorres;
                    if (_appConfig.AppSettings.NonElectronicStatusList.Contains(message.DeliveryChannel ))
                    {
                        electronicCorres = false;
                        
                    }
                    else
                    {
                        electronicCorres = true;
                    }
                    results = _retryPolicy.Execute(() => db.GetCorresReadyForDCSByDeliveryChannel(message.DeliveryChannel, (byte)message.CorresStatusCode, daysToFilterBy, electronicCorres));
                }
                else
                {
                    results = _retryPolicy.Execute(() => db.GetCorresReadyForDCSByNatCd(message.DeliveryChannel, natCd, message.CorresStatusCode, daysToFilterBy));
                }

                //Order the results by priority
                if (context != null)
                {
                    context.LogInformation($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - {results.Count} - Number Found to Process");
                }
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - {results.Count} - Number Found to Process");
                AppLog.Info()(message.BatchId, "Number Found to Process: {Count}", results.Count);
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{_appConfig.AppSettings.Server} - Number Found to Process: {results.Count}", null);

                //Get the count per grouping
                // Group the nat/cds by pub file name and priority
                Dictionary<string, PubFileDetails> templatesToProcess = new Dictionary<string, PubFileDetails>();

                foreach (CorresReadyForDCSByDeliveryChannel natCdReady in results)
                {
                    //Get the pub file name from the cached list and add to the list of pub files to process
                    AppLog.Info()(message.BatchId, "Looking for {NatCd} in cachedTemplates", natCdReady.NatCd);
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $" - Looking for {natCdReady.NatCd} in cached templates", null);
                    var t = (from x in cachedTemplates where x.NATCd == natCdReady.NatCd select x).FirstOrDefault();
                    if (t == null)
                    {
                        //Log an error - pub file not found - log the NatDin that is being looked for
                        doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Error - NatDin from OutboundDB not found in CorresPub/CorresPackage tables - {natCdReady.NatCd}");
                        logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Error, $" - Error - NatDin from OutboundDB not found in CorresPub/CorresPackage tables - {natCdReady.NatCd}", null);
                        doWorkResponse.Success = false;
                        continue;
                    }
                    if (templatesToProcess.ContainsKey(t.CorresPubId.ToString()))
                    {
                        if (!templatesToProcess[t.CorresPubId.ToString()].NatCds.ContainsKey(t.NATCd))
                        {
                            templatesToProcess[t.CorresPubId.ToString()].NatCds.Add(t.NATCd, natCdReady.Count);
                        }
                    }
                    else
                    {
                        PubFileDetails details = new PubFileDetails
                        {
                            Name = t.PubFileNm,
                            Priority = t.SchedulingPriorityNum,
                            NatCds = new Dictionary<string, int>(),
                            CorresPubId = t.CorresPubId
                        };
                        details.NatCds.Add(t.NATCd, natCdReady.Count);
                        templatesToProcess.Add(t.CorresPubId.ToString(), details);
                    }
                }

                DateTime nextRun = DateTime.Now;
                //Order by priority - 9 first then 1
                for (int i = 9; i >= 0; i--)
                {
                    //Get all a the 
                    var t = from x in templatesToProcess where x.Value.Priority == i select x;
                    if (currentNumberProcessed <= message.NumberPerSchedule)
                    {
                        foreach (KeyValuePair<string, PubFileDetails> pubFileDetail in t)
                        {
                            if (pubFileDetail.Value.Priority == 0)
                            {
                                //Throw a warning out saying this template has a priority of 0
                                AppLog.Warning()(0, $"Pubfile has a scheduling priority of 0 - {string.Join(",", pubFileDetail.Value.NatCds)} - PubFile Name {pubFileDetail.Value.Name}");
                            }
                            var maxRequestsAllowedToBeProcessed = message.NumberPerSchedule - currentNumberProcessed;

                            List<string> natCdsList = new List<string>();

                            //Get all the NatCds as a string and combined count
                            int numberOfRequestForCurrentPriority = 0;
                            foreach (KeyValuePair<string, int> item in pubFileDetail.Value.NatCds)
                            {
                                var numberOfRequestsRemaining = maxRequestsAllowedToBeProcessed - numberOfRequestForCurrentPriority;
                                if (numberOfRequestsRemaining == 0) break;

                                var numberOfRequestsForThisNatCd = item.Value;
                                var numberOfRequestsAllowedForThisNatCd = Math.Min(numberOfRequestsForThisNatCd, numberOfRequestsRemaining);

                                natCdsList.Add(item.Key);
                                numberOfRequestForCurrentPriority += numberOfRequestsAllowedForThisNatCd;

                            }

                            //Need to break out of the outer for loop as we have exhausted the number we are doing for this schedule
                            if (currentNumberProcessed >= message.NumberPerSchedule) break;

                            string natCds = string.Join(",", natCdsList);

                            //Now have the list of nat/cds that will be used
                            logMsg.Message = $"{_appConfig.AppSettings.Server} - Creating Batches for {natCds}";
                            logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{_appConfig.AppSettings.Server} - Number Found to Process: {results.Count}", null);

                            doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Creating Batches for {natCds}");
                            GSJob gsJob = new GSJob
                            {
                                NatCds = natCds,
                                NumberToProcess = numberOfRequestForCurrentPriority
                            };

                            //Get the print streamid for the natcd/pub file
                            int printStreamId = _retryPolicy.Execute(() => db.GetPrintStreamIdByNatCd(natCdsList[0]));
                            if (updateDb)
                            {
                                //Use the CreateBulkPrintBatch for paper and use CreateElectronicBatch for non-paper
                                if (_appConfig.AppSettings.NonElectronicStatusList.Contains(message.DeliveryChannel))
                                {

                                    batchId = _retryPolicy.Execute(() => db.CreateBulkPrintBatch(Convert.ToInt16(printStreamId), null, 2, "DCSBP", "BP", _appConfig.AppSettings.UserToRecordAgainst));
                                    doWorkResponse.LogMessages.Add($"Batch created with CreateBulkPrintBatch");
                                    AppLog.Info()(batchId, "Creating batch {batchId} for type {batchType} and channel {deliveryChannel} using CreateBulkPrintBatch", DcsBatchType.Batch, message.DeliveryChannel);

                                } else
                                {
                                    batchId = _retryPolicy.Execute(() => db.CreateElectronicBatch(printStreamId, userToRecordAgainst));
                                    doWorkResponse.LogMessages.Add("Batch created with CreateElectronicBatch");
                                    AppLog.Info()(batchId, "Creating batch {batchId} for type {batchType} and channel {deliveryChannel} using CreateElectronicBatch", DcsBatchType.Batch, message.DeliveryChannel);
                                }

                                _retryPolicy.Execute(() => db.AddDcsBulkPrintBatch(new DcsBulkPrintBatch()
                                {
                                    BulkPrintBatchId = batchId,
                                    CreatedId = userToRecordAgainst,
                                    DcsBatchHistoryCodesId = (int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerStarted,
                                    DcsBatchTypeId = (int)DcsBatchType.Batch,
                                    DeliveryChannelCd = message.DeliveryChannel,
                                    CorresPubId = pubFileDetail.Value.CorresPubId
                                }));
                            }
                            else
                            {
                                batchId = -1;
                            }

                            doWorkResponse.BatchIds.Add(batchId);
                            logMsg.BatchId = batchId;
                            message.BatchId = batchId;
                            //Add a BatchHistory record
                            int result = 0;
                            doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Adding entry in DcsBatchHistory for {batchId} with GlobalSchedulerStarted - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerStarted}");
                            if (updateDb)
                            {
                                UpdateBatchHistory(db, message, context, DcsBatchHistoryStatusEnum.CompGlobalSchedulerStarted, _appConfig.AppSettings.UserToRecordAgainst);
                                using (LogContext.PushProperty("BatchId", batchId))
                                {
                                    logMsg.Message = $"{_appConfig.AppSettings.Server} - Calling UpdateCorresRequestStatusAndBatchByDeliveryChannel with parameters: {natCds}, {message.CorresStatusCode}, {message.DeliveryChannel}, {numberOfRequestForCurrentPriority}, {batchId}, {DateTime.Now.AddDays(-1 * daysToFilterBy)}, {DateTime.Now}, {daysToFilterBy} ";
                                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logMsg.Message, null);
                                }

                                result = _retryPolicy.Execute(() => db.UpdateCorresRequestStatusAndBatchByDeliveryChannel(natCds, message.CorresStatusCode.ToString(), message.DeliveryChannel, numberOfRequestForCurrentPriority, batchId, DateTime.Now.AddDays(-1 * daysToFilterBy), DateTime.Now, daysToFilterBy));
                                _retryPolicy.Execute(() => db.AddCorresBatchHistory(batchId, _appConfig.AppSettings.CorresBatchHistoryInsertSize));
                            }

                            //Logging
                            if (context != null)
                            {
                                context.LogInformation($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - {result} records added to batch {batchId} ");
                            }
                            logMsg.Message = $"{_appConfig.AppSettings.Server} - {result} records added to batch {batchId} ";
                            using (LogContext.PushProperty("BatchId", batchId))
                            {
                                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logMsg.Message, null);
                            }

                            doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - {result} records added to batch {batchId} ");

                            Flags _flags = new Flags
                            {
                                AllowBdeDelivery = message.Flags.AllowBdeDelivery,
                                AllowDatabaseRetrieve = message.Flags.AllowDatabaseRetrieve,
                                AllowDatabaseUpdate = message.Flags.AllowDatabaseUpdate,
                                AllowEaiDelivery = message.Flags.AllowEaiDelivery,
                                AllowMyGovDelivery = message.Flags.AllowMyGovDelivery,
                                AllowPaperDelivery = message.Flags.AllowPaperDelivery,
                                AllowSmppDelivery = message.Flags.AllowSmppDelivery,
                                AllowSmtpDelivery = message.Flags.AllowSmtpDelivery,
                                PdfConsolidationRequired = message.Flags.PdfConsolidationRequired,
                                PsConsolidationRequired = message.Flags.PsConsolidationRequired,
                                SendPaper = message.Flags.SendPaper
                            };

                            CompositionMsg jobServiceParams = new CompositionMsg
                            {
                                BatchId = batchId,
                                JobPath = string.Empty,
                                GSScheduleId = message.GSScheduleId,
                                DeliveryChannel = message.DeliveryChannel,
                                NatDins = natCdsList,
                                NumberPerSchedule = message.NumberPerSchedule,
                                Operation = message.Operation,
                                CorresStatusCode = message.CorresStatusCode,
                                JGScheduleId = jobGroupScheduleId,
                                Flags = _flags
                            };


                            string inputMessageAsJson = JsonSerializer.Serialize(jobServiceParams);

                            //Logging
                            if (context != null)
                            {
                                context.LogInformation($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Creating JobService for {inputMessageAsJson}");
                            }
                            logMsg.Message = $"{_appConfig.AppSettings.Server} - Creating JobService for {inputMessageAsJson}";
                            using (LogContext.PushProperty("BatchId", batchId))
                            {
                                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logMsg.Message, null);
                            }

                            doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Creating JobService for {inputMessageAsJson}");

                            gsJob.MessaageToSendToJobService = jobServiceParams;
                            if (triggerJobService)
                            {
                                gsJob.HangfireJobServiceJobId = BackgroundJob.Schedule<IJobService>(x => x.Start(jobServiceParams, null), nextRun);
                            }
                            else
                            {
                                gsJob.HangfireJobServiceJobId = "None Triggered";
                            }

                            gsJob.HangfireScheduleDateTime = nextRun;

                            doWorkResponse.Jobs.Add(gsJob);
                            //Logging
                            logMsg.Message = $"{_appConfig.AppSettings.Server} - HF Job - {gsJob.ToJson()}";
                            using (LogContext.PushProperty("BatchId", batchId))
                            {
                                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logMsg.Message, null);
                            }
                            doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - HF Job - {gsJob.ToJson()}");

                            if (context != null)
                            {
                                context.LogInformation($"{_appConfig.AppSettings.Server} - HF Job - {gsJob.ToJson()}");
                            }

                            nextRun = nextRun.AddSeconds(15);
                            currentNumberProcessed += numberOfRequestForCurrentPriority;
                            if (updateDb)
                            {
                                UpdateBatchHistory(db, message, context, DcsBatchHistoryStatusEnum.CompGlobalSchedulerCompleted, _appConfig.AppSettings.UserToRecordAgainst);
                            }
                        }
                    }
                }
                //Add a BatchHistory record
                doWorkResponse.NumberProcessed = currentNumberProcessed;
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Number Processed for {messageAsJson} = {currentNumberProcessed}");
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Adding entry in DcsBatchHistory for {batchId} with GlobalSchedulerStarted - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerCompleted}");


                return doWorkResponse;

            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, "Error occured processing {messageAsJson} - {message}; {stacktrace}",messageAsJson, ex.Message, ex.StackTrace);
                if (context != null)
                {
                    context.LogError($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Exception Occured - {ex.Message} - {ex.StackTrace}");
                }
                logMsg.Message = $"{_appConfig.AppSettings.Server} - Exception Occured - {ex.Message} - {ex.StackTrace}";
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logMsg.Message, ex);
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Exception Occured - {ex.Message} - {ex.StackTrace}");
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Adding entry in DcsBatchHistory for {batchId} with GlobalSchedulerStarted - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerFailed}");
                if (updateDb)
                {
                    UpdateBatchHistory(db, message, context, DcsBatchHistoryStatusEnum.CompGlobalSchedulerFailed, _appConfig.AppSettings.UserToRecordAgainst);
                }
                throw;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bdvRequest">
        /// Object that contains the following:
        ///     betIds          - The list of BET IDs to process
        ///     deliveryChannel - The Deliveyr Channel</param>
        ///     Status          - The satatus of the corres as it is int he DB currently. Defaults to 12 if not set
        ///     StatusToProcess - The Status that will be used to retrieve the Vars details. Essentially the status that we would have used if this was a live job
        ///     NatCd           - The Nat/Cd to that the corres is for
        ///     Flags           - The flags.
        ///     RunAt           - the DateTimeOffeset to run the task at
        ///     CallHangFire    - Whether to call hangfire. Defaults to True
        /// <returns></returns>
        public DoWorkResponse RunBdv(ProcessBdvRequest bdvRequest)
        {
            DoWorkResponse doWorkResponse = new DoWorkResponse
            {
                BatchIds = new List<long>(),
                LogMessages = new List<string>(),
                Jobs = new List<GSJob>()
            };

            try
            {
                cachedTemplates = _retryPolicy.Execute(() => _db.GetPubFileNatCdsAndPriorities(bdvRequest.StatusToProcess));
                var t = (from x in cachedTemplates where x.NATCd == bdvRequest.NatCd select x).FirstOrDefault();
                if (t == null)
                {
                    //Log an error - pub file not found - log the NatDin that is being looked for
                    doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Error - NatDin from OutboundDB not found in CorresPub/CorresPackage tables - {bdvRequest.NatCd}");
                    doWorkResponse.Success = false;
                    return doWorkResponse;
                }
                //Create a new BatchId
                int printStreamId = _retryPolicy.Execute(() => _db.GetPrintStreamIdByNatCd(bdvRequest.NatCd));

                if (_appConfig.AppSettings.NonElectronicStatusList.Contains(bdvRequest.DeliveryChannel))
                {

                    batchId = _retryPolicy.Execute(() => _db.CreateBulkPrintBatch(Convert.ToInt16(printStreamId), null, 2, "DCSBP", "BP", _appConfig.AppSettings.UserToRecordAgainst));
                    doWorkResponse.LogMessages.Add($"Batch created with CreateBulkPrintBatch");
                    AppLog.Info()(batchId, "Creating batch {batchId} for type {batchType} and channel {deliveryChannel} using CreateBulkPrintBatch", DcsBatchType.Batch, bdvRequest.DeliveryChannel);

                }
                else
                {
                    batchId = _retryPolicy.Execute(() => _db.CreateElectronicBatch(printStreamId, userToRecordAgainst));
                    doWorkResponse.LogMessages.Add("Batch created with CreateElectronicBatch");
                    AppLog.Info()(batchId, "Creating batch {batchId} for type {batchType} and channel {deliveryChannel} using CreateElectronicBatch", DcsBatchType.Batch, bdvRequest.DeliveryChannel);
                }

                UpdateBatchHistoryForBdv(_db, batchId, DcsBatchHistoryStatusEnum.CompGlobalSchedulerBAUStarted, _appConfig.AppSettings.UserToRecordAgainst);

                AppLog.Info()(batchId, "Creating batch {batchId} for type {batchType} and channel {deliveryChannel}", DcsBatchType.Batch, bdvRequest.DeliveryChannel);
                _retryPolicy.Execute(() => _db.AddDcsBulkPrintBatch(new DcsBulkPrintBatch()
                {
                    BulkPrintBatchId = batchId,
                    CreatedId = userToRecordAgainst,
                    DcsBatchHistoryCodesId = (int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerStarted,
                    DcsBatchTypeId = (int)DcsBatchType.BAUBatch,
                    DeliveryChannelCd = bdvRequest.DeliveryChannel,
                    CorresPubId = t.CorresPubId
                }));
                //Add the batchid to the set of BETId's selected
                UpdateBatchByBetId updateBatchByBetId = new UpdateBatchByBetId
                {
                    BatchID = batchId
                };
                DataTable dt = new DataTable();
                dt.Columns.Add("CorresId", typeof(Int64));

                foreach (long corresId in bdvRequest.BetIds)
                {
                    DataRow row = dt.NewRow();
                    row["CorresId"] = corresId;
                    dt.Rows.Add(row);
                }

                updateBatchByBetId.BetIds = dt;
                updateBatchByBetId.StatusCode = bdvRequest.Status;
                updateBatchByBetId.NatCd = bdvRequest.NatCd;

                //Update the bet ids to the new batch id
                _retryPolicy.Execute(() => _db.UpdateBatchByBetId(updateBatchByBetId));
                _retryPolicy.Execute(() => _db.AddCorresBatchHistory(batchId, _appConfig.AppSettings.CorresBatchHistoryInsertSize));

                //Submit new job to JobService using HF
                CompositionMsg jobServiceParams = new CompositionMsg
                {
                    BatchId = batchId,
                    JobPath = string.Empty,
                    GSScheduleId = Guid.NewGuid(),
                    DeliveryChannel = bdvRequest.DeliveryChannel,
                    NatDins = new List<string> { bdvRequest.NatCd },
                    NumberPerSchedule = bdvRequest.BetIds.Count,
                    Operation = "",
                    CorresStatusCode = bdvRequest.StatusToProcess,
                    JGScheduleId = Guid.NewGuid(),
                    Flags = bdvRequest.Flags
                };


                string inputMessageAsJson = JsonSerializer.Serialize(jobServiceParams);

                //Logging
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Creating JobService for {inputMessageAsJson}");
                AppLog.Info()(batchId, "Creating BDV JobService for {inputMessageAsJson}", inputMessageAsJson);

                string hangfireJobServiceJobId = string.Empty;
                if (bdvRequest.CallHangfire)
                {
                    hangfireJobServiceJobId = BackgroundJob.Schedule<IJobService>(x => x.Start(jobServiceParams, null), bdvRequest.RunAt); 
                } else
                {
                    hangfireJobServiceJobId = "0";
                }
                
                doWorkResponse.BatchIds.Add(batchId);
                doWorkResponse.Jobs.Add(new GSJob()
                {
                    HangfireJobServiceJobId = hangfireJobServiceJobId,
                    MessaageToSendToJobService = jobServiceParams,
                    NatCds = bdvRequest.NatCd,
                    NumberToProcess = bdvRequest.BetIds.Count
                });

                UpdateBatchHistoryForBdv(_db, batchId, DcsBatchHistoryStatusEnum.CompGlobalSchedulerBAUCompleted, _appConfig.AppSettings.UserToRecordAgainst);

                return doWorkResponse;
            }
            catch(Exception ex)
            {
                UpdateBatchHistoryForBdv(_db, batchId, DcsBatchHistoryStatusEnum.CompGlobalSchedulerBAUFailed, _appConfig.AppSettings.UserToRecordAgainst);
                AppLog.Error()(ex, batchId, ex.Message);
                throw;
            }
        }

        
        /// <summary>
        /// Method to actually do the work
        /// </summary>
        /// <returns></returns>
        public CsvProcessingResponse ProcessCSVBatchJobs(CsvProcessingRequest.CsvBatchJob[] messages, IOutbound db, bool triggerJobService = true, bool updateDb = true)
        {
            var response = new CsvProcessingResponse();

            var logMessage = new DCSLogMsg
            {
                Application = "DCS.Composition.Services.GlobalScheduler",
                Server = _appConfig.AppSettings.Server,
                ApplicationVersion = _appConfig.AppSettings.Versions[Assembly.GetExecutingAssembly().GetName().Name].ReleaseBuild,
                DeliveryChannel = 0,
                BatchId = 0,
                LogDatetime = DateTime.Now,
                LogLevel = LogLevel.Information
            };

            try
            {
                foreach (var message in messages)
                {
                    logMessage.NatDins = message.NatCd;
                    logMessage.GSScheduleId = Guid.NewGuid();
                    logMessage.JGScheduleId = Guid.NewGuid();

                    var printStreamId = _retryPolicy.Execute(() => db.GetPrintStreamIdByNatCd(message.NatCd));

                    if (updateDb)
                    {
                        batchId = _retryPolicy.Execute(() => db.CreateBulkPrintBatch(Convert.ToInt16(printStreamId), null, 2, "DCSBP", "BP", _appConfig.AppSettings.UserToRecordAgainst));

                        AppLog.Info()(batchId, "Creating batch {batchId} for type {batchType} using CreateBulkPrintBatch", DcsBatchType.OpsPortalCSVBatch);

                        _retryPolicy.Execute(() => db.AddDcsBulkPrintBatch(new DcsBulkPrintBatch()
                        {
                            BulkPrintBatchId = batchId,
                            CreatedId = userToRecordAgainst,
                            DcsBatchHistoryCodesId = (int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerCSVStarted,
                            DcsBatchTypeId = (int)DcsBatchType.OpsPortalCSVBatch
                        }));
                    }
                    else
                    {
                        batchId = -1;
                    }

                    logMessage.BatchId = batchId;

                    log($"Creating batch {batchId} for file {message.InputFile}");

                    if (updateDb)
                    {
                        log($"Adding entry in DcsBatchHistory for {batchId} with GlobalSchedulerStarted - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerCSVStarted}");
                        UpdateBatchHistoryForCSV(db, logMessage.GSScheduleId, logMessage.JGScheduleId, batchId, DcsBatchHistoryStatusEnum.CompGlobalSchedulerCSVStarted);
                    }

                    var jobServiceMessage = new CompositionMsg
                    {
                        BatchId = batchId,
                        JobPath = string.Empty,
                        GSScheduleId = logMessage.GSScheduleId,
                        DeliveryChannel = 0,
                        NatDins = new List<string>() { message.NatCd },
                        NumberPerSchedule = 1,
                        Operation = string.Empty,
                        CorresStatusCode = 31,
                        JGScheduleId = logMessage.JGScheduleId,
                        Flags = new Flags()
                        {
                            AllowDatabaseRetrieve = false,
                            AllowDatabaseUpdate = false,

                            AllowBdeDelivery = true,
                            AllowEaiDelivery = true,
                            AllowMyGovDelivery = true,
                            AllowPaperDelivery = true,
                            AllowSmppDelivery = true,
                            AllowSmtpDelivery = true,
                            SendPaper = true,
                            CorresNotInDb = true,
                            PdfConsolidationRequired = true,
                            PsConsolidationRequired = true,
                        },
                        CSVPreprocessorMsg = new CSVPreprocessorMsg()
                        {
                            BAUContacts = message.BAUContacts,
                            NatCd = message.NatCd,
                            InputFile = message.InputFile
                        },
                        CsvFilePathName = message.InputFile
                    };

                    log($"Creating JobService for {JsonSerializer.Serialize(jobServiceMessage)}");

                    string jobServiceHangfireScheduleId = null;

                    if (triggerJobService)
                    {
                        if (message.ScheduledDateTime.HasValue)
                        {
                            jobServiceHangfireScheduleId = BackgroundJob.Schedule<IJobService>(x => x.Start(jobServiceMessage, null), message.ScheduledDateTime.Value);
                        }
                        else
                        {
                            BackgroundJob.Enqueue<IJobService>(x => x.Start(jobServiceMessage, null));
                        }
                    }

                    response.CsvBatchJobs.Add(new CsvProcessingResponse.CsvBatchJob()
                    {
                        Id = message.Id,
                        BatchId = batchId,
                        JobServiceHangfireScheduleId = jobServiceHangfireScheduleId,
                    });

                    if (updateDb)
                    {
                        log($"Adding entry in DcsBatchHistory for {batchId} with GlobalSchedulerCompleted - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerCSVCompleted}");
                        UpdateBatchHistoryForCSV(db, logMessage.GSScheduleId, logMessage.JGScheduleId, batchId, DcsBatchHistoryStatusEnum.CompGlobalSchedulerCSVCompleted);
                    }
                }

                return response;
            }
            catch (Exception ex)
            {
                logException(ex);

                if (updateDb)
                {
                    log($"Adding entry in DcsBatchHistory for {batchId} with CompGlobalSchedulerFailed - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerCSVFailed}");
                    UpdateBatchHistoryForCSV(db, logMessage.GSScheduleId, logMessage.JGScheduleId, batchId, DcsBatchHistoryStatusEnum.CompGlobalSchedulerCSVFailed);
                }

                response.Failed = true;
                return response;
            }

            void log(string messageToLog)
            {
                var messagePrefixedWithServer = $"{_appConfig.AppSettings.Server} - {messageToLog}";

                response.LogMessages.Add($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {messagePrefixedWithServer}");

                logMessage.Message = messagePrefixedWithServer;
                logMessage.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, messagePrefixedWithServer, null);
            }

            void logException(Exception ex)
            {
                var message = $"{_appConfig.AppSettings.Server} - Exception Occured - {ex.Message} - {ex.StackTrace}";

                response.LogMessages.Add($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}");

                logMessage.Message = message;
                logMessage.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, message, ex);
            }
        }

        private void UpdateBatchHistory(IOutbound db, CompositionMsg message, PerformContext context, DcsBatchHistoryStatusEnum statusToRecord, string userToRecordAgainst)
        {
            DcsBatchHistory recordToAdd = new DcsBatchHistory
            {
                BatchId = message.BatchId,
                CreatedDt = DateTime.Now,
                CreatedId = userToRecordAgainst,
                GSScheduleId = message.GSScheduleId,
                JSScheduleId = message.JGScheduleId
            };
            long temp;
            if (context != null)
            {
                long.TryParse(context.BackgroundJob.Id, out temp);
            }
            else
            {
                temp = 0;
            }
            recordToAdd.HangfireJobId = temp;
            recordToAdd.NewStatusId = (int)statusToRecord;
            recordToAdd.UpdateMsgTxt = "Created by GlobalScheduler";
            _retryPolicy.Execute(() => db.AddDcsBatchHistory(recordToAdd));
        }

        private void UpdateBatchHistoryForRealTime(IOutbound db, RealTimeBatchJobParams message, long batchId, DcsBatchHistoryStatusEnum statusToRecord, string userToRecordAgainst)
        {
            DcsBatchHistory recordToAdd = new DcsBatchHistory
            {
                BatchId = batchId,
                CreatedDt = DateTime.Now,
                CreatedId = userToRecordAgainst,
                GSScheduleId = message.GSScheduleId,
                JSScheduleId = message.JGScheduleId
            };

            recordToAdd.HangfireJobId = 0;
            recordToAdd.NewStatusId = (int)statusToRecord;
            recordToAdd.UpdateMsgTxt = "Created by GlobalScheduler - RealTimeBatchJob";
            _retryPolicy.Execute(() => db.AddDcsBatchHistory(recordToAdd));
        }

        private void UpdateBatchHistoryForCSV(IOutbound db, Guid gsScheduleId, Guid jsScheduleId, long batchId, DcsBatchHistoryStatusEnum statusToRecord)
        {
            DcsBatchHistory recordToAdd = new DcsBatchHistory
            {
                BatchId = batchId,
                CreatedDt = DateTime.Now,
                CreatedId = userToRecordAgainst,
                GSScheduleId = gsScheduleId,
                JSScheduleId = jsScheduleId,
                HangfireJobId = 0,
                NewStatusId = (int)statusToRecord,
                UpdateMsgTxt = "Created by GlobalScheduler - CSVBatchJob"
            };

            _retryPolicy.Execute(() => db.AddDcsBatchHistory(recordToAdd));
        }

        /// <summary>
        /// uodates campain portal batch history with hangfirejobId
        /// </summary>
        /// <param name="db"></param>
        /// <param name="gsScheduleId"></param>
        /// <param name="jsScheduleId"></param>
        /// <param name="batchId"></param>
        /// <param name="hangfireJobId"></param>
        /// <param name="statusToRecord"></param>
        private void UpdateBatchHistoryForCampaignPortal(IOutbound db, Guid gsScheduleId, Guid jsScheduleId, long batchId, long hangfireJobId, DcsBatchHistoryStatusEnum statusToRecord)
        {
            DcsBatchHistory recordToAdd = new DcsBatchHistory
            {
                BatchId = batchId,
                CreatedDt = DateTime.Now,
                CreatedId = userToRecordAgainst,
                GSScheduleId = gsScheduleId,
                JSScheduleId = jsScheduleId,
                HangfireJobId = hangfireJobId,
                NewStatusId = (int)statusToRecord,
                UpdateMsgTxt = "Created by GlobalScheduler - CampaignPortal"
            };

            _retryPolicy.Execute(() => db.AddDcsBatchHistory(recordToAdd));
        }

        private void UpdateBatchHistoryForBdv(IOutbound db, int batchId, DcsBatchHistoryStatusEnum statusToRecord, string userToRecordAgainst)
        {
            DcsBatchHistory recordToAdd = new DcsBatchHistory
            {
                BatchId = batchId,
                CreatedDt = DateTime.Now,
                CreatedId = userToRecordAgainst,
                GSScheduleId = Guid.NewGuid(),
                JSScheduleId = Guid.NewGuid()
            };
            recordToAdd.HangfireJobId = 0;
            recordToAdd.NewStatusId = (int)statusToRecord;
            recordToAdd.UpdateMsgTxt = "Created by GlobalScheduler";
            _retryPolicy.Execute(() => db.AddDcsBatchHistory(recordToAdd));
        }


        #region "Campaign Schedule"
        /// <summary>
        /// deletes a schedule based on the schedueId
        /// </summary>
        /// <param name="scheduleId"></param>
        /// <returns></returns>
        public Dictionary<string, string> DeleteCampaignSchedule(string scheduleId)
        {
            var deleted = BackgroundJob.Delete(scheduleId);
            Dictionary<string, string> response = new Dictionary<string, string>
            {
                { "HangfireJobId", scheduleId},
                { "Deleted", deleted.ToString() }
            };
            return response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="schedule"></param>
        /// <param name="db"></param>
        /// <param name="triggerJobService"></param>
        /// <param name="updateDb"></param>
        /// <returns></returns>
        public CampaignScheduleProcessingResponse CreateCampaignSchedule(CampaignScheduldeMsg schedule, IOutbound db, bool triggerJobService = true, bool updateDb = true)
        {
            var response = new CampaignScheduleProcessingResponse();

            var logMessage = new DCSLogMsg
            {
                Application = "DCS.Composition.Services.GlobalScheduler",
                Server = _appConfig.AppSettings.Server,
                ApplicationVersion = _appConfig.AppSettings.Versions[Assembly.GetExecutingAssembly().GetName().Name].ReleaseBuild,
                DeliveryChannel = 0,
                BatchId = 0,
                LogDatetime = DateTime.Now,
                LogLevel = LogLevel.Information
            };

            try
            {
                logMessage.NatDins = schedule.NatCd;
                logMessage.GSScheduleId = Guid.NewGuid();
                logMessage.JGScheduleId = Guid.NewGuid();

                var printStreamId = _retryPolicy.Execute(() => db.GetPrintStreamIdByNatCd(schedule.NatCd));

                if (updateDb)
                {
                    batchId = _retryPolicy.Execute(() => db.CreateElectronicBatch(printStreamId, userToRecordAgainst));

                    AppLog.Info()(batchId, "Creating batch {batchId} for type {batchType}", DcsBatchType.CampaignPortalBatch);

                    _retryPolicy.Execute(() => db.AddDcsBulkPrintBatch(new DcsBulkPrintBatch()
                    {
                        BulkPrintBatchId = batchId,
                        CreatedId = userToRecordAgainst,
                        DcsBatchHistoryCodesId = (int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerCSVStarted,
                        DcsBatchTypeId = (int)DcsBatchType.CampaignPortalBatch
                    }));
                }
                else
                {
                    batchId = -1;
                }

                logMessage.BatchId = batchId;

                log($"Creating batch {batchId} for file {schedule.InputFile}");

                if (updateDb)
                {
                    log($"Adding entry in DcsBatchHistory for {batchId} with GlobalSchedulerStarted - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerStarted}");
                    UpdateBatchHistoryForCampaignPortal(db, logMessage.GSScheduleId, logMessage.JGScheduleId, batchId, 0, DcsBatchHistoryStatusEnum.CompGlobalSchedulerStarted);
                }

                var jobServiceMessage = new CompositionMsg
                {
                    BatchId = batchId,
                    JobPath = string.Empty,
                    GSScheduleId = logMessage.GSScheduleId,
                    DeliveryChannel = 0,// schedule.DeliveryChannel,
                    NatDins = new List<string>() { schedule.NatCd },
                    NumberPerSchedule = 1,
                    Operation = string.Empty,
                    Stage = schedule.Stage,
                    CorresStatusCode = schedule.CorresStatusCode,
                    JGScheduleId = logMessage.JGScheduleId,
                    Flags = new Flags()
                    {
                        AllowDatabaseRetrieve = false,
                        AllowDatabaseUpdate = false,
                        AllowBdeDelivery = true,
                        AllowEaiDelivery = true,
                        AllowMyGovDelivery = true,
                        AllowPaperDelivery = true,
                        AllowSmppDelivery = true,
                        AllowSmtpDelivery = true,
                        SendPaper = true
                    },
                    CampaignScheduldeMsg = new CampaignScheduldeMsg()
                    {
                        InputFile = schedule.InputFile,
                        ScheduleId = schedule.ScheduleId,
                        BAUContacts = schedule.BAUContacts,
                        CompositionStartDt = schedule.CompositionStartDt,
                        DeliveryStartDt = schedule.DeliveryStartDt,
                        RealtimeFolder = schedule.RealtimeFolder,
                        NatCd = schedule.NatCd,
                        CorresStatusCode = schedule.CorresStatusCode,
                        Stage = schedule.Stage,
                        DeliveryChannel = 0// schedule.DeliveryChannel
                    },
                    CSVPreprocessorMsg = null


                };

                log($"Creating JobService for {JsonSerializer.Serialize(jobServiceMessage)}");

                string jobServiceHangfireScheduleId = null;

                if (triggerJobService)
                {

                    jobServiceHangfireScheduleId = BackgroundJob.Schedule<IJobService>(x => x.Start(jobServiceMessage, null), schedule.CompositionStartDt);


                }
                response.BatchId = batchId;
                response.JobServiceHangfireScheduleId = jobServiceHangfireScheduleId;
                response.Id = Guid.NewGuid();



                if (updateDb)
                {
                    long.TryParse(jobServiceHangfireScheduleId, out long hfId);

                    log($"Adding entry in DcsBatchHistory for {batchId} with GlobalSchedulerCompleted - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerCompleted}");
                    UpdateBatchHistoryForCampaignPortal(db, logMessage.GSScheduleId, logMessage.JGScheduleId, batchId, hfId, DcsBatchHistoryStatusEnum.CompGlobalSchedulerCompleted);
                }


                return response;
            }
            catch (Exception ex)
            {
                logException(ex);

                if (updateDb)
                {
                    log($"Adding entry in DcsBatchHistory for {batchId} with CompGlobalSchedulerFailed - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerFailed}");
                    UpdateBatchHistoryForCampaignPortal(db, logMessage.GSScheduleId, logMessage.JGScheduleId, batchId, 0, DcsBatchHistoryStatusEnum.CompGlobalSchedulerFailed);
                }

                response.Failed = true;
                return response;
            }

            void log(string messageToLog)
            {
                var messagePrefixedWithServer = $"{_appConfig.AppSettings.Server} - {messageToLog}";

                response.LogMessages.Add($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {messagePrefixedWithServer}");

                logMessage.Message = messagePrefixedWithServer;
                logMessage.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, messagePrefixedWithServer, null);
            }

            void logException(Exception ex)
            {
                var message = $"{_appConfig.AppSettings.Server} - Exception Occured - {ex.Message} - {ex.StackTrace}";

                response.LogMessages.Add($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}");

                logMessage.Message = message;
                logMessage.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, message, ex);
            }
        }


        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="batchId"></param>
        /// <returns></returns>
        private string CreateBatchFolder(long batchId)
        {
            string path = Path.Combine(_appConfig.AppSettings.JobFolderRootPath, batchId.ToString());
            if (Directory.Exists(path))
            {
                AppLog.Info()(batchId, $"Folder '{path}' exists, no need to create another one.");
                return path;
            }
            AppLog.Info()(batchId, $"Creating a new folder '{path}'.");
            var info = Directory.CreateDirectory(path);
            string newFolder = info?.FullName;
            AppLog.Info()(batchId, $"The batch ({batchId}) folder path is {newFolder}");
            return newFolder;
        }

        /// <summary>
        /// Method to actually do the work
        /// </summary>
        /// <param name="message"></param>
        /// <param name="context">The HangFire Context passed when the HF server calls this method</param>
        /// <returns></returns>
        public void RunRealtimeBatchJob(RealTimeBatchJobParams message, PerformContext context)
        {
            if (message.GSScheduleId == Guid.Empty)
                message.GSScheduleId = Guid.NewGuid();

            if (message.JGScheduleId == Guid.Empty)
                message.JGScheduleId = Guid.NewGuid();

            DCSLogMsg logMsg = new DCSLogMsg
            {
                Application = "DCS.Composition.Services.GlobalScheduler",
                Server = _appConfig.AppSettings.Server,
                ApplicationVersion = _appConfig.AppSettings.Versions[Assembly.GetExecutingAssembly().GetName().Name].ReleaseBuild,
                GSScheduleId = message.GSScheduleId,
                JGScheduleId = message.JGScheduleId,
                DeliveryChannel = message.DeliveryChannel,
                NatDins = message.NatDin,
                BatchId = 0,
                LogDatetime = DateTime.Now,
                LogLevel = LogLevel.Information
            };
            string messageAsJson = JsonSerializer.Serialize(message);

            RealTimeBatchJobParamsResponse doWorkResponse = new RealTimeBatchJobParamsResponse
            {
                Job = null,
                LogMessages = new List<string>(),
                BatchId = 0,
                NumberProcessed = 0
            };

            logMsg.Message = $"{_appConfig.AppSettings.Server} - Processing {messageAsJson}";
            doWorkResponse.LogMessages.Add($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Processing {messageAsJson}");
            logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{_appConfig.AppSettings.Server} - Processing {messageAsJson}", null);

            try
            {

                int currentNumberProcessed = 0;

                //Get the list of Corres ready to process
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Processing {message.CorresId} for {message.NatDin} and CorresStatusCode {message.CorresStatusCode}");

                logMsg.Message = $"{_appConfig.AppSettings.Server} - Creating Batche for {message.CorresId} with Nat/Din of {message.NatDin}";
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{_appConfig.AppSettings.Server} - Number Found to Process: 1", null);

                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Creating Batches for {message.NatDin}");
                GSJob gsJob = new GSJob
                {
                    NatCds = message.NatDin,
                    NumberToProcess = 1
                };

                // get the print streamid for the natcd/pub file
                int printStreamId = _retryPolicy.Execute(() => _db.GetPrintStreamIdByNatCd(message.NatDin));

                if (_appConfig.AppSettings.NonElectronicStatusList.Contains(message.DeliveryChannel))
                {

                    batchId = _retryPolicy.Execute(() => _db.CreateBulkPrintBatch(Convert.ToInt16(printStreamId), null, 2, "DCSBP", "BP", _appConfig.AppSettings.UserToRecordAgainst));
                    AppLog.Info()(batchId, "Creating batch {batchId} for type {batchType} and channel {deliveryChannel} using CreateBulkPrintBatch", DcsBatchType.RealTimeInstantBatch, message.DeliveryChannel);
                }
                else
                {
                    batchId = _retryPolicy.Execute(() => _db.CreateElectronicBatch(printStreamId, userToRecordAgainst));
                    AppLog.Info()(batchId, "Creating batch {batchId} for type {batchType} and channel {deliveryChannel} using CreateElectronicBatch", DcsBatchType.RealTimeInstantBatch, message.DeliveryChannel);
                }

                _retryPolicy.Execute(() => _db.AddDcsBulkPrintBatch(new DcsBulkPrintBatch()
                {
                    BulkPrintBatchId = batchId,
                    CreatedId = userToRecordAgainst,
                    DcsBatchHistoryCodesId = (int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerRealTimeStarted,
                    DcsBatchTypeId = (int)DcsBatchType.RealTimeInstantBatch,
                    DeliveryChannelCd = message.DeliveryChannel
                }));

                doWorkResponse.BatchId = batchId;
                //Add a BatchHistory record
                int result = 0;
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Adding entry in DcsBatchHistory for {batchId} with GlobalSchedulerStarted - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerStarted}");

                UpdateBatchHistoryForRealTime(_db, message, batchId, DcsBatchHistoryStatusEnum.CompGlobalSchedulerRealTimeStarted, _appConfig.AppSettings.UserToRecordAgainst);
                logMsg.Message = $"{_appConfig.AppSettings.Server} - Calling UpdateCorresRequestStatusAndBatchByBetId with parameters: {message.CorresId}, {message.CorresStatusCode}, {batchId}";
                using (LogContext.PushProperty("BatchId", batchId))
                {
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logMsg.Message, null);
                }
                result = _retryPolicy.Execute(() => _db.UpdateCorresRequestBatchByBetId(message.CorresId, batchId));
                _retryPolicy.Execute(() => _db.AddCorresBatchHistory(batchId, _appConfig.AppSettings.CorresBatchHistoryInsertSize));


                //Logging
                logMsg.Message = $"{_appConfig.AppSettings.Server} - {result} records added to batch {batchId} ";
                using (LogContext.PushProperty("BatchId", batchId))
                {
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logMsg.Message, null);
                }

                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - {result} records added to batch {batchId} ");

                CompositionMsg jobServiceParams = new CompositionMsg
                {
                    BatchId = batchId,
                    JobPath = string.Empty,
                    GSScheduleId = message.GSScheduleId,
                    DeliveryChannel = message.DeliveryChannel,
                    NatDins = new List<string>() { message.NatDin },
                    NumberPerSchedule = 1,
                    Operation = string.Empty,
                    CorresStatusCode = message.CorresStatusCode,
                    JGScheduleId = message.JGScheduleId,
                    Flags = message.Flags
                };

                string inputMessageAsJson = JsonSerializer.Serialize(jobServiceParams);

                //Logging
                logMsg.Message = $"{_appConfig.AppSettings.Server} - Creating JobService for {inputMessageAsJson}";
                using (LogContext.PushProperty("BatchId", batchId))
                {
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logMsg.Message, null);
                }

                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Creating JobService for {inputMessageAsJson}");

                gsJob.MessaageToSendToJobService = jobServiceParams;

                gsJob.HangfireJobServiceJobId = BackgroundJob.Enqueue<IJobService>(x => x.Start(jobServiceParams, null));


                gsJob.HangfireScheduleDateTime = DateTime.Now;

                doWorkResponse.Job = gsJob;
                //Logging
                logMsg.Message = $"{_appConfig.AppSettings.Server} - HF Job - {gsJob.ToJson()}";
                using (LogContext.PushProperty("BatchId", batchId))
                {
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logMsg.Message, null);
                }
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - HF Job - {gsJob.ToJson()}");

                currentNumberProcessed += 1;

                //Add a BatchHistory record
                doWorkResponse.NumberProcessed = currentNumberProcessed;
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Number Processed for {messageAsJson} = {currentNumberProcessed}");
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Adding entry in DcsBatchHistory for {batchId} with GlobalSchedulerStarted - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerCompleted}");

                UpdateBatchHistoryForRealTime(_db, message, batchId, DcsBatchHistoryStatusEnum.CompGlobalSchedulerRealTimeCompleted, _appConfig.AppSettings.UserToRecordAgainst);


            }
            catch (Exception ex)
            {
                logMsg.Message = $"{_appConfig.AppSettings.Server} - Exception Occured - {ex.Message} - {ex.StackTrace}";
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logMsg.Message, ex);
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Exception Occured - {ex.Message} - {ex.StackTrace}");
                doWorkResponse.LogMessages.Add($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Adding entry in DcsBatchHistory for {batchId} with GlobalSchedulerStarted - {(int)DcsBatchHistoryStatusEnum.CompGlobalSchedulerFailed}");

                UpdateBatchHistoryForRealTime(_db, message, 0, DcsBatchHistoryStatusEnum.CompGlobalSchedulerRealTimeFailed, _appConfig.AppSettings.UserToRecordAgainst);

            }

        }
    }

    class PubFileDetails
    {
        public string Name { get; set; }
        public int Priority { get; set; }
        public Dictionary<string, int> NatCds { get; set; }
        public int CorresPubId { get; set; }
    }


}
