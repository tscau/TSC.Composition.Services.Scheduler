﻿using DCS.Composition.Services.Shared.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DCS.Composition.Services.GlobalScheduler.Common
{
    public class ProcessBdvRequest
    {
        public List<long> BetIds { get; set; }

        public int DeliveryChannel { get; set; }

        public byte Status { get; set; }

        public int StatusToProcess { get; set; }

        public string NatCd { get; set; }

        public Flags Flags { get; set; }
        public DateTimeOffset RunAt { get; set; }

        public bool CallHangfire { get; set; }
    }
}
