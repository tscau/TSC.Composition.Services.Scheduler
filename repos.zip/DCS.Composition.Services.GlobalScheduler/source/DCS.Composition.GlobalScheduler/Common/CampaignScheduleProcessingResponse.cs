﻿using System;
using System.Collections.Generic;

namespace DCS.Composition.Services.GlobalScheduler.Common
{
    /// <summary>
    /// Class to hold all the responses from the DoWork method
    /// </summary>
    public class CampaignScheduleProcessingResponse
    {
        /// <summary>
        /// List of log messages that are written to the logs/event log
        /// </summary>
        public List<string> LogMessages { get; set; } = new List<string>();

        /// <summary>
        /// Whether the request was successful or not
        /// </summary>
        public bool Failed { get; set; }

        /// <summary>
        /// Guid used to identifier this job
        /// </summary>
        public Guid Id { get; set; }

        /// <summary>
        /// The generated batchId
        /// </summary>
        public long BatchId { get; set; }

        /// <summary>
        /// The job service schedule d if scheduled
        /// </summary>
        public string JobServiceHangfireScheduleId { get; set; }

    }
}
