﻿using System.Collections.Generic;

namespace DCS.Composition.Services.GlobalScheduler.Common
{
    /// <summary>
    /// Class to hold all the responses from the DoWork method
    /// </summary>
    public class DoWorkResponse
    {
        /// <summary>
        /// List of log messages that are written to the logs/event log
        /// </summary>
        public List<string> LogMessages { get; set; }

        /// <summary>
        /// The lsit of GSJob details that are created by the DoWork method
        /// </summary>
        public List<GSJob> Jobs { get; set; }

        /// <summary>
        /// The list of BatchIds that were created by the application
        /// </summary>
        public List<long> BatchIds { get; set; }

        /// <summary>
        /// The number of records processed by the DoWork method
        /// </summary>
        public int NumberProcessed { get; set; }

        /// <summary>
        /// Indicates whether the process completed successfully or not
        /// </summary>
        public bool Success { get; set; }
    }
}
