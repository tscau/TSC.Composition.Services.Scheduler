﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Reflection;

namespace DCS.Composition.Services.GlobalScheduler.Config
{
    /// <summary>
    /// 
    /// </summary>
    public class AppSettings : IAppSettings
    {
        /// <summary>
        /// 
        /// </summary>
        public string Environment
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("Env");
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public int DaysToFilter
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("DaysToFilter"), out int daysToFilter);
                if (daysToFilter == 0)
                {
                    daysToFilter = 90;
                }

                return daysToFilter;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public int HangfirePutQueueWorkerCount
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("HangfirePutQueueWorkerCount"), out int hangfireWorkerCount);
                if (hangfireWorkerCount == 0)
                {
                    hangfireWorkerCount = 10;
                }

                return hangfireWorkerCount;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public int HangfireRealtimeBatchQueueWorkerCount
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("HangfireRealtimeBatchQueueWorkerCount"), out int hangfireWorkerCount);
                if (hangfireWorkerCount == 0)
                {
                    hangfireWorkerCount = 10;
                }

                return hangfireWorkerCount;
            }
        }

        /// <summary>
        /// Max records per csv file before splitting the file into multiples
        /// Defaults to 50,000
        /// </summary>
        public int MaxRecordsPerCsvFile
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get(nameof(MaxRecordsPerCsvFile)), out int maxRecordsPerCsvFile);
                if (maxRecordsPerCsvFile == 0)
                {
                    maxRecordsPerCsvFile = 50_000;
                }

                return maxRecordsPerCsvFile;
            }
        }

        /// <summary>
        /// When a csv file has been split into multiple batches, this is the time to wait between scheduling each batch
        /// Defaults to 15 seconds
        /// </summary>
        public TimeSpan DelayBetweenCsvSchedules
        {
            get
            {
                TimeSpan.TryParse(ConfigurationManager.AppSettings.Get(nameof(DelayBetweenCsvSchedules)), out TimeSpan delayBetweenCsvSchedules);
                if (delayBetweenCsvSchedules == TimeSpan.Zero)
                {
                    delayBetweenCsvSchedules = TimeSpan.FromSeconds(15);
                }

                return delayBetweenCsvSchedules;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public string UserToRecordAgainst
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("UserToRecordAgainst");
            }
        }

        /// <summary>
        /// Returns the version of the application
        /// </summary>
        public Dictionary<string, AssemblyVersionDetails> Versions
        {
            get
            {
                Dictionary<string, AssemblyVersionDetails> versions = new Dictionary<string, AssemblyVersionDetails>();
                AssemblyVersionDetails details = new AssemblyVersionDetails
                {
                    ReleaseBuild = Assembly.GetExecutingAssembly().GetName().Version.ToString(),
                    ReleaseVersion = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                    BuildNumber = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                    ReleaseName = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyProductAttribute>().Product
                };
                versions.Add(Assembly.GetExecutingAssembly().GetName().Name, details);

                Assembly sharedAssembly = Assembly.Load("DCS.Composition.Services.Shared");
                details = new AssemblyVersionDetails
                {
                    ReleaseBuild = sharedAssembly.GetName().Version.ToString(),
                    ReleaseVersion = sharedAssembly.GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                    BuildNumber = sharedAssembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                    ReleaseName = sharedAssembly.GetCustomAttribute<AssemblyProductAttribute>().Product
                };
                versions.Add(sharedAssembly.GetName().Name, details);

                sharedAssembly = Assembly.Load("DCS.PostComposition.Services.Shared");
                details = new AssemblyVersionDetails
                {
                    ReleaseBuild = sharedAssembly.GetName().Version.ToString(),
                    ReleaseVersion = sharedAssembly.GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                    BuildNumber = sharedAssembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                    ReleaseName = sharedAssembly.GetCustomAttribute<AssemblyProductAttribute>().Product
                };
                versions.Add(sharedAssembly.GetName().Name, details);

                //add the shared assemblies as well
                sharedAssembly = Assembly.Load("DCS.Shared.DataAccess.Outbound");
                details = new AssemblyVersionDetails
                {
                    ReleaseBuild = sharedAssembly.GetName().Version.ToString(),
                    ReleaseVersion = sharedAssembly.GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                    BuildNumber = sharedAssembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                    ReleaseName = sharedAssembly.GetCustomAttribute<AssemblyProductAttribute>().Product
                };
                versions.Add(sharedAssembly.GetName().Name, details);
                return versions;
            }
        }

        /// <summary>
        /// Returns the name of the server that is currently executing the code
        /// </summary>
        public string Server => System.Environment.MachineName;

        /// <summary>
        /// 
        /// </summary>
        public string JobFolderRootPath
        {
            get
            {
                string jobFolderRootPath = ConfigurationManager.AppSettings.Get("JobFolderRootPath");
                if (string.IsNullOrWhiteSpace(jobFolderRootPath))
                {
                    return string.Empty;
                }
                else
                {
                    return jobFolderRootPath;
                }
            }
        }

        /// <summary>
        /// </summary>
        public string BaseStagingFolder
        {
            get
            {
                string baseStagingFolder = ConfigurationManager.AppSettings.Get("BaseStagingFolder");
                if (string.IsNullOrWhiteSpace(baseStagingFolder))
                {
                    return string.Empty;
                }
                else
                {
                    return baseStagingFolder;
                }
            }
        }

        /// <summary>
        /// Returns a list of integers that represent the Status Codes that are not electronic correspondence
        /// Defaults to 5 and 30 if no value is supplied
        /// </summary>
        public List<int> NonElectronicStatusList
        {
            get
            {
                List<int> returnValue = new List<int>() { 5, 30 }; 
                string nonElectronicStatusList = ConfigurationManager.AppSettings.Get("NonElectronicStatusList");
                if (!string.IsNullOrWhiteSpace(nonElectronicStatusList))
                { 
                    //Split into integers
                    returnValue = new List<int>();
                    string[] splitArr = nonElectronicStatusList.Split(',');
                    foreach (string item in splitArr)
                    {
                        int.TryParse(item, out int temp);
                        if (temp != 0)
                        {
                            returnValue.Add(temp);
                        }
                    }
                }
                if (returnValue.Count == 0)
                {
                    returnValue = new List<int>() { 5, 30 };
                }
                return returnValue;
            }
        }

        /// <summary>
        /// The size of inserts when inserting records for CorresBatchHistory
        /// </summary>
        public int CorresBatchHistoryInsertSize
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("CorresBatchHistoryInsertSize"), out int corresBatchHistoryInsertSize);
                if (corresBatchHistoryInsertSize == 0)
                {
                    corresBatchHistoryInsertSize = 500;
                }

                return corresBatchHistoryInsertSize;
            }
        }

        /// <summary>
        /// Retrieves the SqlTimeoutRetryAttempts entry from the config file. If none found, then defaults to 3
        /// </summary>
        public int SqlTimeoutRetryAttempts
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("SqlTimeoutRetryAttempts"), out int sqlTimeoutRetryAttempts);
                if (sqlTimeoutRetryAttempts == 0)
                {
                    sqlTimeoutRetryAttempts = 3;
                }

                return sqlTimeoutRetryAttempts;
            }
        }

        /// <summary>
        /// Retrieves the SqlTimeoutFirstRetryDelaySeconds entry from the config file. If none found, then defaults to 3
        /// </summary>
        public int SqlTimeoutFirstRetryDelaySeconds
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("SqlTimeoutFirstRetryDelaySeconds"), out int sqlTimeoutFirstRetryDelaySeconds);
                if (sqlTimeoutFirstRetryDelaySeconds == 0)
                {
                    sqlTimeoutFirstRetryDelaySeconds = 3;
                }

                return sqlTimeoutFirstRetryDelaySeconds;
            }
        }
    }
}
