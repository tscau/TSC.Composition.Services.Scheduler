﻿namespace DCS.Composition.Services.GlobalScheduler.Config
{
    /// <summary>
    /// 
    /// </summary>
    public interface ILoggingSettings
    {
        /// <summary>
        /// 
        /// </summary>
        public string LogServiceUrl { get; }

    }
}
