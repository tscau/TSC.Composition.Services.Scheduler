﻿using System;
using System.Collections.Generic;

namespace DCS.Composition.Services.GlobalScheduler.Config
{
    /// <summary>
    /// 
    /// </summary>
    public interface IAppSettings
    {
        /// <summary>
        /// 
        /// </summary>
        public string Environment { get; }

        /// <summary>
        /// 
        /// </summary>
        public int DaysToFilter { get; }

        /// <summary>
        /// 
        /// </summary>
        public int HangfirePutQueueWorkerCount { get; }

        /// <summary>
        /// 
        /// </summary>
        public int HangfireRealtimeBatchQueueWorkerCount { get; }

        /// <summary>
        /// 
        /// </summary>
        public string UserToRecordAgainst { get; }

        /// <summary>
        /// The version of the application abd dependent assemblies
        /// </summary>
        public Dictionary<string, AssemblyVersionDetails> Versions { get; }

        /// <summary>
        /// 
        /// </summary>
        public string Server { get; }

        /// <summary>
        /// 
        /// </summary>
        public int MaxRecordsPerCsvFile { get; }

        /// <summary>
        /// 
        /// </summary>
        TimeSpan DelayBetweenCsvSchedules { get; }

        /// <summary>
        /// 
        /// </summary>
        public string JobFolderRootPath { get; }

        /// <summary>
        /// 
        /// </summary>
        public string BaseStagingFolder { get; }

        /// <summary>
        /// 
        /// </summary>
        public List<int> NonElectronicStatusList { get; }

        /// <summary>
        /// The size of inserts when inserting records for CorresBatchHistory
        /// </summary>
        public int CorresBatchHistoryInsertSize { get; }

        /// <summary>
        /// Retrieves the SqlTimeoutRetryAttempts entry from the config file. If none found, then defaults to 3
        /// </summary>
        public int SqlTimeoutRetryAttempts { get; }

        /// <summary>
        /// Retrieves the SqlTimeoutFirstRetryDelaySeconds entry from the config file. If none found, then defaults to 3
        /// </summary>
        public int SqlTimeoutFirstRetryDelaySeconds { get; }
    }
}
