﻿namespace DCS.Composition.Services.GlobalScheduler.Config
{
    /// <summary>
    /// 
    /// </summary>
    public interface IConnectionStrings
    {
        /// <summary>
        /// 
        /// </summary>
        public string OutboundCorroGen { get; }

        /// <summary>
        /// 
        /// </summary>
        public string HangfireDb { get; }

        /// <summary>
        /// 
        /// </summary>
        public string HangfireDeliveryDb { get; }
    }
}
