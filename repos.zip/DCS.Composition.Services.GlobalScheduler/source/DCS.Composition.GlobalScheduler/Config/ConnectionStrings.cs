﻿using System.Configuration;

namespace DCS.Composition.Services.GlobalScheduler.Config
{
    /// <summary>
    /// 
    /// </summary>
    public class ConnectionStrings : IConnectionStrings
    {

        /// <summary>
        /// The Connection String for the Outbound database
        /// </summary>
        public string OutboundCorroGen
        {
            get
            {
                ConnectionStringSettings connectionStrings = ConfigurationManager.ConnectionStrings["OutboundCorroGen"];
                if (connectionStrings is null)
                {
                    return string.Empty;
                }


                string outboundCorrogen = ConfigurationManager.ConnectionStrings["OutboundCorroGen"].ConnectionString;
                if (string.IsNullOrWhiteSpace(outboundCorrogen))
                {
                    outboundCorrogen = string.Empty;
                }
                return outboundCorrogen;
            }
        }

        /// <summary>
        /// The connections tring for the hangfire database
        /// </summary>
        public string HangfireDb
        {
            get
            {
                ConnectionStringSettings connectionStrings = ConfigurationManager.ConnectionStrings["Hangfire"];
                if (connectionStrings is null)
                {
                    return string.Empty;
                }

                string hangfire = ConfigurationManager.ConnectionStrings["Hangfire"].ConnectionString;
                if (string.IsNullOrWhiteSpace(hangfire))
                {
                    hangfire = string.Empty;
                }
                return hangfire;
            }
        }


        /// <summary>
        /// The Hangfire database that will be used for post composition services
        /// </summary>
        public string HangfireDeliveryDb
        {
            get
            {
                ConnectionStringSettings connectionStrings = ConfigurationManager.ConnectionStrings["HangfireDelivery"];
                if (connectionStrings is null)
                {
                    return string.Empty;
                }

                string hangfireDeliveryDb = ConfigurationManager.ConnectionStrings["HangfireDelivery"].ConnectionString;
                if (string.IsNullOrWhiteSpace(hangfireDeliveryDb))
                {
                    hangfireDeliveryDb = string.Empty;
                }
                return hangfireDeliveryDb;
            }
        }
    }
}
