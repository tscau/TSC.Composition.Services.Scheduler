﻿using DCS.Composition.Services.GlobalScheduler.Common;
using DCS.Composition.Services.GlobalScheduler.Config;
using DCS.Composition.Services.Shared.GlobalScheduler;
using DCS.Composition.Services.Shared.Queues;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Database;
using DCS.Shared.DataAccess.Outbound.Extensions;
using Hangfire;
using Hangfire.JobsLogger;
using Hangfire.SqlServer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Polly;
using Polly.Contrib.WaitAndRetry;
using Polly.Registry;
using Polly.Retry;
using System;
using System.IO;
using System.Reflection;

namespace DCS.Composition.Services.GlobalScheduler
{
    /// <summary>
    /// 
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="configuration"></param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// 
        /// </summary>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="services"></param>
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var appConfig = new AppConfig();

            services.AddControllers();
            services.ConfigureSwaggerGen(c => c.CustomSchemaIds(type => type.FullName));
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "GLobalScheduler API",
                    Version = "v1",
                    Description = "The GlobalScheduler API used to manage the GlobalScheduler via a REST endpoint"
                });
            });

            //See https://github.com/Polly-Contrib/Polly.Contrib.WaitAndRetry#wait-and-retry-with-jittered-back-off
            var delay = Backoff.DecorrelatedJitterBackoffV2(medianFirstRetryDelay: TimeSpan.FromSeconds(appConfig.AppSettings.SqlTimeoutFirstRetryDelaySeconds), retryCount: appConfig.AppSettings.SqlTimeoutRetryAttempts);
            RetryPolicy retryPolicy = Policy.Handle<SqlException>(ex => SqlServerTransientExceptionDetector.ShouldRetryOn(ex))
                    .WaitAndRetry(delay);

            PolicyRegistry registry = new PolicyRegistry()
            {
                { "SqlTimeOutPolicy",  retryPolicy}
            };
            services.AddSingleton<IReadOnlyPolicyRegistry<string>>(registry);

            services.AddTransient<IGlobalScheduler, GlobalSchedulerImplementation>();
            services.AddTransient<GlobalSchedulerImplementation>();
            services.AddSingleton<IOutbound>(new DbContext(() => new SqlConnection(appConfig.ConnectionStrings.OutboundCorroGen)));
            services.AddSingleton<IAppConfig>(appConfig);


            services.AddHangfire(configuration => configuration
                .SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
                .UseSerilogLogProvider()
                .UseJobsLogger()
                .UseSimpleAssemblyNameTypeSerializer()
                .UseRecommendedSerializerSettings()
                .UseSqlServerStorage(appConfig.ConnectionStrings.HangfireDb, new SqlServerStorageOptions
                {
                    CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
                    SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
                    QueuePollInterval = TimeSpan.Zero,
                    UseRecommendedIsolationLevel = true,
                    UsePageLocksOnDequeue = true,
                    DisableGlobalLocks = true,
                    PrepareSchemaIfNecessary = true
                }));

            services.AddHangfireServer(options =>
            {
                options.Queues = new string[] { GlobalSchedulerQueues.GlobalSchedulerPutQueue };
                options.WorkerCount = appConfig.AppSettings.HangfirePutQueueWorkerCount;
                options.ServerName = string.Format("{0}.{1}", Environment.MachineName, Guid.NewGuid().ToString());
            });

            services.AddHangfireServer(options =>
            {
                options.Queues = new string[] { GlobalSchedulerQueues.GlobalSchedulerRealtimeBatchQueue };
                options.WorkerCount = appConfig.AppSettings.HangfireRealtimeBatchQueueWorkerCount;
                options.ServerName = string.Format("{0}.{1}", Environment.MachineName, Guid.NewGuid().ToString());
            });

        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseStaticFiles();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "GlobalScheduler API V1");
                c.RoutePrefix = string.Empty;
            });

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

        }
    }
}
