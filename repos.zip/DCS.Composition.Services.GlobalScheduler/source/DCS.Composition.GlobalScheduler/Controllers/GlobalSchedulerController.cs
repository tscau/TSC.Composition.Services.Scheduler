﻿using DCS.Composition.Services.GlobalScheduler.Common;
using DCS.Composition.Services.GlobalScheduler.Config;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.GlobalScheduler;
using DCS.Logging.Shared.Infrastructure;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Database;
using Hangfire;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace DCS.Composition.Services.GlobalScheduler.Controllers
{
    /// <summary>
    /// REST Controlle rthat provides methods to call and get information on the service
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class GlobalSchedulerController : ControllerBase
    {
        readonly IAppConfig _appConfig;
        private readonly GlobalSchedulerImplementation globalScheduler;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appConfig"></param>
        public GlobalSchedulerController(IAppConfig appConfig, GlobalSchedulerImplementation globalScheduler)
        {
            _appConfig = appConfig;
            this.globalScheduler = globalScheduler;
        }
        /// <summary>
        /// Method to put a call to the JobService onto the Hangfire datbase  using the supplied CompositionMsg
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        /// <remarks>
        /// This method uses the CompositionMsg. The following properties need to be set for this to work:
        ///   
        /// </remarks>
        [HttpPost]
        [Route("CallJobServiceViaHangfire")]
        public JsonResult CallJobServiceViaHangfire(CompositionMsg message)
        {
            try
            {
                AppLog.Info()(message.BatchId, "CallJobServiceViaHangfire started");
                var id = BackgroundJob.Enqueue<IGlobalScheduler>(x => x.RunSchedule(message, null));
                Dictionary<string, string> response = new Dictionary<string, string>
                {
                    { "HangfireJobId", id }
                };
                AppLog.Info()(message.BatchId, "CallJobServiceViaHangfire completed");
                return new JsonResult(response);
            }
            catch(Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, "An unhandled error occured in CallJobServiceViaHangfire: {Message}; {Stacktrace}", ex.Message, ex.StackTrace);
                return new JsonResult(ex);
            }
        }

        /// <summary>
        /// Method to put a call to the JobService onto the Hangfire datbase  using the supplied CompositionMsg. this simualates being called via a Hangfire schedule
        /// </summary>
        /// <param name="message"></param>
        /// <param name="triggerJobService">Whether to trigger the JobService. Used for testing/BAU purposes</param>
        /// <param name="updateDb"></param>
        /// <returns></returns>
        /// <remarks>The result of this method is that a JobService Hangfire schedule is created in the Hangfire database</remarks>
        [HttpPost]
        [Route("CallJobservice")]
        public JsonResult CallJobService(CompositionMsg message, bool triggerJobService, bool updateDb)
        {
            try
            {
                IOutbound db = new DbContext(() => new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen));

                DoWorkResponse response = globalScheduler.DoWork(message, null, db, triggerJobService, updateDb);
                return new JsonResult(response);
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, "An unhandled error occured in CallJobService: {Message}; {Stacktrace}", ex.Message, ex.StackTrace);
                return new JsonResult(ex);
            }
            
        }

        /// <summary>
        /// API to call GlobalSchduler to create batches for a NatCd as opposed to the default Delivery Channel. Places a message on the HangFire queue
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CallRunschduleForNatCdViaHF")]
        public JsonResult CallRunschduleForNatCdViaHF(CompositionMsg message)
        {
            try
            {
                if (message.NatDins == null || message.NatDins.Count == 0)
                {
                    //Throw an error back saying that the message is invalid
                    return new JsonResult(new BadRequestResult());
                }
                var id = BackgroundJob.Enqueue<IGlobalScheduler>(x => x.RunScheduleByNatCd(message, null));
                Dictionary<string, string> response = new Dictionary<string, string>
            {
                { "HangfireJobId", id }
            };
                return new JsonResult(response);
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, "An unhandled error occured in CallRunschduleForNatCdViaHF: {Message}; {Stacktrace}", ex.Message, ex.StackTrace);
                return new JsonResult(ex);
            }          
        }

        /// <summary>
        /// API to call the global scheduler to use a NatCd instead of the default deliveyr channel to create the batch
        /// </summary>
        /// <param name="message"></param>
        /// <param name="triggerJobService"></param>
        /// <param name="updateDb"></param>
        /// <param name="natCd"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CallRunschduleForNatCd")]
        public JsonResult CallRunschduleForNatCd(CompositionMsg message, bool triggerJobService, bool updateDb, string natCd)
        {
            try
            {
                if (message.NatDins == null || message.NatDins.Count == 0)
                {
                    //Throw an error back saying that the message is invalid
                    return new JsonResult(new BadRequestResult());
                }
                IOutbound db = new DbContext(() => new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen));

                DoWorkResponse response = globalScheduler.DoWork(message, null, db, triggerJobService, updateDb, natCd);
                return new JsonResult(response);
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, "An unhandled error occured in CallRunschduleForNatCd: {Message}; {Stacktrace}", ex.Message, ex.StackTrace);
                return new JsonResult(ex);
            }
            
        }

        /// <summary>
        /// Method to start the generation of a batch of 1
        /// </summary>
        /// <param name="realTimeBatchJobParams">The JsonParameters passesd from the calling application</param>
        /// <returns></returns>
        [HttpPost]
        [Route("RunRealtimeBatchJob")]
        public JsonResult RunRealtimeBatchJob([FromBody] RealTimeBatchJobParams realTimeBatchJobParams)
        {
            try
            {
                AppLog.Info()(0, "Processing {realTimeBatchJobParams}", realTimeBatchJobParams);

                var job = BackgroundJob.Enqueue<IGlobalScheduler>(x => x.RunRealtimeBatchJob(realTimeBatchJobParams, null));
                var response = new RealTimeBatchJobParamsResponse()
                {
                    Job = new GSJob()
                    {
                        HangfireJobServiceJobId = job,
                        HangfireScheduleDateTime = DateTime.Now,
                    }
                };
                return new JsonResult(response);
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, 0, "An unhandled error occured in RunRealtimeBatchJob: {Message}; {Stacktrace}", ex.Message, ex.StackTrace);
                return new JsonResult(ex);
            }
        }


        /// <summary>
        /// Method to trigger CSV batch processing
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("CsvProcessing")]
        public ActionResult<CsvProcessingResponse> CsvProcessing([FromBody] CsvProcessingRequest csvProcessingRequest)
        {
            try
            {
                IOutbound db = new DbContext(() => new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen));
                AppLog.Info()(0, "Processing {@csvProcessingRequest}", csvProcessingRequest);

                var response = globalScheduler.ProcessCSVBatchJobs(csvProcessingRequest.CsvBatchJobs, db, true, true);
                return new JsonResult(response);
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, 0, "An unhandled error occured in CsvProcessing: {Message}; {Stacktrace}", ex.Message, ex.StackTrace);
                return new JsonResult(ex);
            }
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bdvRequest"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("ProcessBdv")]
        public ActionResult ProcessBdv(ProcessBdvRequest bdvRequest)
        {
            try
            {
                if (bdvRequest.BetIds == null || bdvRequest.BetIds.Count == 0)
                {
                    //Throw an error back saying that the message is invalid
                    return new JsonResult(new BadRequestResult());
                }

                DoWorkResponse response = globalScheduler.RunBdv(bdvRequest);

                return new JsonResult(response);
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, 0, "An unhandled error occured in ProcessBdv: {Message}; {Stacktrace}", ex.Message, ex.StackTrace);
                return new JsonResult(ex);
            }
        }

        /// <summary>
        /// Method to get the current config entries for the application. Returns as a string.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetCurrentConfig")]
        public JsonResult GetCurrentConfig()
        {
            try
            {
                return new JsonResult(_appConfig);
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, 0,  "An unhandled error occured in GetCurrentConfig: {Message}; {Stacktrace}", ex.Message, ex.StackTrace);
                return new JsonResult(ex);
            }
            
        }

        /// <summary>
        /// Method to get the heartbeat of the service. Provided so that other apps can query the service
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("Heartbeat")]
        public JsonResult Heartbeat()
        {
            return new JsonResult("running");
        }

        /// <summary>
        /// REST end point to get the version of the application and any shared components that make sense to report on
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("VersionInfo")]
        public JsonResult VersionInfo()
        {
            return new JsonResult(_appConfig.AppSettings.Versions);
        }

        #region "Campaign Portal"
        /// <summary>
        /// Method to put delete a specified hangfire schedule  based on the shedule id 
        /// </summary>
        /// <param name="scheduleId"></param> 
        /// <returns></returns>
        /// <remarks>
        /// </remarks>
        [HttpPost]
        [Route("CallDeleteCampaignSchedule")]
        public JsonResult CallDeleteCampaignSchedule([FromBody] string scheduleId)
        {

            AppLog.Info()(0, "Deleting global scheduler job for  campaign schedule {scheduleId}", scheduleId);

            var response = globalScheduler.DeleteCampaignSchedule(scheduleId);

            return new JsonResult(response);



        }
        /// <summary>
        /// Method to trigger CSV batch processing
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("CreateCampaignSchedule")]
        public JsonResult CreateCampaignSchedule([FromBody] CampaignScheduldeMsg schedule)
        {


            IOutbound db = new DbContext(() => new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen));
            AppLog.Info()(0, "Processing {@CreateCampaignSchedule}", schedule);

            var response = globalScheduler.CreateCampaignSchedule(schedule, db, true, true);

            return new JsonResult(response);
        }




        #endregion
    }
}
