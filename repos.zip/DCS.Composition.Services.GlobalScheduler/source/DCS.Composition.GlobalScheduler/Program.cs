using DCS.Composition.Services.GlobalScheduler;
using DCS.Composition.Services.GlobalScheduler.Config;
using DCS.Logging.Shared.Infrastructure;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Https;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace DCS.Composition.GlobalScheduler
{
    /// <summary>
    /// 
    /// </summary>
    public class Program
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static async Task Main(string[] args)
        {
            Log.Logger = new LoggerConfiguration()
                    .ReadFrom.AppSettings()
                    .Enrich.WithMachineName()
                    .Enrich.FromLogContext()
                    .CreateLogger();

            try
            {
                AppLog.Info()(0, "Application Starting.");

                await CreateHostBuilder(args).Build().RunAsync();
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, 0, "The Application failed to start.");
            }
            finally
            {
                Log.CloseAndFlush();
            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseWindowsService()
                .ConfigureLogging(logging =>
                {
                    logging.AddSerilog();
                })
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.ConfigureServices(services =>
                    {
                        services.AddSingleton<IAppConfig, AppConfig>();
                    });
                    AppConfig cfg = new AppConfig();
                    webBuilder.ConfigureKestrel(configure =>
                    {
                        if (cfg.Kestrel.UseCertificateForSSL)
                        {
                            configure.ListenAnyIP(cfg.Kestrel.RESTAPIPort, listOptions =>
                            {

                                listOptions.UseHttps(httpsOptions =>
                                {
                                    var location = (cfg.Kestrel.CertificateLocation.ToLower()) switch
                                    {
                                        "currentuser" => StoreLocation.CurrentUser,
                                        "localmachine" => StoreLocation.LocalMachine,
                                        _ => StoreLocation.LocalMachine,
                                    };
                                    var cert = CertificateLoader.LoadFromStoreCert(cfg.Kestrel.CertificateSubject, cfg.Kestrel.CertificateStoreName, location, cfg.Kestrel.CertificateAllowInvalid);
                                    httpsOptions.ServerCertificate = cert;
                                });
                            });
                        }
                        else
                        {
                            configure.ListenAnyIP(cfg.Kestrel.RESTAPIPort);

                        }
                    });

                    webBuilder.UseStartup<Startup>();
                });

    }
}
