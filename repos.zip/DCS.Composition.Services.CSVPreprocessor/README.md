# .NET Framework Packages

Although this project targets .NET Core 3.1, it references the following .NET Framework NuGet Packages

- Ato.CD.Outbound.CorroGen.RS (To generate DPID's)
- Ato.En.Integrationservices.BusinessEventTracking (To generate BET's)

These packages use System.Data.SqlClient under to covers an so will still work although you will see warnings