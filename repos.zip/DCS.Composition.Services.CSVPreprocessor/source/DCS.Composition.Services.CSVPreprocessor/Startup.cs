﻿using System;
using System.IO;
using System.IO.Abstractions;
using System.Net;
using System.Net.Http;
using System.Reflection;
using Ato.EN.IntegrationServices.BusinessEventTracking;
using DCS.Composition.Services.CSVPreprocessor.Domain;
using DCS.Composition.Services.CSVPreprocessor.Domain.Generators;
using DCS.Composition.Services.CSVPreprocessor.Domain.Parsers;
using DCS.Composition.Services.CSVPreprocessor.Domain.Services;
using DCS.Composition.Services.Shared.CSVPreprocessor;
using DCS.Composition.Services.Shared.Queues;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Database;
using Hangfire;
using Hangfire.JobsLogger;
using Hangfire.SqlServer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using DCS.Logging.Shared.Infrastructure;

namespace DCS.Composition.Services.CSVPreprocessor
{
    public class Startup
    {
        private readonly ApplicationConfiguration _applicationConfiguration;

        public Startup()
        {
            _applicationConfiguration = new ApplicationConfiguration();
        }

        public void ConfigureServices(IServiceCollection services)
        {
            var outboundCorroGenConnectionString = _applicationConfiguration.ConnectionStringsSection.OutboundCorroGen;
 
            services.AddMemoryCache();

            services.AddSingleton(_applicationConfiguration);
            services.AddSingleton<IOutbound>(new DbContext(() => new SqlConnection(outboundCorroGenConnectionString)));

            services.AddTransient<IPerBatchLogger, PerBatchLogger>();
            services.AddTransient<BetNumberProcessor>();
            services.AddTransient<IFileSystem, FileSystem>();
            services.AddTransient<IBETGenerator, BETGenerator>();
            services.AddTransient<IDPIDGenerator, DPIDGenerator>();
            services.AddTransient<IFileProcessor, FileProcessor>();
            services.AddTransient<ICSVPreprocessor, Domain.CSVPreprocessor>();
            services.AddTransient<IControlFileParser, ControlFileParser>();

            services.AddHttpClient<IEmailService, EmailService>(client =>
            {
                client.BaseAddress = new Uri(_applicationConfiguration.EmailApiBaseAddress);
            })
            .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler { UseDefaultCredentials = true }); ;

            services.AddControllers();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "CSVPreprocessor API",
                    Version = "v1",
                    Description = "The CSVPreprocessor API used to manage the CSVPreprocessor via a REST endpoint",
                    TermsOfService = new Uri("https://example.com/terms"),
                    Contact = new OpenApiContact
                    {
                        Name = "DCRT",
                        Email = "dcrt@ato.gov.au",
                        Url = new Uri("https://www.ato.gov.au")
                    },
                    License = new OpenApiLicense
                    {
                        Name = "use under licx",
                        Url = new Uri("https://exmaple.com/license")
                    }
                });
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });

            services.AddHangfire(configuration => configuration
                .SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
                .UseSerilogLogProvider()
                .UseJobsLogger()
                .UseSimpleAssemblyNameTypeSerializer()
                .UseRecommendedSerializerSettings()
                .UseSqlServerStorage(_applicationConfiguration.ConnectionStringsSection.Hangfire, new SqlServerStorageOptions
                {
                    CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
                    SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
                    QueuePollInterval = TimeSpan.Zero,
                    UseRecommendedIsolationLevel = true,
                    UsePageLocksOnDequeue = true,
                    DisableGlobalLocks = true,
                    PrepareSchemaIfNecessary = true
                }));

            services.AddHangfireServer(options =>
            {
                options.Queues = new[] { CSVPreprocessorQueues.CSVPreprocessorStartQueue };
                options.WorkerCount = _applicationConfiguration.HangfireWorkerCount;
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseStaticFiles();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "DCS.Composition.Services.CSVPreprocessor API V1");
                c.RoutePrefix = string.Empty;
            });

            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
