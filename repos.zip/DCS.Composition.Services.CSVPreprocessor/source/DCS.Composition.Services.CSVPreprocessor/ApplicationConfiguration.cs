﻿using System;
using System.Configuration;
using DCS.Composition.Services.CSVPreprocessor.Common;

namespace DCS.Composition.Services.CSVPreprocessor
{
    public class ApplicationConfiguration
    {
        public int HangfireWorkerCount => GetIntOrThrow(nameof(HangfireWorkerCount), 10);
        public int RUCExceptionCdCacheTimeInSeconds => GetIntOrThrow(nameof(RUCExceptionCdCacheTimeInSeconds), 600);
        public string EmailApiBaseAddress => GetOrThrow(nameof(EmailApiBaseAddress));
        public string ControlFileFolder => GetOrThrow(nameof(ControlFileFolder));
        public string ControlFileName => GetOrThrow(nameof(ControlFileName));

        public KestrelSettings KestrelSettingsSection => new KestrelSettings();
        public ConnectionStrings ConnectionStringsSection => new ConnectionStrings();
  
        public class KestrelSettings
        {
            public string CertificateSubject => GetOrThrow(nameof(CertificateSubject));
            public string CertificateStoreName => GetOrThrow(nameof(CertificateStoreName));
            public string CertificateLocation => GetOrThrow(nameof(CertificateLocation));
            public bool UseCertificateForSSL => GetBoolOrThrow(nameof(UseCertificateForSSL));
            public bool CertificateAllowInvalid => GetBoolOrThrow(nameof(CertificateAllowInvalid));
            public int RESTAPIPort => GetIntOrThrow(nameof(RESTAPIPort));
        }

        public class ConnectionStrings
        {
            public string OutboundCorroGen => GetConnectionStringOrThrow(nameof(OutboundCorroGen));
            public string Hangfire => GetConnectionStringOrThrow(nameof(Hangfire));
        }

        private static string GetOrThrow(string key) =>
            ConfigurationManager.AppSettings[key] ??
            throw new ArgumentException($"Could not find setting name [{key}] in app.config");

        private static string GetConnectionStringOrThrow(string key)
        {
            var connectionString = ConfigurationManager.ConnectionStrings[key];

            if (connectionString == null)
                throw new ArgumentException($"Could not find connection string name [{key}] in app.config");

            if (connectionString.ConnectionString.IsNullOrWhitespace())
                throw new ArgumentException($"Connection string name [{key}] was empty");

            return connectionString.ConnectionString;
        }

        private static bool GetBoolOrThrow(string key)
        {
            var value = GetOrThrow(key);

            return bool.TryParse(GetOrThrow(key), out var boolValue)
                ? boolValue
                : throw new ArgumentException($"Could not parse [{value}] as a bool");
        }

        private static int GetIntOrThrow(string key)
        {
            var value = GetOrThrow(key);

            return int.TryParse(GetOrThrow(key), out var intValue)
                ? intValue
                : throw new ArgumentException($"Could not parse [{value}] as an int");
        }

        private static int GetIntOrThrow(string key, int fallbackIfZero)
        {
            var value = GetIntOrThrow(key);
            return value == 0 ? fallbackIfZero : value;
        }
    }
}