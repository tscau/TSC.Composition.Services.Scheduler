﻿namespace DCS.Composition.Services.CSVPreprocessor.Domain
{
    public class CSVPreprocessorParameters
    {
        public string InputFile { get; set; }
        public string BatchFolder { get; set; }
        public string[] BAUContacts { get; set; }
        public int[] CompulsoryColumns { get; set; }
        public int? ReqColumnCount { get; set; }
        public int? InsertBetInColumnNo { get; set; }
        public bool Headers { get; set; }
        public int? InsertDPID { get; set; }
        public string NatCd { get; set; }
        public int? NatCdColumn { get; set; }
        public bool StrictValidation { get; set; }
        public string Delimiter { get; set; }
    }
}