﻿using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using DCS.Composition.Services.CSVPreprocessor.Common;
using DCS.Logging.Shared.Infrastructure;
using Newtonsoft.Json;
using Serilog.Core;

namespace DCS.Composition.Services.CSVPreprocessor.Domain.Services
{
    public interface IEmailService
    {
        Task SendEmail(string[] addresses, string subject, string body);
        void SetLogger(IPerBatchLogger logger);
    }

    public class EmailService : IEmailService
    {
        private readonly HttpClient _httpClient;
        private IPerBatchLogger _logger;

        public EmailService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public void SetLogger(IPerBatchLogger logger)
        {
            _logger = logger;
        }

        public async Task SendEmail(string[] addresses, string subject, string body)
        {
            if (addresses.None())
            {
                _logger.Info("Skipping sending email as no address were provided");
                return;
            }

            // the send email service only allows send to one address at a time
            var sendEmailTasks = addresses.Select(address => SendEmail(address, subject, body));
            await Task.WhenAll(sendEmailTasks);
        }

        private async Task SendEmail(string address, string subject, string body)
        {
            _logger.Info("Sending email to {Address} with subject {Subject}", _logger.WrapArgs(address, subject));

            var sendEmailRequest = new SendEmailRequest(address, subject, body);
            var jsonPostData = new StringContent(JsonConvert.SerializeObject(sendEmailRequest));
            jsonPostData.Headers.ContentType = new MediaTypeHeaderValue("application/json");

            var response = await _httpClient.PostAsync("/api/Email", jsonPostData);
            response.EnsureSuccessStatusCode();

            var responseAsString = await response.Content.ReadAsStringAsync();
            _logger.Info("Sending email succeeded with response {@response}", _logger.WrapArgs(responseAsString));
        }
    }
}