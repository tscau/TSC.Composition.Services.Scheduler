﻿using System;
using System.Collections.Generic;

namespace DCS.Composition.Services.CSVPreprocessor.Domain.Services
{
    public class SendEmailRequest
    {
        private const string OUTBOUND_SOURCE_ID = "54";
        private const string EMAIL_CHANNEL_CATEGORY_CODE = "105";
        private const string FROM_ADDRESS = "noreply@ato.gov.au";

        public SendEmailRequest(string address, string subject, string body)
        {
            DCSRequest.Control.MessageSourceID = OUTBOUND_SOURCE_ID;
            DCSRequest.Control.MessageDateTime = DateTime.Now;

            DCSRequest.Interaction.Address.ChannelCategoryCode = EMAIL_CHANNEL_CATEGORY_CODE;
            DCSRequest.Interaction.Address.InternetEmailAddress = address;
            DCSRequest.Interaction.IsBodyhtml = false;
            DCSRequest.Interaction.Body = body;
            DCSRequest.Interaction.OutboundCorrespondenceSubjectName = subject;
            DCSRequest.Interaction.Sender.InternetEmailAddress = FROM_ADDRESS;
        }

        public DCSRequestType DCSRequest { get; set; } = new DCSRequestType();

        public class DCSRequestType
        {
            public ControlType Control { get; set; } = new ControlType();
            public InteractionType Interaction { get; set; } = new InteractionType();
        }

        public class ControlType
        {
            public string RequestedService { get; set; }
            public string MessageSourceID { get; set; }
            public DateTime MessageDateTime { get; set; }
        }

        public class ClientType
        {
            public string ClientIdentifierTypeCode { get; set; }
            public string ClientIdentifierValueID { get; set; }
            public string UnstructuredFullName { get; set; }
        }

        public class ClientsType
        {
            public ClientType Client { get; set; } = new ClientType();
        }

        public class CopyToType
        {
            public string InternetEmailAddress { get; set; }
        }

        public class BCopyToType
        {
            public string InternetEmailAddress { get; set; }
        }

        public class AddressType
        {
            public string ChannelCategoryCode { get; set; }
            public string InternetEmailAddress { get; set; }
            public CopyToType CopyTo { get; set; } = new CopyToType();
            public BCopyToType BCopyTo { get; set; } = new BCopyToType();
        }

        public class SenderType
        {
            public string UnstructuredFullName { get; set; }
            public string InternetEmailAddress { get; set; }
        }

        public class AttachmentType
        {
            public string DocumentFileName { get; set; }
            public string MediaType { get; set; }
            public string Base64Binary { get; set; }
        }

        public class InteractionType
        {
            public ClientsType Clients { get; set; } = new ClientsType();
            public AddressType Address { get; set; } = new AddressType();
            public string OutboundCorrespondenceTmpltID { get; set; }
            public string Body { get; set; }
            public bool IsBodyhtml { get; set; }
            public string OutboundCorrespondenceSubjectName { get; set; }
            public SenderType Sender { get; set; } = new SenderType();
            public List<AttachmentType> Attachment { get; set; } = new List<AttachmentType>();
        }
    }
}