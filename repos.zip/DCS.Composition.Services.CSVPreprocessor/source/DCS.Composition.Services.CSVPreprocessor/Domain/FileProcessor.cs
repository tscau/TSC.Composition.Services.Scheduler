﻿using System.IO;
using System.IO.Abstractions;
using System.Linq;
using DCS.Composition.Services.CSVPreprocessor.Common;
using DCS.Composition.Services.CSVPreprocessor.Domain.Generators;
using DCS.Logging.Shared.Infrastructure;
using Microsoft.VisualBasic.FileIO;
using Serilog.Core;

namespace DCS.Composition.Services.CSVPreprocessor.Domain
{
    public interface IFileProcessor
    {
        FileProcessorResult Process(CSVPreprocessorParameters message);
        void SetLogger(IPerBatchLogger logger);
    }

    public class FileProcessor : IFileProcessor
    {
        private readonly IFileSystem _fileSystem;
        private readonly IBETGenerator _betGenerator;
        private readonly IDPIDGenerator _dpidGenerator;
        private IPerBatchLogger _logger;

        public FileProcessor(
            IFileSystem fileSystem,
            IBETGenerator betGenerator,
            IDPIDGenerator dpidGenerator)
        {
            _fileSystem = fileSystem;
            _betGenerator = betGenerator;
            _dpidGenerator = dpidGenerator;
        }

        public void SetLogger(IPerBatchLogger logger)
        {
            _logger = logger;

            _betGenerator.SetLogger(logger);
            _dpidGenerator.SetLogger(logger);
        }

        public FileProcessorResult Process(CSVPreprocessorParameters message)
        {
            _logger.Info("Processing {InputFile}", message.InputFile);

            var outputFilePath = _fileSystem.Path.Combine(message.BatchFolder, "Driver.csv");
            if (_fileSystem.File.Exists(outputFilePath)) _fileSystem.File.Delete(outputFilePath);

            var errorFilePath = _fileSystem.Path.Combine(message.BatchFolder, "Preprocessor_Error.csv"); ;
            if (_fileSystem.File.Exists(errorFilePath)) _fileSystem.File.Delete(errorFilePath);

            var delimiter = message.Delimiter.IsNullOrWhitespace() ? "," : message.Delimiter;

            var generateBet = message.InsertBetInColumnNo.HasValue;
            var generateDpid = message.InsertDPID.HasValue;

            // Pulling these out as variable here so they can be accessed by the local method WriteError
            long lineNumber;
            string originalLine;
            StreamWriter errorStream;

            var errorRecordCount = 0;
            var processedRecordCount = 0;
            var generatedBet = 0L;

            using (var outputStream = new StreamWriter(_fileSystem.File.OpenWrite(outputFilePath)))
            using (errorStream = new StreamWriter(_fileSystem.File.OpenWrite(errorFilePath)))
            using (var inputStream = new TextFieldParser(_fileSystem.File.OpenText(message.InputFile))
            {
                TextFieldType = FieldType.Delimited,
                Delimiters = new[] { delimiter },
                HasFieldsEnclosedInQuotes = true
            })
            {
                if (message.Headers)
                {
                    outputStream.WriteLine(inputStream.ReadLine());
                }

                while (!inputStream.EndOfData)
                {
                    processedRecordCount += 1;

                    lineNumber = inputStream.LineNumber;
                    var fields = inputStream.ReadFields().EmptyIfNull();
                    originalLine = fields.Join(delimiter);

                    var anyColumnsMissing = fields.Length != message.ReqColumnCount;
                    if (anyColumnsMissing)
                    {
                        WriteError($"Expecting {message.ReqColumnCount} columns but {fields.Length} found.");
                        continue;
                    }

                    var missingCompulsoryFields = message.CompulsoryColumns.Where(columnNumber =>
                        columnNumber >= fields.Length ||
                        fields[columnNumber].IsNullOrWhitespace()).ToArray();

                    if (missingCompulsoryFields.Any())
                    {
                        WriteError($"Compulsory field(s) {missingCompulsoryFields.Join(", ")} are missing.");
                        continue;
                    }

                    var invalidNatCdColumn = generateDpid &&
                                             message.NatCdColumn.HasValue &&
                                             message.NatCdColumn >= fields.Length;

                    if (invalidNatCdColumn)
                    {
                        WriteError($"Expected NatCd at column {message.NatCdColumn}.");
                        continue;
                    }

                    if (generateBet)
                    {
                        var betColumnNumber = message.InsertBetInColumnNo.Value;
                        fields = fields.EnsureLengthAtLeast(betColumnNumber + 1, "");

                        var betGeneratorResult = _betGenerator.GenerateBET();
                        if (betGeneratorResult.Failure)
                        {
                            WriteError($"Error generating BET - {betGeneratorResult.Error}.");
                            continue;
                        }

                        generatedBet = betGeneratorResult.Value;
                        fields[betColumnNumber] = generatedBet.ToString();
                    }

                    if (generateDpid)
                    {
                        var natCd = message.NatCdColumn.HasValue
                            ? fields[message.NatCdColumn.Value]
                            : message.NatCd;

                        var dpidColumnNumber = message.InsertDPID.Value;
                        fields = fields.EnsureLengthAtLeast(dpidColumnNumber + 1, "");

                        var dpidGeneratorResult = _dpidGenerator.GenerateDPID(natCd, generatedBet);
                        if (dpidGeneratorResult.Failure)
                        {
                            WriteError($"Error generating DPID - {dpidGeneratorResult.Error}.");
                            continue;
                        }

                        fields[dpidColumnNumber] = dpidGeneratorResult.Value;
                    }

                    outputStream.WriteLine(fields.Join(delimiter));
                }
            }

            ArchiveInputFile();

            var allRecordsFailed = errorRecordCount == processedRecordCount;
            if (allRecordsFailed)
            {
                _fileSystem.File.Delete(outputFilePath);
                return FileProcessorResult.Fail($"All {errorRecordCount} records failed to process.",
                    processedRecordCount, errorRecordCount, errorFilePath);
            }

            var strictValidationAndSomeErrors = message.StrictValidation && errorRecordCount > 0;
            if (strictValidationAndSomeErrors)
            {
                _fileSystem.File.Delete(outputFilePath);
                return FileProcessorResult.Fail($"Strict validation was set and {errorRecordCount} out of {processedRecordCount} records failed to process.",
                    processedRecordCount, errorRecordCount, errorFilePath);
            }

            // File.OpenWrite creates the file regardless of whether it was written to or not so lets cleanup
            if (errorRecordCount == 0)
                _fileSystem.File.Delete(errorFilePath);

            return FileProcessorResult.Ok(processedRecordCount, errorRecordCount, outputFilePath, errorFilePath);

            // Local method to write errors to the the error stream and increment
            // error count without having a seperate method that you would need to pass
            // all these message to.
            void WriteError(string error)
            {
                var message = $"Error parsing line {lineNumber}: {error}";
                errorStream.WriteLine($"{originalLine}{delimiter}{message}");
                errorRecordCount += 1;

                _logger.Warn(message);
            }

            void ArchiveInputFile()
            {
                var inputFilePath = message.InputFile;
                var archivedFolder = _fileSystem.Path.Combine(_fileSystem.Path.GetDirectoryName(inputFilePath), "Archived");
                var archivedFilePath = _fileSystem.Path.Combine(archivedFolder, _fileSystem.Path.GetFileName(inputFilePath));

                _logger.Info<string, string>("Moving {InputFile} to {ArchivedFilePath}", message.InputFile, archivedFilePath);

                _fileSystem.Directory.CreateDirectory(archivedFolder);
                _fileSystem.File.Move(inputFilePath, archivedFilePath);
            }
        }
    }

    public class FileProcessorResult
    {
        public bool Success { get; }
        public bool Failure => !Success;
        public int ProcessedRecordCount { get; }
        public int ErrorRecordCount { get; }
        public string DriverFilePath { get; }
        public string ErrorFilePath { get; }
        public string Error { get; }

        private FileProcessorResult(
            bool success,
            int processedRecordCount,
            int errorRecordCount,
            string driverFilePath,
            string errorFilePath,
            string error)
        {
            Success = success;
            ProcessedRecordCount = processedRecordCount;
            ErrorRecordCount = errorRecordCount;
            DriverFilePath = driverFilePath;
            ErrorFilePath = errorFilePath;
            Error = error;
        }

        public static FileProcessorResult Ok(int processedRecordCount, int errorRecordCount, string driverFilePath, string errorFilePath) =>
            new FileProcessorResult(true, processedRecordCount, errorRecordCount, driverFilePath, errorFilePath, null);

        public static FileProcessorResult Fail(string error, int processedRecordCount, int errorRecordCount, string errorFilePath) =>
            new FileProcessorResult(false, processedRecordCount, errorRecordCount, null, errorFilePath, error);
    }
}