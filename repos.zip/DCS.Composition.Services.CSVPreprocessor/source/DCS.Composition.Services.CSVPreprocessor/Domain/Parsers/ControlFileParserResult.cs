﻿namespace DCS.Composition.Services.CSVPreprocessor.Domain.Parsers
{
    public class ControlFileParserResult
    {
        public int[] CompulsoryColumns { get; set; }
        public int? ReqColumnCount { get; set; }
        public int? InsertBetInColumnNo { get; set; }
        public bool Headers { get; set; }
        public int? InsertDPID { get; set; }
        public int? NatCdColumn { get; set; }
        public bool StrictValidation { get; set; }
        public string Delimiter { get; set; }
    }
}