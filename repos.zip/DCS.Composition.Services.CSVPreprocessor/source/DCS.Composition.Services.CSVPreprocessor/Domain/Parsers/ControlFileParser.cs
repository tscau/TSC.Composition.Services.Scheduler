﻿using System;
using System.IO.Abstractions;
using System.Linq;
using DCS.Logging.Shared.Infrastructure;
using Serilog.Core;

namespace DCS.Composition.Services.CSVPreprocessor.Domain.Parsers
{
    public interface IControlFileParser
    {
        ControlFileParserResult Parse(string controlFilePath);
        void SetLogger(IPerBatchLogger logger);
    }

    public class ControlFileParser : IControlFileParser
    {
        private readonly IFileSystem _fileSystem;
        private IPerBatchLogger _logger;

        public ControlFileParser(IFileSystem fileSystem)
        {
            _fileSystem = fileSystem;
        }

        public void SetLogger(IPerBatchLogger logger)
        {
            _logger = logger;
        }

        public ControlFileParserResult Parse(string controlFilePath)
        {
            _logger.Info("Parsing control file {ControlFilePath}", _logger.WrapArgs(controlFilePath));

            if (!_fileSystem.File.Exists(controlFilePath))
                throw new Exception($"Could not find control file {controlFilePath}");

            var preProcessorOptionsLine = _fileSystem.File
                .ReadAllLines(controlFilePath)
                .FirstOrDefault(line => line.StartsWith("-CCVARSET=PREPROCESSOR_OPTIONS"));

            if (preProcessorOptionsLine == null)
                throw new Exception($"Could not find '-CCVARSET=PREPROCESSOR_OPTIONS` in control file {controlFilePath}");

            _logger.Info("Parsing pre-processor options {PreProcessorOptions}", preProcessorOptionsLine);

            var options = preProcessorOptionsLine
                .Split("-", StringSplitOptions.RemoveEmptyEntries)
                .Select(optionNameAndValue =>
                {
                    var indexOfFirstSpace = optionNameAndValue.IndexOf(" ");
                    if (indexOfFirstSpace == -1) return new Option() {Name = optionNameAndValue};

                    return new Option()
                    {
                        Name = optionNameAndValue.Substring(0, indexOfFirstSpace).Trim(),
                        Value = optionNameAndValue.Substring(indexOfFirstSpace).Trim(),
                    };
                })
                .ToLookup(option => option.Name);

            var compulsoryColumnsOption = options["compulsoryColumns"].FirstOrDefault();
            var reqColumnCountOption = options["reqColumnCount"].FirstOrDefault();
            var insertBetInColumnNoOption = options["insertBetInColumnNo"].FirstOrDefault();
            var headersOption = options["headers"].FirstOrDefault();
            var insertDPIDOption = options["insertDPID"].FirstOrDefault();
            var natCdColumnOption = options["natCdColumn"].FirstOrDefault();
            var strictValidationOption = options["strictValidation"].FirstOrDefault();
            var delimiterOption = options["delimiter"].FirstOrDefault();

            return new ControlFileParserResult()
            {
                CompulsoryColumns = compulsoryColumnsOption?.ValueAsIntArrayOrThrow(),
                ReqColumnCount = reqColumnCountOption?.ValueAsIntOrThrow(),
                InsertBetInColumnNo = insertBetInColumnNoOption?.ValueAsIntOrThrow(),
                Headers = headersOption?.ValueAsBooleanOrThrow() ?? false,
                InsertDPID = insertDPIDOption?.ValueAsIntOrThrow(),
                NatCdColumn = natCdColumnOption?.ValueAsIntOrThrow(),
                StrictValidation = strictValidationOption?.ValueAsBooleanOrThrow() ?? false,
                Delimiter = string.IsNullOrWhiteSpace(delimiterOption?.Value) ? "," : delimiterOption?.Value
            };
        }

        private class Option
        {
            public string Name { get; set; }
            public string Value { get; set; }

            public int[] ValueAsIntArrayOrThrow() 
            {
                var values = Value.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                if (!values.All(value => int.TryParse(value.Trim(), out var _)))
                    throw new Exception($"Could not parse option '{Name}' value '{Value}' as an int array");
                
                return values
                    .Select(item => int.Parse(item.Trim()))
                    .ToArray();
            }

            public int ValueAsIntOrThrow() => 
                int.TryParse(Value, out var intValue)
                    ? intValue
                    : throw new Exception($"Could not parse option '{Name}' value '{Value}' as an int");

            public bool ValueAsBooleanOrThrow() =>
                bool.TryParse(Value, out var boolValue)
                    ? boolValue
                    : throw new Exception($"Could not parse option '{Name}' value '{Value}' as a boolean");
        }
    }
}