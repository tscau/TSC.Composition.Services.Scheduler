﻿using System;

namespace DCS.Composition.Services.CSVPreprocessor.Domain
{
    public class StopHangfireContinuationException: Exception
    {
    }
}