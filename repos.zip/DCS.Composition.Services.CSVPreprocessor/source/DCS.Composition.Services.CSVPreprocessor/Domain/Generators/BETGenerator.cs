﻿using System;
using Ato.EN.IntegrationServices.BusinessEventTracking;
using DCS.Composition.Services.CSVPreprocessor.Common;
using DCS.Logging.Shared.Infrastructure;
using Serilog.Core;

namespace DCS.Composition.Services.CSVPreprocessor.Domain.Generators
{
    public interface IBETGenerator
    {
        Result<long> GenerateBET();
        void SetLogger(IPerBatchLogger logger);
    }

    public class BETGenerator : IBETGenerator
    {
        private readonly BetNumberProcessor _betNumberProcessor;
        private IPerBatchLogger _logger;

        public BETGenerator(BetNumberProcessor betNumberProcessor)
        {
            _betNumberProcessor = betNumberProcessor;
        }

        public void SetLogger(IPerBatchLogger logger)
        {
            _logger = logger;
        }

        public Result<long> GenerateBET()
        {
            try
            {
                var bet = (long) _betNumberProcessor.NewBETNumber(1)[0];
                return Result.Ok(bet);
            }
            catch (Exception e)
            {
                var error = $"Exception generating BET: {e.Message}";
                _logger.Error(e, error);

                return Result.Fail<long>(error);
            }
        }
    }
}