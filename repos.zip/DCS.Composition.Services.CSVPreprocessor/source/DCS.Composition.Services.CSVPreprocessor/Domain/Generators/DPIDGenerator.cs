﻿using System;
using Ato.CD.Outbound.CorroGen.RS;
using DCS.Composition.Services.CSVPreprocessor.Common;
using DCS.Logging.Shared.Infrastructure;
using DCS.Shared.DataAccess.Outbound;
using Microsoft.Extensions.Caching.Memory;
using Serilog.Core;

namespace DCS.Composition.Services.CSVPreprocessor.Domain.Generators
{
    public interface IDPIDGenerator
    {
        Result<string> GenerateDPID(string natCd, long BET);
        void SetLogger(IPerBatchLogger logger);
    }

    public class DPIDGenerator : IDPIDGenerator
    {
        private readonly IOutbound _outbound;
        private readonly IMemoryCache _cache;
        private readonly ApplicationConfiguration _configuration;
        private IPerBatchLogger _logger;

        public DPIDGenerator(IOutbound outbound, IMemoryCache cache, ApplicationConfiguration configuration)
        {
            _outbound = outbound;
            _cache = cache;
            _configuration = configuration;
        }

        public void SetLogger(IPerBatchLogger logger)
        {
            _logger = logger;
        }

        public Result<string> GenerateDPID(string natCd, long BET)
        {
            try
            {
                var rucExceptionCode = GetRUCExceptionCdForNatCdFromCache(natCd);
                var customerInfo = $"{BET}{rucExceptionCode}";
                var dpid =  new RS().BuildUpBarcodeString(RS.FCCDecimal.CustomerThree, null, customerInfo);

                return Result.Ok(dpid);
            }
            catch (Exception e)
            {
                var error = $"Exception generating DPID for natCd[{natCd}] and BET[{BET}]: {e.Message}";
                _logger.Error(e, error);

                return Result.Fail<string>(error);
            }
        }

        private short GetRUCExceptionCdForNatCdFromCache(string natCd) =>
            _cache.GetOrCreate(natCd.ToUpper(), entry =>
            {
                _logger.Info("Cache miss, retrieving RUCExceptionCd for {NatCd}", natCd);

                entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(_configuration.RUCExceptionCdCacheTimeInSeconds);
                return GetRUCExceptionCdForNatCdFromOutbound(natCd);
            });

        private short GetRUCExceptionCdForNatCdFromOutbound(string natCd)
        {
            var templateId = _outbound.GetCorresTemplateIdByNATCd(natCd);
            if (templateId == null) throw new Exception($"Could not find CorresTemplate for natCD[{natCd}]");

            var template = _outbound.GetCorresTemplateById(templateId.Value);
            if (template == null) throw new Exception($"Could not find CorresTemplate for CorresTemplateId[{templateId}]");

            return template.RUCExceptionCd;
        }
    }
}