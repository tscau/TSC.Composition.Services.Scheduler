﻿using System;
using System.IO;
using System.IO.Abstractions;
using DCS.Composition.Services.CSVPreprocessor.Common;
using DCS.Composition.Services.CSVPreprocessor.Domain.Parsers;
using DCS.Composition.Services.CSVPreprocessor.Domain.Services;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.CSVPreprocessor;
using DCS.Logging.Shared.Infrastructure;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Documents;
using DCS.Shared.DataAccess.Outbound.Enums;
using Hangfire.Server;
using Serilog.Core;

namespace DCS.Composition.Services.CSVPreprocessor.Domain
{
    public class CSVPreprocessor : ICSVPreprocessor
    {
        private readonly IFileProcessor _fileProcessor;
        private readonly IOutbound _outbound;
        private readonly IFileSystem _fileSystem;
        private readonly IEmailService _emailService;
        private readonly ApplicationConfiguration _configuration;
        private readonly IControlFileParser _controlFileParser;
        private readonly IPerBatchLogger _perBatchLogger;

        private const string DEFAULT_USER_TO_RECORD_AGAINST = "CSVPREPRO";

        public CSVPreprocessor(
            IFileProcessor fileProcessor,
            IOutbound outbound,
            IFileSystem fileSystem,
            IEmailService emailService,
            ApplicationConfiguration configuration,
            IControlFileParser controlFileParser,
            IPerBatchLogger perBatchLogger)
        {
            _fileProcessor = fileProcessor;
            _outbound = outbound;
            _fileSystem = fileSystem;
            _emailService = emailService;
            _configuration = configuration;
            _controlFileParser = controlFileParser;
            _perBatchLogger = perBatchLogger;
        }

        public void Start(CompositionMsg message, PerformContext context)
        {
            using var logger = _perBatchLogger.CreateForBatchId(message.BatchId, Path.Join(message.JobPath, "Logs", "composition.csvpreprocessor.log"));
            
            try
            {
                var result = ExecuteCore(message, context, logger);

                // On failure, we need to throw an exception to prevent job service from executing the next hangfire job continuation
                // but we also don't want to execute the code in the catch so we will use an exception filter to skip
                if (result.Failure) throw new StopHangfireContinuationException();
            }
            catch (Exception exception) when (!(exception is StopHangfireContinuationException))
            {
                logger.Error(exception, "Preprocessing CSV failed for Batch [{BatchId}]", new object[] { message.BatchId });
                UpdateBatchHistoryStatusTo(message, context, DcsBatchHistoryStatusEnum.CSVPreprocessorServiceFailed, logger);

                throw;
            }
        }

        public FileProcessorResult ExecuteCore(CompositionMsg message, PerformContext context, IPerBatchLogger logger)
        {
            // hack, we are using dependency inject, but creating the logger per execution so no
            // other way to inject
            _fileProcessor.SetLogger(logger);
            _emailService.SetLogger(logger);
            _controlFileParser.SetLogger(logger);

            logger.Info("Preprocessing CSV starting with message {@Message}", message);

            UpdateBatchHistoryStatusTo(message, context, DcsBatchHistoryStatusEnum.CSVPreprocessorServiceStarted, logger);
            ValidateMessage(message, _fileSystem);

            var csvPreprocessorParameters = LoadCSVPreprocessorParametersFromControlFile(message);
            ValidateParameters(csvPreprocessorParameters);

            var result = _fileProcessor.Process(csvPreprocessorParameters);
            logger.Info("Preprocessing CSV finished processing with results {@Result}", result);

            if (result.Success)
            {
                logger.Info("Preprocessing CSV succeeded");
                UpdateBatchHistoryStatusTo(message, context, DcsBatchHistoryStatusEnum.CSVPreprocessorServiceCompleted, logger);
            }
            else
            {
                logger.Error<long, string>("Preprocessing CSV failed for Batch [{BatchId}]: {Error}", message.BatchId, result.Error);
                UpdateBatchHistoryStatusTo(message, context, DcsBatchHistoryStatusEnum.CSVPreprocessorServiceFailed, logger);

                SendFailureEmailToBAU(message, result);
            }

            return result;
        }

        private CSVPreprocessorParameters LoadCSVPreprocessorParametersFromControlFile(CompositionMsg message)
        {
            var controlFile = Path.Combine(message.JobPath, _configuration.ControlFileFolder, _configuration.ControlFileName);
            var parsedOptions = _controlFileParser.Parse(controlFile);

            return new CSVPreprocessorParameters()
            {
                BatchFolder = message.JobPath,
                BAUContacts = message.CSVPreprocessorMsg.BAUContacts,
                InputFile = message.CSVPreprocessorMsg.InputFile,
                NatCd = message.CSVPreprocessorMsg.NatCd,
                CompulsoryColumns = parsedOptions.CompulsoryColumns,
                ReqColumnCount = parsedOptions.ReqColumnCount,
                InsertBetInColumnNo = parsedOptions.InsertBetInColumnNo,
                Headers = parsedOptions.Headers,
                InsertDPID = parsedOptions.InsertDPID,
                NatCdColumn = parsedOptions.NatCdColumn,
                StrictValidation = parsedOptions.StrictValidation,
                Delimiter = parsedOptions.Delimiter,
            };
        }

        private void SendFailureEmailToBAU(CompositionMsg message, FileProcessorResult result)
        {
            var csvVPreprocessorMsg = message.CSVPreprocessorMsg;

            var subject = $"Errors in CSV pre-processor for {message.GSScheduleId}";
            var body = $@"
CSV pre-processor has returned errors when processing the file {csvVPreprocessorMsg.InputFile} for {csvVPreprocessorMsg.NatCd}.
Please check the following file for error records {result.ErrorFilePath}
".Trim();
                
            // tsk, tsk, calling asynchronous method synchronously. Can't be avoided here unfortunately :(
            // Task.GetAwaiter().GetResult() is preferred over Task.Wait and Task.Result because it propagates
            // exceptions rather than wrapping them in an AggregateException
            _emailService
                .SendEmail(csvVPreprocessorMsg.BAUContacts, subject, body)
                .GetAwaiter().GetResult();
        }

        public static void ValidateMessage(CompositionMsg message, IFileSystem fileSystem)
        {
            if (message.JobPath.IsNullOrWhitespace())
                throw new ArgumentException($"Input parameter {nameof(message.JobPath)} missing");

            var csvVPreprocessorMsg = message.CSVPreprocessorMsg;

            if (csvVPreprocessorMsg == null)
                throw new ArgumentException($"Input parameter {nameof(message.CSVPreprocessorMsg)} missing");

            if (csvVPreprocessorMsg.NatCd.IsNullOrWhitespace())
                throw new ArgumentException($"Input parameter {nameof(csvVPreprocessorMsg.NatCd)} missing");

            if (csvVPreprocessorMsg.InputFile.IsNullOrWhitespace())
                throw new ArgumentException($"Input parameter {nameof(csvVPreprocessorMsg.InputFile)} missing");

            if (!fileSystem.File.Exists(csvVPreprocessorMsg.InputFile))
                throw new ArgumentException($"Input file was not found: {csvVPreprocessorMsg.InputFile}");
        }

        public static void ValidateParameters(CSVPreprocessorParameters parameters)
        {
            if (parameters.CompulsoryColumns.None())
                throw new ArgumentException($"Input parameter {nameof(parameters.CompulsoryColumns)} missing");

            if (parameters.ReqColumnCount.GetValueOrDefault() <= 0)
                throw new ArgumentException($"Input parameter {nameof(parameters.ReqColumnCount)} missing");

            var requiresDpid = parameters.InsertDPID.HasValue;

            var requiresBetGeneration = requiresDpid;
            if (requiresBetGeneration && parameters.InsertBetInColumnNo == null)
                throw new ArgumentException($"InsertDPID was set but InsertBetInColumnNo was missing");

            var requiresNatCd = requiresDpid;
            if (requiresNatCd && parameters.NatCdColumn == null && parameters.NatCd.IsNullOrWhitespace())
                throw new ArgumentException($"Both NatCdColumn and NatCd are missing");
        }

        private void UpdateBatchHistoryStatusTo(CompositionMsg message, PerformContext context, DcsBatchHistoryStatusEnum status, IPerBatchLogger logger)
        {
            logger.Info("Updating CSV Preprocessing status to {Status}", status);

            long.TryParse(context?.BackgroundJob?.Id, out var hangfireJobId);

            var batchHistoryRecord = new DcsBatchHistory
            {
                BatchId = message.BatchId,
                CreatedDt = DateTime.Now,
                CreatedId = DEFAULT_USER_TO_RECORD_AGAINST,
                GSScheduleId = message.GSScheduleId,
                JSScheduleId = message.JGScheduleId,
                HangfireJobId = hangfireJobId,
                NewStatusId = (int)status,
                UpdateMsgTxt = "Created by CSVPreprocessor"
            };

            var _ = _outbound.AddDcsBatchHistory(batchHistoryRecord);
        }
    }
}