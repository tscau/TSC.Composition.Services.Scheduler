using System;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Https;
using Microsoft.Extensions.Hosting;
using Serilog;

namespace DCS.Composition.Services.CSVPreprocessor
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            Log.Logger = new LoggerConfiguration()
                .ReadFrom.AppSettings()
                .CreateLogger();

            try
            {
                Log.Information("Application Starting.");

                await CreateHostBuilder(args).Build().RunAsync();
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "The Application failed to start.");
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            var kestrelConfiguration = new ApplicationConfiguration().KestrelSettingsSection;

            return Host
                .CreateDefaultBuilder(args)
                .UseSerilog()
                .UseWindowsService()
                .ConfigureWebHostDefaults(builder =>
                {
                    builder.ConfigureKestrel(configure =>
                    {
                        if (kestrelConfiguration.UseCertificateForSSL)
                        {
                            configure.ListenAnyIP(kestrelConfiguration.RESTAPIPort, listOptions =>
                            {
                                listOptions.UseHttps(httpsOptions =>
                                {
                                    var location = kestrelConfiguration.CertificateLocation.ToLower() switch
                                    {
                                        "currentuser" => StoreLocation.CurrentUser,
                                        "localmachine" => StoreLocation.LocalMachine,
                                        _ => StoreLocation.LocalMachine,
                                    };

                                    var cert = CertificateLoader.LoadFromStoreCert(
                                        kestrelConfiguration.CertificateSubject,
                                        kestrelConfiguration.CertificateStoreName,
                                        location,
                                        kestrelConfiguration.CertificateAllowInvalid);

                                    httpsOptions.ServerCertificate = cert;
                                });
                            });
                        }
                        else
                        {
                            configure.ListenAnyIP(kestrelConfiguration.RESTAPIPort);

                        }
                    });

                    builder.UseStartup<Startup>();
                });
        }
    }
}
