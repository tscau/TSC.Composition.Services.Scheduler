﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using DCS.Composition.Services.CSVPreprocessor.Common;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.CSVPreprocessor;
using DCS.Logging.Shared.Infrastructure;
using Hangfire;
using Microsoft.AspNetCore.Mvc;
namespace DCS.Composition.Services.CSVPreprocessor.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CSVPreprocessorController : ControllerBase
    {
        private readonly ICSVPreprocessor _csvPreprocessor;
        private readonly ApplicationConfiguration _configuration;
        private readonly IPerBatchLogger _perBatchLogger;

        public CSVPreprocessorController(
            ICSVPreprocessor csvPreprocessor,
            ApplicationConfiguration configuration,
            IPerBatchLogger perBatchLogger)
        {
            _csvPreprocessor = csvPreprocessor;
            _configuration = configuration;
            _perBatchLogger = perBatchLogger;
        }

        [Route("[action]")]
        [HttpPost]
        public ActionResult<string> CallCsvPreprocessorServiceViaHangfire(CompositionMsg message)
        {
            var jobId = BackgroundJob.Enqueue<ICSVPreprocessor>(x => x.Start(message, null));
            return "Csv Preprocessor message placed on Hangfire Queue. JobID: " + jobId;
        }

        [Route("[action]")]
        [HttpPost]
        public JsonResult CallCsvPreprocessorService(CompositionMsg message)
        {
            using var logger = _perBatchLogger.CreateForBatchId(message.BatchId, Path.Join(message.JobPath, "Logs", "composition.csvpreprocessor.log"));

            var result = ((Domain.CSVPreprocessor) _csvPreprocessor).ExecuteCore(message, null, logger);
            return new JsonResult(result);
        }

        /// <summary>
        /// Method to get the current config entries for the application. Returns as a string.
        /// </summary>
        [HttpGet]
        [Route("[action]")]
        public ActionResult<ApplicationConfiguration> GetCurrentConfig() =>
            new JsonResult(_configuration);

        /// <summary>
        /// Method to get the heartbeat of the service. Provided so that other apps can query the service
        /// </summary>
        [HttpGet]
        [Route("[action]")]
        public JsonResult Heartbeat() =>
            new JsonResult("running");

        /// <summary>
        /// REST end point to get the version of the application and any shared components that make sense to report on
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("VersionInfo")]
        public ActionResult<Dictionary<string, AssemblyVersionDetails>> VersionInfo()
        {
            var assemblyVersions = new[]
                {
                    AssemblyVersionDetails.FromAssembly(Assembly.GetExecutingAssembly()),
                    AssemblyVersionDetails.FromAssemblyName("DCS.Composition.Services.Shared"),
                    AssemblyVersionDetails.FromAssemblyName("DCS.Shared.DataAccess.Outbound"),
                }
                .ToDictionary(x => x.name, x => x.assemblyVersionDetails);

            return new JsonResult(assemblyVersions);
        }
    }
}
