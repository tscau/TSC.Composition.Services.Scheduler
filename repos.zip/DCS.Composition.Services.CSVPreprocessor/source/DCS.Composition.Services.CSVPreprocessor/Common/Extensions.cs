﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DCS.Composition.Services.CSVPreprocessor.Common
{
    public static class Extensions
    {
		public static T[] EmptyIfNull<T>(this T[] arr) =>
            arr ?? Array.Empty<T>();

        public static bool None<T>(this T[] arr) =>
            arr.EmptyIfNull().Length == 0;

        public static bool IsNullOrWhitespace(this string self) =>
            string.IsNullOrWhiteSpace(self);

        public static string Join<T>(this IEnumerable<T> enumerable, string seperator) =>
            string.Join(seperator, enumerable);

        public static T[] EnsureLengthAtLeast<T>(this T[] arr, int length, T padWith)
        {
            if (arr.Length >= length) return arr;

            var numItemsToAdd = length - arr.Length;

            var additionItems = Enumerable
                .Range(0, numItemsToAdd)
                .Select(_ => padWith);

            return arr.Concat(additionItems).ToArray();
        }
	}
}