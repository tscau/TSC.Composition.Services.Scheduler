﻿using System;
using System.Collections.Concurrent;
using System.IO.Abstractions;
using System.IO.Abstractions.TestingHelpers;
using DCS.Composition.Services.CSVPreprocessor.Domain.Parsers;
using DCS.Logging.Shared.Infrastructure;
using FluentAssertions;
using Microsoft.Extensions.Logging.Abstractions;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using Serilog;
using Xunit;

namespace DCS.Composition.Services.CSVPreprocessor.UnitTests.Parsers
{
    public class ControlFileParserTests
    {
        [Theory]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,-compulsoryColumns 0 4 6 7 8 -reqColumnCount 13 -headers true -insertBetInColumnNo 11", new[] {0,4,6,7,8})]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,", null)]
        public void Can_parse_compulsory_columns(string options, int[] expected)
        {
            Parse(options).CompulsoryColumns.Should().Equal(expected);
        }

        [Theory]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,-compulsoryColumns 0 4 6 7 8 -reqColumnCount 13 -headers true -insertBetInColumnNo 11", 13)]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,", null)]
        public void Can_parse_req_column_count(string options, int? expected)
        {
            Parse(options).ReqColumnCount.Should().Be(expected);
        }

        [Theory]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,-compulsoryColumns 0 4 6 7 8 -reqColumnCount 13 -headers true -insertBetInColumnNo 11", 11)]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,", null)]
        public void Can_parse_insert_bet_in_column_no(string options, int? expected)
        {
            Parse(options).InsertBetInColumnNo.Should().Be(expected);
        }


        [Theory]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,-compulsoryColumns 0 4 6 7 8 -reqColumnCount 13 -headers true -insertBetInColumnNo 11", true)]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,", false)]
        public void Can_parse_headers(string options, bool expected)
        {
            Parse(options).Headers.Should().Be(expected);
        }

        [Theory]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,-compulsoryColumns 0 4 6 7 8 -insertBetInColumnNo 11 -insertDPID 10 -natCdColumn 0", 10)]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,", null)]
        public void Can_parse_insert_dpid(string options, int? expected)
        {
            Parse(options).InsertDPID.Should().Be(expected);
        }

        [Theory]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,-compulsoryColumns 0 4 6 7 8 -insertBetInColumnNo 11 -insertDPID 10 -natCdColumn 0", 0)]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,", null)]
        public void Can_parse_nat_cd_column(string options, int? expected)
        {
            Parse(options).NatCdColumn.Should().Be(expected);
        }

        [Theory]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,-compulsoryColumns 0 4 6 7 8 -reqColumnCount 13 -strictValidation true -insertBetInColumnNo 11", true)]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,", false)]
        public void Can_parse_strictValidation(string options, bool expected)
        {
            Parse(options).StrictValidation.Should().Be(expected);
        }

        [Theory]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,-compulsoryColumns 0 4 6 7 8 -reqColumnCount 13 -delimiter | -insertBetInColumnNo 11", "|")]
        [InlineData("-CCVARSET=PREPROCESSOR_OPTIONS,", ",")]
        public void Can_parse_delimiter(string options, string expected)
        {
            Parse(options).Delimiter.Should().Be(expected);
        }

        [Fact]
        public void Can_parse_multiple()
        {
            var options = "-CCVARSET=PREPROCESSOR_OPTIONS,-compulsoryColumns 0 4 6 7 8 -reqColumnCount 13 -headers true -insertBetInColumnNo 11 -insertDPID 10 -natCdColumn 0";

            Parse(options).Should().BeEquivalentTo(new ControlFileParserResult {
                InsertBetInColumnNo = 11,
                CompulsoryColumns = new int[] { 0, 4, 6, 7, 8 },
                Headers = true,
                Delimiter = ",",
                InsertDPID = 10,
                NatCdColumn = 0,
                ReqColumnCount = 13,
                StrictValidation = false
            });
        }

        [Fact]
        public void Throws_when_control_file_not_found()
        {
            var fileSystem = new MockFileSystem();

            Action parsingANonExistingControlFile = () => SUT(fileSystem)
                .Parse("job_orchestration.ctl");

            parsingANonExistingControlFile
                .Should()
                .Throw<Exception>()
                .WithMessage("Could not find control file job_orchestration.ctl");
        }

        [Fact]
        public void Throws_when_control_file_does_not_contain_pre_processor_options()
        {
            var fileSystem = new MockFileSystem();
            fileSystem.AddFile("job_orchestration.ctl", "no pre processor options");

            Action parsingAControlFileWithoutOptions = () => SUT(fileSystem)
                .Parse("job_orchestration.ctl");

            parsingAControlFileWithoutOptions
                .Should()
                .Throw<Exception>()
                .WithMessage("Could not find '-CCVARSET=PREPROCESSOR_OPTIONS` in control file job_orchestration.ctl");
        }

        [Fact]
        public void Throws_when_cannot_parse_int_array()
        {
            Action parsingInvalidIntArray = () => Parse("-CCVARSET=PREPROCESSOR_OPTIONS,-compulsoryColumns a b c");

            parsingInvalidIntArray
                .Should()
                .Throw<Exception>()
                .WithMessage("Could not parse option 'compulsoryColumns' value 'a b c' as an int array");
        }

        [Fact]
        public void Throws_when_cannot_parse_int()
        {
            Action parsingInvalidInt = () => Parse("-CCVARSET=PREPROCESSOR_OPTIONS,-reqColumnCount a");

            parsingInvalidInt
                .Should()
                .Throw<Exception>()
                .WithMessage("Could not parse option 'reqColumnCount' value 'a' as an int");
        }

        [Fact]
        public void Throws_when_cannot_parse_boolean()
        {
            Action parsingInvalidBoolean = () => Parse("-CCVARSET=PREPROCESSOR_OPTIONS,-headers a");

            parsingInvalidBoolean
                .Should()
                .Throw<Exception>()
                .WithMessage("Could not parse option 'headers' value 'a' as a boolean");
        }

        private ControlFileParserResult Parse(string controlFileContents)
        {
            var fileContents = $"{Guid.NewGuid()}\n{controlFileContents}\n{Guid.NewGuid()}";

            var fileSystem = new MockFileSystem(new ConcurrentDictionary<string, MockFileData>
            {
                ["job_orchestration.ctl"] = new MockFileData(fileContents)
            });

            var controlFileParserResult = SUT(fileSystem)
                .Parse("job_orchestration.ctl");

            return controlFileParserResult;
        }

        private ControlFileParser SUT(IFileSystem fileSystem)
        {
            var controlFileParser = new ControlFileParser(fileSystem);
            controlFileParser.SetLogger(Substitute.For<IPerBatchLogger>());
            return controlFileParser;
        }
    }
}