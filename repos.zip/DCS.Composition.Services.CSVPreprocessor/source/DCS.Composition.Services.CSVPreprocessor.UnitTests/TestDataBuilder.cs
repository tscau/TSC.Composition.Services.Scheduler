﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;

namespace DCS.Composition.Services.CSVPreprocessor.UnitTests
{
    public abstract class TestDataBuilder<TObject>
    {
        private readonly IDictionary<string, object> _properties = new Dictionary<string, object>();

        public void Set<TValue>(Expression<Func<TObject, TValue>> property, TValue value)
        {
            _properties[GetPropertyName(property)] = value;
        }

        public TValue Get<TValue>(Expression<Func<TObject, TValue>> property)
        {
            var propertyName = GetPropertyName(property);

            if (!_properties.TryGetValue(propertyName, out var value))
                throw new InvalidOperationException($"Property {propertyName} was not set.");

            return (TValue) value;
        }

        public abstract TObject Build();

        private static string GetPropertyName<TValue>(Expression<Func<TObject, TValue>> property)
        {
            var type = typeof(TObject);

            if (!(property.Body is MemberExpression member))
                throw new ArgumentException($"Expression '{property}' refers to a method, not a property.");

            var propInfo = member.Member as PropertyInfo;
            if (propInfo == null)
                throw new ArgumentException($"Expression '{property}' refers to a field, not a property.");

            if (type != propInfo.ReflectedType && !type.IsSubclassOf(propInfo.ReflectedType))
                throw new ArgumentException(
                    string.Format($"Expression '{property}' refers to a property that is not from type {type}."));

            return propInfo.Name;
        }
    }
}