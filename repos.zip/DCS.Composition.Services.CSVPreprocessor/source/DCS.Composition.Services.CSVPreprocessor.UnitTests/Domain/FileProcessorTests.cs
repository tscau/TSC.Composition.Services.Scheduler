﻿using System.IO;
using System.IO.Abstractions;
using System.IO.Abstractions.TestingHelpers;
using DCS.Composition.Services.CSVPreprocessor.Common;
using DCS.Composition.Services.CSVPreprocessor.Domain;
using DCS.Composition.Services.CSVPreprocessor.Domain.Generators;
using DCS.Composition.Services.CSVPreprocessor.UnitTests.Builders;
using DCS.Composition.Services.CSVPreprocessor.UnitTests.Stubs;
using DCS.Logging.Shared.Infrastructure;
using FluentAssertions;
using NSubstitute;
using Serilog;
using Xunit;

namespace DCS.Composition.Services.CSVPreprocessor.UnitTests.Domain
{
    public class FileProcessorTests
    {
        [Fact]
        public void Can_generate_bets_into_existing_column()
        {
            var csv = @"
HEADER_1,HEADER_2,BET
AAAAAAAA,AAAAAAAA,
BBBBBBBB,BBBBBBBB,
    ".Trim();

            var expectedDriver = @"
HEADER_1,HEADER_2,BET
AAAAAAAA,AAAAAAAA,12345
BBBBBBBB,BBBBBBBB,12345
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(3)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithInsertBetInColumnNo(2)
                .Build();

            var stubBetGenerator = new StubBETGenerator(Result.Ok(12345L));

            SUT(fileSystem, stubBetGenerator).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, expectedDriver);
        }

        [Fact]
        public void Can_generate_bets_into_new_column()
        {
            var csv = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA
BBBBBBBB,BBBBBBBB
    ".Trim();

            var expectedDriver = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA,12345
BBBBBBBB,BBBBBBBB,12345
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(2)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithInsertBetInColumnNo(2)
                .Build();

            var stubBetGenerator = new StubBETGenerator(Result.Ok(12345L));

            SUT(fileSystem, stubBetGenerator).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, expectedDriver);
        }


        [Fact]
        public void Can_generate_dpids_into_existing_column_using_nat_cd()
        {
            var csv = @"
HEADER_1,HEADER_2,BET,DPID
AAAAAAAA,AAAAAAAA,,
CCCCCCCC,CCCCCCCC,,
    ".Trim();

            var expectedDriver = @"
HEADER_1,HEADER_2,BET,DPID
AAAAAAAA,AAAAAAAA,12345,NATCD_12345
CCCCCCCC,CCCCCCCC,12345,NATCD_12345
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(4)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithInsertBetInColumnNo(2)
                .WithNatCd("NATCD")
                .WithInsertDPID(3)
                .Build();

            var stubBetGenerator = new StubBETGenerator(Result.Ok(12345L));
            var stubDpidGenerator = new StubDPIDGenerator((natcd, bet) => Result.Ok($"{natcd}_{bet}"));

            SUT(fileSystem, stubBetGenerator, stubDpidGenerator).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, expectedDriver);
        }

        [Fact]
        public void Can_generate_dpids_into_existing_column_using_nat_cd_column()
        {
            var csv = @"
HEADER_1,HEADER_2,NATCD,BET,DPID
AAAAAAAA,AAAAAAAA,NATCDA,,
BBBBBBBB,BBBBBBBB,NATCDB,,
    ".Trim();

            var expectedDriver = @"
HEADER_1,HEADER_2,NATCD,BET,DPID
AAAAAAAA,AAAAAAAA,NATCDA,12345,NATCDA_12345
BBBBBBBB,BBBBBBBB,NATCDB,12345,NATCDB_12345
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(5)
                .WithCompulsoryColumns(new[] { 0, 1, 2 })
                .WithInsertBetInColumnNo(3)
                .WithInsertDPID(4)
                .WithNatCdColumn(2)
                .Build();

            var stubBetGenerator = new StubBETGenerator(Result.Ok(12345L));
            var stubDpidGenerator = new StubDPIDGenerator((natcd, bet) => Result.Ok($"{natcd}_{bet}"));

            SUT(fileSystem, stubBetGenerator, stubDpidGenerator).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, expectedDriver);
        }

        [Fact]
        public void Can_generate_dpids_into_new_column_using_nat_cd()
        {
            var csv = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA
BBBBBBBB,BBBBBBBB
    ".Trim();

            var expectedDriver = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA,12345,NATCD_12345
BBBBBBBB,BBBBBBBB,12345,NATCD_12345
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(2)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithInsertBetInColumnNo(2)
                .WithNatCd("NATCD")
                .WithInsertDPID(3)
                .Build();

            var stubBetGenerator = new StubBETGenerator(Result.Ok(12345L));
            var stubDpidGenerator = new StubDPIDGenerator((natcd, bet) => Result.Ok($"{natcd}_{bet}"));

            SUT(fileSystem, stubBetGenerator, stubDpidGenerator).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, expectedDriver);
        }

        [Fact]
        public void Can_generate_dpids_into_new_column_using_nat_cd_column()
        {
            var csv = @"
HEADER_1,HEADER_2,NATCD
AAAAAAAA,AAAAAAAA,NATCDA
BBBBBBBB,BBBBBBBB,NATCDB
    ".Trim();

            var expectedDriver = @"
HEADER_1,HEADER_2,NATCD
AAAAAAAA,AAAAAAAA,NATCDA,12345,NATCDA_12345
BBBBBBBB,BBBBBBBB,NATCDB,12345,NATCDB_12345
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(3)
                .WithCompulsoryColumns(new[] { 0, 1, 2 })
                .WithInsertBetInColumnNo(3)
                .WithInsertDPID(4)
                .WithNatCdColumn(2)
                .Build();

            var stubBetGenerator = new StubBETGenerator(Result.Ok(12345L));
            var stubDpidGenerator = new StubDPIDGenerator((natcd, bet) => Result.Ok($"{natcd}_{bet}"));

            SUT(fileSystem, stubBetGenerator, stubDpidGenerator).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, expectedDriver);
        }

        [Fact]
        public void Creates_error_record_for_invalid_nat_cd_column()
        {
            var csv = @"
AAAAAAAA,AAAAAAAA,AAAAAAAA
    ".Trim();

            var expectedError = @"
AAAAAAAA,AAAAAAAA,AAAAAAAA,Error parsing line 1: Expected NatCd at column 999.
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(false)
                .WithReqColumnCount(3)
                .WithCompulsoryColumns(new[] { 0, 1, 2 })
                .WithInsertBetInColumnNo(3)
                .WithInsertDPID(4)
                .WithNatCdColumn(999)
                .Build();

            SUT(fileSystem).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, errorContents: expectedError);
        }

        [Fact]
        public void Creates_error_record_for_missing_columns()
        {
            var csv = @"
HEADER_1,HEADER_2,HEADER_3
AAAAAAAA,AAAAAAAA,AAAAAAAA
BBBBBBBB,BBBBBBBB
CCCCCCCC,CCCCCCCC,CCCCCCCC
    ".Trim();

            var expectedDriver = @"
HEADER_1,HEADER_2,HEADER_3
AAAAAAAA,AAAAAAAA,AAAAAAAA
CCCCCCCC,CCCCCCCC,CCCCCCCC
    ".Trim();

            var expectedError = @"
BBBBBBBB,BBBBBBBB,Error parsing line 3: Expecting 3 columns but 2 found. 
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(3)
                .Build();

            SUT(fileSystem).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, expectedDriver, expectedError);
        }

        [Fact]
        public void Creates_error_record_for_missing_compulsory_columns()
        {
            var csv = @"
HEADER_1,HEADER_2,HEADER_3
AAAAAAAA,AAAAAAAA,AAAAAAAA
BBBBBBBB,        ,BBBBBBBB
CCCCCCCC,CCCCCCCC,CCCCCCCC
    ".Trim();

            var expectedDriver = @"
HEADER_1,HEADER_2,HEADER_3
AAAAAAAA,AAAAAAAA,AAAAAAAA
CCCCCCCC,CCCCCCCC,CCCCCCCC
    ".Trim();

            var expectedError = @"
BBBBBBBB,,BBBBBBBB,Error parsing line 3: Compulsory field(s) 1 are missing.
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(3)
                .WithCompulsoryColumns(new[] { 1, 2 })
                .Build();

            SUT(fileSystem).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, expectedDriver, expectedError);
        }

        [Fact]
        public void Creates_error_record_when_BET_generation_fails()
        {
            var csv = @"
HEADER_1,HEADER_2,BET
AAAAAAAA,AAAAAAAA,
    ".Trim();

            var expectedError = @"
AAAAAAAA,AAAAAAAA,,Error parsing line 2: Error generating BET - BET generation failed.
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(3)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithInsertBetInColumnNo(2)
                .Build();

            var stubBetGenerator = new StubBETGenerator(
                Result.Fail<long>("BET generation failed"));

            SUT(fileSystem, stubBetGenerator).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, errorContents: expectedError);
        }

        [Fact]
        public void Creates_error_record_when_DPID_generation_fails()
        {
            var csv = @"
HEADER_1,HEADER_2,BET,DPID
AAAAAAAA,AAAAAAAA,,
    ".Trim();

            var expectedError = @"
AAAAAAAA,AAAAAAAA,,,Error parsing line 2: Error generating DPID - DPID generation failed.
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(4)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithInsertBetInColumnNo(2)
                .WithNatCd("NATCD")
                .WithInsertDPID(3)
                .Build();

            var stubBetGenerator = new StubBETGenerator(Result.Ok(12345L));
            var stubDpidGenerator = new StubDPIDGenerator((natcd, bet) =>
                Result.Fail<string>("DPID generation failed"));

            SUT(fileSystem, stubBetGenerator, stubDpidGenerator).Process(csvPreprocessorMsg);

            AssertContents(csvPreprocessorMsg, fileSystem, errorContents: expectedError);
        }

        [Fact]
        public void Fails_when_strict_validation_false_and_all_records_error_when_theres_a_header()
        {
            var csv = @"
HEADER_1,HEADER_2
AAAAAAAA,
BBBBBBBB,
CCCCCCCC,
    ".Trim();

            var expectedError = @"
AAAAAAAA,,Error parsing line 2: Compulsory field(s) 1 are missing.
BBBBBBBB,,Error parsing line 3: Compulsory field(s) 1 are missing.
CCCCCCCC,,Error parsing line 4: Compulsory field(s) 1 are missing.
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(2)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithStrictValidation(false)
                .Build();

            var result = SUT(fileSystem).Process(csvPreprocessorMsg);

            result.Failure.Should().BeTrue();
            result.Error.Should().Be(@"All 3 records failed to process.");

            AssertContents(csvPreprocessorMsg, fileSystem, errorContents: expectedError);
        }


        [Fact]
        public void Fails_when_strict_validation_false_and_all_records_error_when_theres_no_header()
        {
            var csv = @"
AAAAAAAA,
BBBBBBBB,
CCCCCCCC,
    ".Trim();

            var expectedError = @"
AAAAAAAA,,Error parsing line 1: Compulsory field(s) 1 are missing.
BBBBBBBB,,Error parsing line 2: Compulsory field(s) 1 are missing.
CCCCCCCC,,Error parsing line 3: Compulsory field(s) 1 are missing.
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(false)
                .WithReqColumnCount(2)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithStrictValidation(false)
                .Build();

            var result = SUT(fileSystem).Process(csvPreprocessorMsg);

            result.Failure.Should().BeTrue();
            result.Error.Should().Be(@"All 3 records failed to process.");

            AssertContents(csvPreprocessorMsg, fileSystem, errorContents: expectedError);
        }

        [Fact]
        public void Fails_when_strict_validation_true_and_some_records_error()
        {
            var csv = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA
BBBBBBBB,
CCCCCCCC,CCCCCCCC
    ".Trim();

            var expectedError = @"
BBBBBBBB,,Error parsing line 3: Compulsory field(s) 1 are missing.
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(2)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithStrictValidation(true)
                .Build();


            var result = SUT(fileSystem).Process(csvPreprocessorMsg);

            result.Failure.Should().BeTrue();
            result.Error.Should().Be(@"Strict validation was set and 1 out of 3 records failed to process.");

            AssertContents(csvPreprocessorMsg, fileSystem, errorContents: expectedError);
        }

        [Fact]
        public void Succeeds_when_no_records_error()
        {
            var csv = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA
BBBBBBBB,BBBBBBBB
    ".Trim();

            var expectedDriver = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA
BBBBBBBB,BBBBBBBB
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(2)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .Build();

            var result = SUT(fileSystem).Process(csvPreprocessorMsg);

            result.Success.Should().BeTrue();

            AssertContents(csvPreprocessorMsg, fileSystem, expectedDriver);
        }

        [Fact]
        public void Succeeds_when_strict_validation_false_and_some_records_error()
        {
            var csv = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA
BBBBBBBB,
CCCCCCCC,CCCCCCCC
    ".Trim();

            var expectedDriver = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA
CCCCCCCC,CCCCCCCC
    ".Trim();

            var expectedError = @"
BBBBBBBB,,Error parsing line 3: Compulsory field(s) 1 are missing.
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(2)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithStrictValidation(false)
                .Build();

            var result = SUT(fileSystem).Process(csvPreprocessorMsg);

            result.Success.Should().BeTrue();

            AssertContents(csvPreprocessorMsg, fileSystem, expectedDriver, expectedError);
        }

        [Fact]
        public void On_success_returns_correct_record_counts()
        {
            var csv = @"
HEADER_1,HEADER_2,BET
AAAAAAAA,AAAAAAAA,
BBBBBBBB,,
CCCCCCCC,CCCCCCCC,
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(3)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithInsertBetInColumnNo(2)
                .WithStrictValidation(false) // strict validation false, we allow some errors
                .Build();

            var stubBetGenerator = new StubBETGenerator(Result.Ok(12345L));

            var results = SUT(fileSystem, stubBetGenerator).Process(csvPreprocessorMsg);

            var expected = FileProcessorResult.Ok(
                3, 
                1, 
                @"c:\batch_folder\Driver.csv",
                @"c:\batch_folder\Preprocessor_Error.csv");

            results.Should().BeEquivalentTo(expected);
        }

        [Fact]
        public void On_failure_returns_correct_record_counts_and_error_message()
        {
            var csv = @"
HEADER_1,HEADER_2,BET
AAAAAAAA,AAAAAAAA,
BBBBBBBB,,
CCCCCCCC,CCCCCCCC,
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(3)
                .WithCompulsoryColumns(new[] { 0, 1 })
                .WithInsertBetInColumnNo(2)
                .WithStrictValidation(true) // strict validation true, any errors will cause failure
                .Build();

            var stubBetGenerator = new StubBETGenerator(Result.Ok(12345L));

            var results = SUT(fileSystem, stubBetGenerator).Process(csvPreprocessorMsg);

            var expected = FileProcessorResult.Fail(
                "Strict validation was set and 1 out of 3 records failed to process.",
                3,
                1,
                @"c:\batch_folder\Preprocessor_Error.csv");

            results.Should().BeEquivalentTo(expected);
        }


        [Fact]
        public void On_failure_archives_original_file()
        {
            var csv = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(3)
                .Build();

            var results = SUT(fileSystem).Process(csvPreprocessorMsg);

            results.Failure.Should().BeTrue();
            fileSystem.File.Exists(@"c:\input.csv").Should().BeFalse();
            fileSystem.File.Exists(@"c:\Archived\input.csv").Should().BeTrue();
        }

        [Fact]
        public void On_success_archives_original_file()
        {
            var csv = @"
HEADER_1,HEADER_2
AAAAAAAA,AAAAAAAA
    ".Trim();

            var fileSystem = new MockFileSystem();
            fileSystem.AddFile(@"c:\input.csv", new MockFileData(csv));
            fileSystem.AddDirectory(@"c:\batch_folder");

            var csvPreprocessorMsg = new CSVPreprocessorParametersBuilder()
                .WithInputFile(@"c:\input.csv")
                .WithBatchFolder(@"c:\batch_folder")
                .WithHeaders(true)
                .WithReqColumnCount(2)
                .Build();

            var results = SUT(fileSystem).Process(csvPreprocessorMsg);

            results.Success.Should().BeTrue();
            fileSystem.File.Exists(@"c:\input.csv").Should().BeFalse();
            fileSystem.File.Exists(@"c:\Archived\input.csv").Should().BeTrue();
        }

        private FileProcessor SUT(
            IFileSystem fileSystem = null,
            IBETGenerator betGenerator = null,
            IDPIDGenerator dpidGenerator = null)
        {
            fileSystem ??= CreateFileSystemThatMatchesDefaultcsvPreprocessorMsgetup();
            betGenerator ??= new StubBETGenerator(Result.Ok<long>(99999));
            dpidGenerator ??= new StubDPIDGenerator(Result.Ok("SOME_DPID"));

            var fileProcessor = new FileProcessor(
                fileSystem,
                betGenerator,
                dpidGenerator);

            fileProcessor.SetLogger(Substitute.For<IPerBatchLogger>());

            return fileProcessor;
        }

        private IFileSystem CreateFileSystemThatMatchesDefaultcsvPreprocessorMsgetup()
        {
            var validFileSystem = new MockFileSystem();

            validFileSystem.AddFile(@"c:\input.csv", new MockFileData(""));
            validFileSystem.AddDirectory(@"c:\batch_folder");

            return validFileSystem;
        }

        private void AssertContents(CSVPreprocessorParameters parameters, MockFileSystem fileSystem, string driverContents = null, string errorContents = null)
        {
            var errorFile = Path.Combine(parameters.BatchFolder, "Preprocessor_Error.csv");
            var driverFile = Path.Combine(parameters.BatchFolder, "Driver.csv");

            if (errorContents == null)
            {
                var errorFileExists = fileSystem.File.Exists(errorFile);
                var contents = errorFileExists ? fileSystem.File.ReadAllText(errorFile) : null;
                errorFileExists.Should().BeFalse($"Expected error file to not exist. Contents are:\n{contents}");
            }
            else
            {
                fileSystem.File.ReadAllText(errorFile).Trim().Should().Be(errorContents);
            }

            if (driverContents == null)
            {
                var driverFileExists = fileSystem.File.Exists(driverFile);
                var contents = driverFileExists ? fileSystem.File.ReadAllText(driverFile) : null;
                driverFileExists.Should().BeFalse($"Expected driver file to not exist. Contents are:\n{contents}");
            }
            else
            {
                fileSystem.File.ReadAllText(driverFile).Trim().Should().Be(driverContents);
            }
        }
    }
}