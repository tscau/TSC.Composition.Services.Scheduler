﻿using System;
using System.IO.Abstractions.TestingHelpers;
using DCS.Composition.Services.CSVPreprocessor.UnitTests.Builders;
using DCS.Composition.Services.Shared.Contracts;
using FluentAssertions;
using Xunit;

namespace DCS.Composition.Services.CSVPreprocessor.UnitTests.Domain
{
    public class CSVProcessorTests
    {
        [Theory]
        [InlineData(null)]
        [InlineData(" ")]
        public void Throws_when_job_path_is_null_or_empty(string jobPath)
        {
            var invalidMessage = new CompositionMsg { JobPath = jobPath };

            Action executingWithInvalidMessage = () =>
                CSVPreprocessor.Domain.CSVPreprocessor.ValidateMessage(invalidMessage, new MockFileSystem());

            executingWithInvalidMessage
                .Should()
                .Throw<ArgumentException>()
                .WithMessage("Input parameter JobPath missing");
        }

        [Fact]
        public void Throws_when_csv_message_is_null()
        {
            var invalidMessage = new CompositionMsg
            {
                JobPath = "valid_path", 
                CSVPreprocessorMsg = null
            };

            Action executingWithInvalidMessage = () =>
                CSVPreprocessor.Domain.CSVPreprocessor.ValidateMessage(invalidMessage, new MockFileSystem());

            executingWithInvalidMessage
                .Should()
                .Throw<ArgumentException>()
                .WithMessage("Input parameter CSVPreprocessorMsg missing");
        }

        [Theory]
        [InlineData(null)]
        [InlineData(" ")]
        public void Throws_when_input_file_is_null_or_empty(string inputFile)
        {
            var invalidMessage = new CompositionMsg()
            {
                JobPath = "valid_path",
                CSVPreprocessorMsg = new CSVPreprocessorMsg
                {
                    NatCd = "valid_nat_Cd",
                    InputFile = inputFile
                }
            };

            Action executingWithInvalidMessage = () =>
                CSVPreprocessor.Domain.CSVPreprocessor.ValidateMessage(invalidMessage, new MockFileSystem());

            executingWithInvalidMessage
                .Should()
                .Throw<ArgumentException>()
                .WithMessage("Input parameter InputFile missing");
        }

        [Theory]
        [InlineData(null)]
        [InlineData(" ")]
        public void Throws_when_nat_cd_is_null_or_empty(string natCd)
        {
            var invalidMessage = new CompositionMsg()
            {
                JobPath = "valid_path",
                CSVPreprocessorMsg = new CSVPreprocessorMsg
                {
                    NatCd = natCd
                }
            };

            Action executingWithInvalidMessage = () =>
                CSVPreprocessor.Domain.CSVPreprocessor.ValidateMessage(invalidMessage, new MockFileSystem());

            executingWithInvalidMessage
                .Should()
                .Throw<ArgumentException>()
                .WithMessage("Input parameter NatCd missing");
        }

        [Fact]
        public void Throws_when_input_file_does_not_exist()
        {
            var invalidMessage = new CompositionMsg()
            {
                JobPath = "valid_path",
                CSVPreprocessorMsg = new CSVPreprocessorMsg
                {
                    NatCd = "valid_nat_Cd",
                    InputFile = "file_that_doesnt_exist"
                }
            };

            Action executingWithInvalidMessage = () =>
                CSVPreprocessor.Domain.CSVPreprocessor.ValidateMessage(invalidMessage, new MockFileSystem());

            executingWithInvalidMessage
                .Should()
                .Throw<ArgumentException>()
                .WithMessage("Input file was not found: file_that_doesnt_exist");
        }

        [Theory]
        [InlineData(null)]
        [InlineData(new int[0])]
        public void Throws_when_compulsory_column_is_null_or_empty(int[] compulsoryColumns)
        {
            var invalidParameters = new CSVPreprocessorParametersBuilder()
                .WithCompulsoryColumns(compulsoryColumns)
                .Build();

            Action executingWithInvalidParameters = () => 
                CSVPreprocessor.Domain.CSVPreprocessor.ValidateParameters(invalidParameters);

            executingWithInvalidParameters
                .Should()
                .Throw<ArgumentException>()
                .WithMessage("Input parameter CompulsoryColumns missing");
        }

        [Theory]
        [InlineData(0)]
        [InlineData(-1)]
        public void Throws_when_required_column_count_is_less_than_1(int requiredColumnCount)
        {
            var invalidParameters = new CSVPreprocessorParametersBuilder()
                .WithReqColumnCount(requiredColumnCount)
                .Build();

            Action executingWithInvalidParameters = () =>
                CSVPreprocessor.Domain.CSVPreprocessor.ValidateParameters(invalidParameters);

            executingWithInvalidParameters
                .Should()
                .Throw<ArgumentException>()
                .WithMessage("Input parameter ReqColumnCount missing");
        }

        [Theory]
        [InlineData(null)]
        [InlineData(" ")]
        public void Throws_when_nat_cd_required_but_missing(string natCd)
        {
            var invalidParameters = new CSVPreprocessorParametersBuilder()
                .WithNatCd(natCd)
                .WithNatCdColumn(null)
                .WithInsertBetInColumnNo(0)
                .WithInsertDPID(1)
                .Build();

            Action executingWithInvalidParameters = () =>
                CSVPreprocessor.Domain.CSVPreprocessor.ValidateParameters(invalidParameters);

            executingWithInvalidParameters
                .Should()
                .Throw<ArgumentException>()
                .WithMessage(@"Both NatCdColumn and NatCd are missing");
        }

        [Fact]
        public void Throws_when_dpid_required_but_bet_id_column_not_set()
        {
            var invalidParameters = new CSVPreprocessorParametersBuilder()
                .WithInsertDPID(1)
                .WithInsertBetInColumnNo(null)
                .Build();

            Action executingWithInvalidParameters = () =>
                CSVPreprocessor.Domain.CSVPreprocessor.ValidateParameters(invalidParameters);

            executingWithInvalidParameters
                .Should()
                .Throw<ArgumentException>()
                .WithMessage(@"InsertDPID was set but InsertBetInColumnNo was missing");
        }
    }
}