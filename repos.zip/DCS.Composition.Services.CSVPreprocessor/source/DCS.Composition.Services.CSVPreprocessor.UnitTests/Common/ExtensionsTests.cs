﻿using DCS.Composition.Services.CSVPreprocessor.Common;
using FluentAssertions;
using Xunit;

namespace DCS.Composition.Services.CSVPreprocessor.UnitTests.Common
{
    public class ExtensionsTests
    {
        [Theory]
        [InlineData(new string[] { }, 0, "", new string[] { })]
        [InlineData(new string[] { }, 1, "", new[] { "" })]
        [InlineData(new[] { "a" }, 1, "", new[] { "a" })]
        [InlineData(new[] { "a" }, 2, "", new[] { "a", "" })]
        [InlineData(new[] { "a" }, 3, "", new[] { "a", "", "" })]
        [InlineData(new[] { "a", "b" }, 3, "", new[] { "a", "b", "" })]
        [InlineData(new[] { "a", "b", "c" }, 2, "", new[] { "a", "b", "c" })]
        public void EnsureLengthAtLeast_pads_array_to_the_specified_size_if_smaller(string[] original, int length, string padWith, string[] expected)
        {
            original.EnsureLengthAtLeast(length, padWith).Should().BeEquivalentTo(expected);
        }

        [Fact]
        public void EmptyIfNull_returns_an_empty_array_if_null()
        {
            string[] nullArray = null;

            nullArray.EmptyIfNull().Should().BeEmpty();
        }

        [Theory]
        [InlineData(null, true)]
        [InlineData(new string[] { }, true)]
        [InlineData(new[] { "a" }, false)]
        public void None_returns_true_when_array_is_null_or_empty(string[] original, bool expected)
        {
            original.None().Equals(expected);
        }
    }
}