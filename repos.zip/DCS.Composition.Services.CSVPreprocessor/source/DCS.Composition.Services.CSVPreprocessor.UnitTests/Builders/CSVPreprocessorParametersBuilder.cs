﻿using DCS.Composition.Services.CSVPreprocessor.Domain;

namespace DCS.Composition.Services.CSVPreprocessor.UnitTests.Builders
{
    public class CSVPreprocessorParametersBuilder : TestDataBuilder<CSVPreprocessorParameters>
    {
        public CSVPreprocessorParametersBuilder()
        {
            WithInputFile(@"c:\input.csv");
            WithBatchFolder(@"c:\batch_folder");
            WithBAUContacts(new[] {"contact@ato.gov.au"});
            WithCompulsoryColumns(new[] {0, 1});
            WithReqColumnCount(2);
            WithInsertBetInColumnNo(null);
            WithHeaders(true);
            WithInsertDPID(null);
            WithNatCd("NAT_CD");
            WithNatCdColumn(null);
            WithStrictValidation(false);
            WithDelimiter("");
        }

        public CSVPreprocessorParametersBuilder WithInputFile(string value)
        {
            Set(x => x.InputFile, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithBatchFolder(string value)
        {
            Set(x => x.BatchFolder, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithBAUContacts(string[] value)
        {
            Set(x => x.BAUContacts, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithCompulsoryColumns(int[] value)
        {
            Set(x => x.CompulsoryColumns, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithReqColumnCount(int? value)
        {
            Set(x => x.ReqColumnCount, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithInsertBetInColumnNo(int? value)
        {
            Set(x => x.InsertBetInColumnNo, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithHeaders(bool value)
        {
            Set(x => x.Headers, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithInsertDPID(int? value)
        {
            Set(x => x.InsertDPID, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithNatCd(string value)
        {
            Set(x => x.NatCd, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithNatCdColumn(int? value)
        {
            Set(x => x.NatCdColumn, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithStrictValidation(bool value)
        {
            Set(x => x.StrictValidation, value);
            return this;
        }

        public CSVPreprocessorParametersBuilder WithDelimiter(string value)
        {
            Set(x => x.Delimiter, value);
            return this;
        }

        public override CSVPreprocessorParameters Build()
        {
            return new CSVPreprocessorParameters
            {
                InputFile = Get(x => x.InputFile),
                BatchFolder = Get(x => x.BatchFolder),
                BAUContacts = Get(x => x.BAUContacts),
                CompulsoryColumns = Get(x => x.CompulsoryColumns),
                ReqColumnCount = Get(x => x.ReqColumnCount),
                InsertBetInColumnNo = Get(x => x.InsertBetInColumnNo),
                Headers = Get(x => x.Headers),
                InsertDPID = Get(x => x.InsertDPID),
                NatCd = Get(x => x.NatCd),
                NatCdColumn = Get(x => x.NatCdColumn),
                StrictValidation = Get(x => x.StrictValidation),
                Delimiter = Get(x => x.Delimiter)
            };
        }
    }
}