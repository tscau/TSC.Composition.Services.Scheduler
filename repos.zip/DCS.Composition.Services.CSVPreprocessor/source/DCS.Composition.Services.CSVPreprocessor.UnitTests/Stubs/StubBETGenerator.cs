﻿using DCS.Composition.Services.CSVPreprocessor.Common;
using DCS.Composition.Services.CSVPreprocessor.Domain.Generators;
using DCS.Logging.Shared.Infrastructure;
using Serilog.Core;

namespace DCS.Composition.Services.CSVPreprocessor.UnitTests.Stubs
{
    public class StubBETGenerator : IBETGenerator
    {
        private readonly Result<long> _generatedBET;

        public StubBETGenerator(Result<long> generatedBet)
        {
            _generatedBET = generatedBet;
        }

        public Result<long> GenerateBET()
        {
            return _generatedBET;
        }

        public void SetLogger(IPerBatchLogger logger)
        {
        }
    }
}