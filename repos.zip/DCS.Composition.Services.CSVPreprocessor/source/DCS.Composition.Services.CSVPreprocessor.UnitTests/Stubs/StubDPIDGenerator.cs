﻿using System;
using DCS.Composition.Services.CSVPreprocessor.Common;
using DCS.Composition.Services.CSVPreprocessor.Domain.Generators;
using DCS.Logging.Shared.Infrastructure;
using Serilog.Core;

namespace DCS.Composition.Services.CSVPreprocessor.UnitTests.Stubs
{
    public class StubDPIDGenerator : IDPIDGenerator
    {
        private readonly Func<string, long, Result<string>> _dpidGenerator;

        public StubDPIDGenerator(Func<string, long, Result<string>> dpidGenerator)
        {
            _dpidGenerator = dpidGenerator;
        }

        public StubDPIDGenerator(Result<string> dpid)
        {
            _dpidGenerator = (natCd, bet) => dpid;
        }

        public Result<string> GenerateDPID(string natCd, long bet)
        {
            return _dpidGenerator(natCd, bet);
        }

        public void SetLogger(IPerBatchLogger logger)
        {
        }
    }
}