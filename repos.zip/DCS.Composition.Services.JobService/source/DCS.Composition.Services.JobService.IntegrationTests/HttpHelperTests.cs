﻿using DCS.Composition.Services.JobService.Common;
using DCS.Composition.Services.JobService.Config;
using DCS.Composition.Services.JobService.Contracts;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using Xunit;

namespace DCS.Composition.Services.JobService.IntegrationTests
{
    public class HttpHelperTests
    {
        IAppConfig cfg = new AppConfig();
        [Fact]
        public void BasicIntegrationTest()
        {
            var logMoq = new Mock<ILogger<HttpHelper>>();

            var appConfigMock = Utilities.SetupAppConfig();

            var httpHelper = new HttpHelper(logMoq.Object, appConfigMock.Object);
            var request = new CCRequest
            {
                BatchFolder = @"\\DCSXFLS00009DE.devtest.atohdtnet.gov.au\DCSCORRES_DE\DEM\Jobs\Batch\1241",
                JobId = Guid.NewGuid(),
                NatCd = "12345",
                ServiceName = ""
            };

            var ticket = httpHelper.Authenticate(appConfigMock.Object.AppSettings.CCSUserName, appConfigMock.Object.AppSettings.CCSPassword).Result;

            var serviceResponse = httpHelper.SendRequestToCc(request, ticket).Result;

            Assert.NotNull(serviceResponse);
        }
    }
}
