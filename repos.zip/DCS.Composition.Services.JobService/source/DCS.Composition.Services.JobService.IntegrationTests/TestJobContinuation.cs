﻿using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.JobService;
using Hangfire;
using Hangfire.Logging;
using Hangfire.Logging.LogProviders;
using Xunit;

namespace DCS.Composition.Services.JobService.IntegrationTests
{
    public class TestJobContinuation
    {
        [Fact]
        public void TestJobServiceTrigger()
        {
            LogProvider.SetCurrentLogProvider(new ColouredConsoleLogProvider());

            GlobalConfiguration.Configuration.UseSqlServerStorage(@"Server=.\MSSQL2016; Database=HangfireCompositionLOCAL; Integrated Security=SSPI;");

            BackgroundJob.Enqueue<IJobService>(x => x.Start(new CompositionMsg
            {
                BatchId = 123
            }, null));
        }
    }
}
