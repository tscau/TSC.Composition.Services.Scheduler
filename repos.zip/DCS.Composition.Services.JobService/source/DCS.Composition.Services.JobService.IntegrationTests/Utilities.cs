﻿using DCS.Composition.Services.JobService.Config;
using Moq;

namespace DCS.Composition.Services.JobService.IntegrationTests
{
    public static class Utilities
    {
        public static Mock<IAppConfig> SetupAppConfig()
        {
            var appConfig = new Mock<IAppConfig>();
            appConfig.Setup(x => x.AppSettings.CCSAsync).Returns("true");
            appConfig.Setup(x => x.AppSettings.CCSPassword).Returns("password");
            appConfig.Setup(x => x.AppSettings.CCSRestUrl).Returns("https://gatewayde.dcs.devtest.atohdtnet.gov.au:2719/v1/communications");
            appConfig.Setup(x => x.AppSettings.CCSServiceName).Returns("BatchPrimary");
            appConfig.Setup(x => x.AppSettings.CCSUserName).Returns("tenantadmin");
            appConfig.Setup(x => x.AppSettings.CCSPassword).Returns("password");
            appConfig.Setup(x => x.AppSettings.FolderRootPath).Returns(@"\\DCSXFLS00009DE.devtest.atohdtnet.gov.au\DCSCORRES_DE\DEM\Jobs\Batch\");
            appConfig.Setup(x => x.AppSettings.CCSVersion).Returns("1");
            appConfig.Setup(x => x.AppSettings.CtlControlFilesFolder).Returns("ControlFiles");
            appConfig.Setup(x => x.AppSettings.CtlJobOrchestrator).Returns("job_orchestration.ctl");
            appConfig.Setup(x => x.AppSettings.Environment).Returns("DEM");
            appConfig.Setup(x => x.AppSettings.HangfireWorkerCount_JobServiceQueue).Returns(25);
            appConfig.Setup(x => x.AppSettings.HangfireWorkerCount_CcsServiceQueue).Returns(50);
            appConfig.Setup(x => x.AppSettings.HangfireWorkerCount_JobServiceContinueQueue).Returns(25);
            appConfig.Setup(x => x.AppSettings.HangfireWorkerCount_JobServiceFinalizeQueue).Returns(25);
            appConfig.Setup(x => x.AppSettings.ODTSAuthUrl).Returns("https://authde.dcs.devtest.atohdtnet.gov.au:8443/otdsws/v1/authentication/credentials");
            appConfig.Setup(x => x.AppSettings.UserToRecordAgainst).Returns("POSTCOMPJOBSERVICE");

            appConfig.Setup(x => x.Logging.LogFileName).Returns("postcomposition.jobservice.log");
            appConfig.Setup(x => x.Logging.LogServiceUrl).Returns("http://localhost:19130/api/DCSLogger/LogMessage");
            appConfig.Setup(x => x.Logging.RelativeJobLogFileLocation).Returns("LOGS");
            appConfig.Setup(x => x.ConnectionStrings.OutboundCorroGen).Returns(@"Server=outboundDatabaseDE.dcs.devtest.atohdtnet.gov.au\SQL001; database=OutboundDEM;Integrated Security=true;");
            appConfig.Setup(x => x.ConnectionStrings.HangfireDb).Returns(@"Server=DCSXSQL00011DT.devtest.atohdtnet.gov.au\SQL001; Database=DCSCompositionHangFireDEM; Trusted_Connection=True; MultipleActiveResultSets=True;");

            return appConfig;
        }
    }
}
