﻿using System.Configuration;

namespace DCS.Composition.Services.JobService.Config
{
    public class ConnectionStrings : IConnectionStrings
    {

        /// <summary>
        /// The Connection SAtring for the Outbound database
        /// </summary>
        public string OutboundCorroGen { get { return ConfigurationManager.ConnectionStrings["OutboundCorroGen"].ConnectionString; } }

        /// <summary>
        /// The connections tring for the hangfire database
        /// </summary>
        public string HangfireDb { get { return ConfigurationManager.ConnectionStrings["Hangfire"].ConnectionString; } }
    }
}
