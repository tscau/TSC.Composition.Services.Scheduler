﻿namespace DCS.Composition.Services.JobService.Config
{
    public interface IConnectionStrings
    {
        public string OutboundCorroGen { get; }
        public string HangfireDb { get; }
    }
}
