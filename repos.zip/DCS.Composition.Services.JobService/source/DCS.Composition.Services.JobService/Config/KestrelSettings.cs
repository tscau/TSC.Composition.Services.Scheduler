﻿using System.Configuration;

namespace DCS.Composition.Services.JobService.Config
{
    public class KestrelSettings : IKestrelSettings
    {
        public int RESTAPIPort
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("RESTAPIPort"), out int port);
                return port;
            }
        }

        public bool UseCertificateForSSL
        {
            get
            {
                bool.TryParse(ConfigurationManager.AppSettings.Get("UseCertificateForSSL"), out bool useSSL);
                return useSSL;
            }
        }
        public string CertificateSubject
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CertificateSubject");
            }
        }
        public string CertificateStoreName
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CertificateStoreName");
            }
        }

        public string CertificateLocation
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CertificateLocation");
            }
        }
        public bool CertificateAllowInvalid
        {
            get
            {
                bool.TryParse(ConfigurationManager.AppSettings.Get("CertificateAllowInvalid"), out bool allowInvalid);
                return allowInvalid;
            }
        }
    }
}
