﻿namespace DCS.Composition.Services.JobService.Config
{
    public interface IKestrelSettings
    {
        public int RESTAPIPort { get; }
        public bool UseCertificateForSSL { get; }
        public string CertificateSubject { get; }
        public string CertificateStoreName { get; }
        public string CertificateLocation { get; }
        public bool CertificateAllowInvalid { get; }
    }
}
