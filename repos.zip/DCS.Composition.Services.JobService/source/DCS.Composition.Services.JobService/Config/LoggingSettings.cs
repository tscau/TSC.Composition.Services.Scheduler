﻿using System.Configuration;

namespace DCS.Composition.Services.JobService.Config
{
    public class LoggingSettings : ILoggingSettings
    {
        public string LogFileName
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("LogFileName");
            }
        }


        public string RelativeJobLogFileLocation
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("RelativeJobLogFileLocation");
            }
        }

        public string LogServiceUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("LogServiceUrl");
            }
        }
    }
}
