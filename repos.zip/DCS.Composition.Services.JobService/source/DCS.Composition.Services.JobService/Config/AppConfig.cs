﻿namespace DCS.Composition.Services.JobService.Config
{
    public class AppConfig : IAppConfig
    {

        public AppConfig()
        {
            AppSettings = new AppSettings();
            Logging = new LoggingSettings();
            Kestrel = new KestrelSettings();
            ConnectionStrings = new ConnectionStrings();
        }


        public IAppSettings AppSettings { get; set; }
        public ILoggingSettings Logging { get; set; }
        public IKestrelSettings Kestrel { get; set; }
        public IConnectionStrings ConnectionStrings { get; set; }
    }
}
