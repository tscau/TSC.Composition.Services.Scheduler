﻿using System;
using System.Configuration;
using System.Reflection;

namespace DCS.Composition.Services.JobService.Config
{
    public class AppSettings : IAppSettings
    {
        public string Environment
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("Env");
            }
        }

        public string FolderRootPath => ConfigurationManager.AppSettings.Get("FolderRootPath");

        public int HangfireWorkerCount_JobServiceQueue
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("HangfireWorkerCount_JobServiceQueue"), out int hangfireWorkerCount);
                if (hangfireWorkerCount == 0)
                {
                    hangfireWorkerCount = 25;
                }

                return hangfireWorkerCount;
            }
        }

        public int HangfireWorkerCount_JobServiceHandleResponse
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("HangfireWorkerCount_JobServiceHandleResponse"), out int hangfireWorkerCount);
                if (hangfireWorkerCount == 0)
                {
                    hangfireWorkerCount = 25;
                }
                return hangfireWorkerCount;
            }
        }

        public int HangfireWorkerCount_CcsServiceQueue
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("HangfireWorkerCount_CcsServiceQueue"), out int hangfireWorkerCount);
                if (hangfireWorkerCount == 0)
                {
                    hangfireWorkerCount = 50;
                }

                return hangfireWorkerCount;
            }
        }

        public int HangfireWorkerCount_JobServiceContinueQueue
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("HangfireWorkerCount_JobServiceContinueQueue"), out int hangfireWorkerCount);
                if (hangfireWorkerCount == 0)
                {
                    hangfireWorkerCount = 25;
                }

                return hangfireWorkerCount;
            }
        }

        public int HangfireWorkerCount_JobServiceFinalizeQueue
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("HangfireWorkerCount_JobServiceFinalizeQueue"), out int hangfireWorkerCount);
                if (hangfireWorkerCount == 0)
                {
                    hangfireWorkerCount = 25;
                }

                return hangfireWorkerCount;
            }
        }

        public string UserToRecordAgainst => ConfigurationManager.AppSettings.Get("UserToRecordAgainst");

        public string CtlJobOrchestrator
        {
            get
            {
                string temp = ConfigurationManager.AppSettings.Get("CtlJobOrchestrator");
                if (string.IsNullOrWhiteSpace(temp))
                {
                    temp = "job_orchestration.ctl";
                }

                return temp;
            }
        }

        public string CtlControlFilesFolder
        {
            get
            {
                string temp = ConfigurationManager.AppSettings.Get("CtlControlFilesFolder");
                if (string.IsNullOrWhiteSpace(temp))
                {
                    temp = "ControlFiles";
                }

                return temp;
            }
        }

        public int CtlAccessMaxRetries
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("CtlJobOrchestrator"), out int temp);
                if (temp == 0)
                {
                    temp = 3;
                }

                return temp;
            }
        }

        public int CtlRetryIntervalInSeconds
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("CtlRetryIntervalInSeconds"), out int temp);
                if (temp == 0)
                {
                    temp = 1;
                }

                return temp;
            }
        }

        /// <summary>
        /// Url to obtain ODTS ticket
        /// </summary>
        public string ODTSAuthUrl => ConfigurationManager.AppSettings.Get("ODTSAuthUrl");

        /// <summary>
        /// Url to request CCS service
        /// </summary>
        public string CCSRestUrl => ConfigurationManager.AppSettings.Get("CCSRestUrl");

        public string CCSServiceName => ConfigurationManager.AppSettings.Get("CCSServiceName");

        public string CCSAsync => ConfigurationManager.AppSettings.Get("CCSAsync");

        public string CCSVersion => ConfigurationManager.AppSettings.Get("CCSVersion");

        public string CCSUserName => ConfigurationManager.AppSettings.Get("CCSUserName");

        public string CCSPassword => ConfigurationManager.AppSettings.Get("CCSPassword");


        /// <summary>
        /// Returns the version of the application
        /// </summary>
        public Version Version => Assembly.GetExecutingAssembly().GetName().Version;

        /// <summary>
        /// Returns the name of the server that is currently executing the code
        /// </summary>
        public string Server => System.Environment.MachineName;

        public string FakeCCSCall => ConfigurationManager.AppSettings.Get("FakeCCSCall");

        public bool CCSOutputFile
        {
            get
            {
                bool parseResult = bool.TryParse(ConfigurationManager.AppSettings.Get("CCSOutputFile"), out bool _CCSOutputFile);
                if (!parseResult)
                {
                    _CCSOutputFile = false;
                }
                return _CCSOutputFile;
            }



        }
    }
}
