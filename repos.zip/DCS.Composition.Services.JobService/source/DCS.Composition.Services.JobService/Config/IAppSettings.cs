﻿using System;

namespace DCS.Composition.Services.JobService.Config
{
    public interface IAppSettings
    {
        public string Environment { get; }

        public int HangfireWorkerCount_JobServiceQueue { get; }

        public int HangfireWorkerCount_CcsServiceQueue { get; }

        public int HangfireWorkerCount_JobServiceContinueQueue { get; }

        public int HangfireWorkerCount_JobServiceFinalizeQueue { get; }

        public int HangfireWorkerCount_JobServiceHandleResponse { get; }

        public string UserToRecordAgainst { get; }

        public string FolderRootPath { get; }

        public string CtlJobOrchestrator { get; }

        public string CtlControlFilesFolder { get; }

        public int CtlAccessMaxRetries { get; }

        public int CtlRetryIntervalInSeconds { get; }

        public string ODTSAuthUrl { get; }

        public string CCSRestUrl { get; }

        public string CCSServiceName { get; }

        public string CCSAsync { get; }

        public string CCSVersion { get; }

        public string CCSUserName { get; }

        public string CCSPassword { get; }

        public Version Version { get; }

        public string Server { get; }

        public string FakeCCSCall { get; }
        bool CCSOutputFile { get;}
    }
}
