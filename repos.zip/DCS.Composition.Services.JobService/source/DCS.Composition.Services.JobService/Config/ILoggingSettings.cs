﻿namespace DCS.Composition.Services.JobService.Config
{
    public interface ILoggingSettings
    {
        public string LogFileName { get; }

        public string RelativeJobLogFileLocation { get; }

        public string LogServiceUrl { get; }
    }
}
