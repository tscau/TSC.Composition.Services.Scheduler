﻿namespace DCS.Composition.Services.JobService.Config
{
    public interface IAppConfig
    {
        public IAppSettings AppSettings { get; set; }
        public ILoggingSettings Logging { get; set; }
        public IKestrelSettings Kestrel { get; set; }
        public IConnectionStrings ConnectionStrings { get; set; }

    }
}
