﻿namespace DCS.Composition.Services.JobService.Contracts
{
    public struct StoredConfig
    {
        public string Id { get; set; }
        public string FolderPath { get; set; }
    }
}
