﻿using System;

namespace DCS.Composition.Services.JobService.Contracts
{
    public struct CCRequest
    {
        /// <summary>
        /// Batch folder path
        /// </summary>
        public string BatchFolder { get; set; }

        /// <summary>
        /// Job/parameter name required for CCS
        /// </summary>
        public string ServiceName { get; set; }

        public string NatCd { get; set; }

        public Guid JobId { get; set; }
    }
}
