﻿using DCS.Composition.Services.JobService.Common;
using DCS.Composition.Services.JobService.Config;
using DCS.Composition.Services.JobService.Hangfire;
using DCS.Composition.Services.Shared.JobService;
using DCS.Composition.Services.Shared.Queues;
using DCS.Logging.Shared.Infrastructure;
using Hangfire;
using Hangfire.JobsLogger;
using Hangfire.SqlServer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using System;

namespace DCS.Composition.Services.JobService
{
    public class Startup
    {
        readonly IAppConfig _appConfig;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="configuration"></param>
        public Startup()
        {
            _appConfig = new AppConfig();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="services"></param>
        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Composition JobService API",
                    Version = "v1",
                    Description = "The Composition Job Service API used to manage the Composition JobService via a REST endpoint"
                });
            });

            services.AddTransient<IJobService, JobServiceActions>();
            services.AddTransient<ICommService, CommServiceActions>();
            services.AddTransient<IHttpHelper, HttpHelper>();
            services.AddTransient<IFileSystemHelper, FileSystemHelper>();
            services.AddTransient<IFileSystemHelper, FileSystemHelper>();
            services.AddTransient<IPerBatchLogger, PerBatchLogger>();

            services.AddHangfire(configuration => configuration
            .SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
              .UseJobsLogger()
              .UseSimpleAssemblyNameTypeSerializer()
              .UseSqlServerStorage(_appConfig.ConnectionStrings.HangfireDb, new SqlServerStorageOptions
              {
                  CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
                  SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
                  QueuePollInterval = TimeSpan.Zero,
                  UseRecommendedIsolationLevel = true,
                  UsePageLocksOnDequeue = true,
                  DisableGlobalLocks = true,
                  PrepareSchemaIfNecessary = true
              }));

            services.AddHangfireServer(options =>
            {
                options.Queues = new string[] { JobServiceQueues.JobServiceQueue };
                options.WorkerCount = _appConfig.AppSettings.HangfireWorkerCount_JobServiceQueue;
                options.ServerName = string.Format("{0}.{1}", Environment.MachineName, Guid.NewGuid().ToString());
            });

            services.AddHangfireServer(options =>
            {
                options.Queues = new string[] { JobServiceQueues.CcsServiceQueue };
                options.WorkerCount = _appConfig.AppSettings.HangfireWorkerCount_CcsServiceQueue;
                options.ServerName = string.Format("{0}.{1}", Environment.MachineName, Guid.NewGuid().ToString());
            });

            services.AddHangfireServer(options =>
            {
                options.Queues = new string[] { JobServiceQueues.JobServiceContinueQueue };
                options.WorkerCount = _appConfig.AppSettings.HangfireWorkerCount_JobServiceContinueQueue;
                options.ServerName = string.Format("{0}.{1}", Environment.MachineName, Guid.NewGuid().ToString());
            });

            services.AddHangfireServer(options =>
            {
                options.Queues = new string[] { JobServiceQueues.JobServiceFinalizeQueue };
                options.WorkerCount = _appConfig.AppSettings.HangfireWorkerCount_JobServiceFinalizeQueue;
                options.ServerName = string.Format("{0}.{1}", Environment.MachineName, Guid.NewGuid().ToString());
            });

            services.AddHangfireServer(options =>
            {
                options.Queues = new string[] { JobServiceQueues.JobServiceHandleResponse };
                options.WorkerCount = _appConfig.AppSettings.HangfireWorkerCount_JobServiceHandleResponse;
                options.ServerName = string.Format("{0}.{1}", Environment.MachineName, Guid.NewGuid().ToString());
            });


        }

        /// <summary>
        /// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseStaticFiles();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Composition JobService API V1");
                c.RoutePrefix = string.Empty;
            });

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

        }
    }
}
