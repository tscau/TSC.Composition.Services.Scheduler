﻿using DCS.Composition.Services.JobService.Config;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Shared.DataAccess.Outbound.Database;
using DCS.Shared.DataAccess.Outbound.Documents;
using DCS.Shared.DataAccess.Outbound.Enums;
using Hangfire.Server;
using Microsoft.Data.SqlClient;
using System;

namespace DCS.Composition.Services.JobService.Common
{
    public class OutboundHelper : IOutboundHelper
    {
        public DbContext DbContext { get; }

        readonly IAppConfig _appConfig;

        public OutboundHelper(IAppConfig appConfig)
        {
            _appConfig = appConfig;
            DbContext = new DbContext(() => new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen));
        }

        /// <summary>
        /// Handle DcsBatchHistory recording
        /// </summary>
        /// <param name="message"></param>
        /// <param name="context"></param>
        /// <param name="db"></param>
        /// <param name="statusToRecord"></param>
        public void UpdateBatchHistory(CompositionMsg message, PerformContext context, DcsBatchHistoryStatusEnum statusToRecord)
        {
            DcsBatchHistory recordToAdd;

            recordToAdd = new DcsBatchHistory
            {
                BatchId = message.BatchId,
                CreatedDt = DateTime.Now,
                CreatedId = _appConfig.AppSettings.UserToRecordAgainst,
                GSScheduleId = message.GSScheduleId,
                JSScheduleId = message.JGScheduleId
            };
            long temp;
            if (context != null)
            {
                long.TryParse(context.BackgroundJob.Id, out temp);
            }
            else
            {
                temp = -1;
            }
            recordToAdd.HangfireJobId = temp;
            recordToAdd.JSScheduleId = message.JGScheduleId;
            recordToAdd.NewStatusId = (int)statusToRecord;
            recordToAdd.UpdateMsgTxt = $"Created by {_appConfig.AppSettings.UserToRecordAgainst}";

            DbContext.AddDcsBatchHistory(recordToAdd);
        }




        /// <summary>
        /// update the campaign scheduled compoistion status
        /// </summary>
        /// <param name="scheduleId"></param>
        /// <param name="jobId"></param>
        /// <param name="compStatusText"></param>
        /// <param name="officerId"></param>

        public void UpdateCampaignScheduleHFCompositionSchedule(long scheduleId, long jobId, string compStatusText, string officerId)
        {
            DbContext.UpdateCampaignScheduleHFCompositionSchedule(scheduleId, jobId, compStatusText, officerId);
        }

        /// <summary>
        /// update the campaign scheduled compoistion status
        /// </summary>
        /// <param name="scheduleId"></param>
        /// <param name="jobId"></param>
        /// <param name="compStatusText"></param>
        /// <param name="officerId"></param>

        public void UpdateCampaignScheduleBatchId(long scheduleId, long batchId, string officerId)
        {
            DbContext.UpdateCampaignScheduleBatchId(scheduleId, batchId, officerId);
        }
    }
}
