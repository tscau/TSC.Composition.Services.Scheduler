﻿using DCS.Composition.Services.Shared.Contracts;

namespace DCS.Composition.Services.JobService.Common
{
    public interface IHangfireClient
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="parentJobId"></param>
        /// <returns></returns>
        public string JobServiceHandleResponse(CompositionMsg msg, string parentJobId);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        //public void SendHandleResponse(CompositionMsg message);
    }
}
