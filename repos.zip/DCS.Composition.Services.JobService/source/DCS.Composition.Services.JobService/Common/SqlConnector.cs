﻿using DCS.Composition.Services.JobService.Config;
using DCS.Composition.Services.JobService.Contracts;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using System;

namespace DCS.Composition.Services.JobService.Common
{
    public class SqlConnector : ISqlConnector
    {
        readonly private SqlConnection _connection;
        readonly ILogger<SqlConnector> _logger;

        readonly IAppConfig _appConfig;

        public SqlConnector(ILogger<SqlConnector> logger, IAppConfig appConfig)
        {
            _appConfig = appConfig;
            _connection = new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen);
            _logger = logger;
        }

        public StoredConfig FetchConfig()
        {
            throw new NotImplementedException();
        }

        public void LogRecord(string message)
        {
            _logger.LogWarning("SqlHelper.LogRecord is not implemented yet");
        }
    }
}
