﻿namespace DCS.Composition.Services.JobService.Common
{
    public interface IFileSystemHelper
    {
        /// <summary>
        /// Creates a folder and returns the final path to this folder
        /// </summary>
        /// <param name="path">Path including the new folder name</param>
        /// <returns></returns>
        string CreateFolder(string path);

        /// <summary>
        /// Creates a file and returns the final path to this folder
        /// </summary>
        /// <param name="path">Path to the folder the file should be created (including the filename)</param>
        /// <param name="content">File text</param>
        /// <param name="append">Should the file be appended with the new text (= true) or be rewritten (= false)</param>
        /// <returns></returns>
        string WriteFile(string path, string content, bool append = false);

        /// <summary>
        /// If job_orchestrator control file contains PREPROCESSOR_OPTIONS string then returns true
        /// </summary>
        /// <param name="controlFilePath">Path to job_orchestrator file</param>
        /// <returns>If job_orchestrator control file contains PREPROCESSOR_OPTIONS string then returns true</returns>
        bool ShouldTriggerCsv(string controlFilePath);

        /// <summary>
        /// Check if control file contains one of this values ‘Default_CSV_Group’ or ‘Default_CSV_Print_Group’, if so return TRUE
        /// </summary>
        /// <param name="controlFilePath"></param>
        /// <returns>TRUE if provided file contains ‘Default_CSV_Group’ or ‘Default_CSV_Print_Group’ strings</returns>
        bool ShouldCopyCsvDriver(string controlFilePath);
    }
}
