﻿using DCS.Composition.Services.JobService.Contracts;

namespace DCS.Composition.Services.JobService.Common
{
    public interface ISqlConnector
    {
        /// <summary>
        /// Retrevies the configuration record from the config DB
        /// </summary>
        /// <returns></returns>
        StoredConfig FetchConfig();

        /// <summary>
        /// Write a log message to the log table
        /// </summary>
        /// <param name="message">Message to log</param>
        void LogRecord(string message);
    }
}
