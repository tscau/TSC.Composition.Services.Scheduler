﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Reflection;

namespace DCS.Composition.Services.JobService.Common
{
    public class AppConfig
    {
        public AppSettings AppSettingsSection { get; set; }
        public LoggingSettings LoggingSettingsSection { get; set; }
        public KestrelSettings KestrelSettingsSection { get; set; }

        public ConnectionStrings ConnectionStringsSection { get; set; }

        public AppConfig()
        {
            AppSettingsSection = new AppSettings();
            LoggingSettingsSection = new LoggingSettings();
            KestrelSettingsSection = new KestrelSettings();
            ConnectionStringsSection = new ConnectionStrings();
        }

        public class AppSettings
        {
            // <summary>
            /// The environment we are in. e.g. DEM,DEQ, etc
            /// </summary>
            public string Env => ConfigurationManager.AppSettings.Get("Env");

            public int HangfireWorkerCount
            {
                get
                {
                    int.TryParse(ConfigurationManager.AppSettings.Get("HangfireWorkerCount"), out int hangfireWorkerCount);
                    if (hangfireWorkerCount == 0)
                    {
                        hangfireWorkerCount = 10;
                    }

                    return hangfireWorkerCount;
                }
            }
            public string UserToRecordAgainst
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("UserToRecordAgainst");
                }
            }

            public string FolderRootPath => ConfigurationManager.AppSettings.Get("FolderRootPath");

            public string OdtsAuthUrl => ConfigurationManager.AppSettings.Get("ODTSAuthUrl");

            public string CcsRestServiceUrl => ConfigurationManager.AppSettings.Get("CCSRestUrl");

            public string CCSUserName => ConfigurationManager.AppSettings.Get("CCSUserName");

            public string CCSPassword => ConfigurationManager.AppSettings.Get("CCSPassword");

            public string FakeCCSCall => ConfigurationManager.AppSettings.Get("FakeCCSCall");

            public string CCSServiceName => ConfigurationManager.AppSettings.Get("CCSServiceName");

            public string CCSAsync => ConfigurationManager.AppSettings.Get("CCSAsync");

            public string CCSVersion => ConfigurationManager.AppSettings.Get("CCSVersion");

            /// <summary>
            /// Returns the version of the application
            /// </summary>
            public Version Version => Assembly.GetExecutingAssembly().GetName().Version;

            /// <summary>
            /// Returns the version of the application
            /// </summary>
            public Dictionary<string, AssemblyVersionDetails> Versions
            {
                get
                {
                    Dictionary<string, AssemblyVersionDetails> versions = new Dictionary<string, AssemblyVersionDetails>();
                    AssemblyVersionDetails details = new AssemblyVersionDetails
                    {
                        ReleaseBuild = Assembly.GetExecutingAssembly().GetName().Version.ToString(),
                        ReleaseVersion = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                        BuildNumber = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                        ReleaseName = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyProductAttribute>().Product
                    };
                    versions.Add(Assembly.GetExecutingAssembly().GetName().Name, details);

                    Assembly sharedAssembly = Assembly.Load("DCS.Composition.Services.Shared");
                    details = new AssemblyVersionDetails
                    {
                        ReleaseBuild = sharedAssembly.GetName().Version.ToString(),
                        ReleaseVersion = sharedAssembly.GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                        BuildNumber = sharedAssembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                        ReleaseName = sharedAssembly.GetCustomAttribute<AssemblyProductAttribute>().Product
                    };
                    versions.Add(sharedAssembly.GetName().Name, details);

                    //add the shared assemblies as well
                    sharedAssembly = Assembly.Load("DCS.Shared.DataAccess.Outbound");
                    details = new AssemblyVersionDetails
                    {
                        ReleaseBuild = sharedAssembly.GetName().Version.ToString(),
                        ReleaseVersion = sharedAssembly.GetCustomAttribute<AssemblyFileVersionAttribute>().Version,
                        BuildNumber = sharedAssembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion,
                        ReleaseName = sharedAssembly.GetCustomAttribute<AssemblyProductAttribute>().Product
                    };
                    versions.Add(sharedAssembly.GetName().Name, details);
                    return versions;
                }
            }

            /// <summary>
            /// Returns the name of the server that is currently executing the code
            /// </summary>
            public string Server => Environment.MachineName;

            /// <summary>
            /// Job Orchestrator config file
            /// </summary>
            public string CtlJobOrchestrator => ConfigurationManager.AppSettings.Get("CtlJobOrchestrator");

            /// <summary>
            /// Folder in the batch directory which contains control files
            /// </summary>
            public string CtlControlFilesFolder => ConfigurationManager.AppSettings.Get("CtlControlFilesFolder");

            /// <summary>
            /// How many times try to access control file before the exception (in case it's still being prepared)
            /// </summary>
            public int CtlAccessMaxRetries => int.Parse(ConfigurationManager.AppSettings.Get("CtlAccessMaxRetries"));

            /// <summary>
            /// How much time to wait between the retries (see CtlAccessMaxRetries)
            /// </summary>
            public int CtlRetryIntervalInSecods => int.Parse(ConfigurationManager.AppSettings.Get("CtlRetryIntervalInSecods"));
        }

        public class LoggingSettings
        {
            public string EventLogServiceName
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("EventLogServiceName");
                }
            }
            public string LogFilePath
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("LogFilePath");
                }
            }

            public LogLevel MinimumLevel
            {
                get
                {
                    LogLevel tempLevel = LogLevel.Information;
                    string minLevel = ConfigurationManager.AppSettings.Get("MinimumLevel");
                    if (!string.IsNullOrWhiteSpace(minLevel))
                    {
                        switch (minLevel.ToLower())
                        {
                            case "debug":
                                tempLevel = LogLevel.Debug;
                                break;
                            case "trace":
                                tempLevel = LogLevel.Trace;
                                break;

                            case "critical":
                                tempLevel = LogLevel.Critical;
                                break;
                            case "error":
                                tempLevel = LogLevel.Error;
                                break;
                            case "warning":
                                tempLevel = LogLevel.Warning;
                                break;
                            case "information":
                                tempLevel = LogLevel.Information;
                                break;
                            default:
                                break;
                        }
                    }
                    return tempLevel;
                }
            }

            public Dictionary<string, LogLevel> LevelOverrides
            {
                get
                {
                    Dictionary<string, LogLevel> logLevels = new Dictionary<string, LogLevel>();
                    string logLevelsFromConfigFile = ConfigurationManager.AppSettings.Get("LevelOverrides");
                    if (!string.IsNullOrWhiteSpace(logLevelsFromConfigFile))
                    {
                        string[] overrideLevels = logLevelsFromConfigFile.Split(",");
                        foreach (string overrideLevel in overrideLevels)
                        {
                            string[] level = overrideLevel.Split("|");
                            switch (level[1].ToLower())
                            {
                                case "debug":
                                    logLevels.Add(level[0], LogLevel.Debug);
                                    break;
                                case "trace":
                                    logLevels.Add(level[0], LogLevel.Trace);
                                    break;

                                case "critical":
                                    logLevels.Add(level[0], LogLevel.Critical);
                                    break;
                                case "error":
                                    logLevels.Add(level[0], LogLevel.Error);
                                    break;
                                case "warning":
                                    logLevels.Add(level[0], LogLevel.Warning);
                                    break;
                                case "information":
                                    logLevels.Add(level[0], LogLevel.Information);
                                    break;
                                default:
                                    break;
                            }

                        }
                    }
                    return logLevels;
                }
            }
            public bool IsJson
            {
                get
                {
                    bool.TryParse(ConfigurationManager.AppSettings.Get("IsJson"), out bool isJson);
                    return isJson;
                }
            }
            public long FileSizeLimitBytes
            {
                get
                {
                    long.TryParse(ConfigurationManager.AppSettings.Get("FileSizeLimitBytes"), out long fileSizeLimitBytes);
                    if (fileSizeLimitBytes == 0)
                    {
                        fileSizeLimitBytes = 536870912;
                    }
                    return fileSizeLimitBytes;
                }
            }
            public int RetainedFileCountLimit
            {
                get
                {
                    int.TryParse(ConfigurationManager.AppSettings.Get("RetainedFileCountLimit"), out int retainedFileCountLimit);
                    if (retainedFileCountLimit == 0)
                    {
                        retainedFileCountLimit = 31;
                    }
                    return retainedFileCountLimit;
                }
            }

            public string OutputTemplate
            {
                get
                {
                    string outputTemplate = ConfigurationManager.AppSettings.Get("OutputTemplate");
                    if (string.IsNullOrWhiteSpace(outputTemplate))
                    {
                        outputTemplate = "{Timestamp:o} {RequestId,13} [{Level:u3}] {Message} ({EventId:x8}){NewLine}{Exception}";
                    }
                    return outputTemplate;
                }
            }
            public string LogServiceUrl
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("LogServiceUrl");
                }
            }
        }

        public class KestrelSettings
        {
            public int RESTAPIPort
            {
                get
                {
                    int.TryParse(ConfigurationManager.AppSettings.Get("RESTAPIPort"), out int port);
                    return port;
                }
            }

            public bool UseCertificateForSSL
            {
                get
                {
                    bool.TryParse(ConfigurationManager.AppSettings.Get("UseCertificateForSSL"), out bool useSSL);
                    return useSSL;
                }
            }
            public string CertificateSubject
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("CertificateSubject");
                }
            }
            public string CertificateStoreName
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("CertificateStoreName");
                }
            }

            public string CertificateLocation
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("CertificateLocation");
                }
            }
            public bool CertificateAllowInvalid
            {
                get
                {
                    bool.TryParse(ConfigurationManager.AppSettings.Get("CertificateAllowInvalid"), out bool allowInvalid);
                    return allowInvalid;
                }
            }
        }


        public class ConnectionStrings
        {

            /// <summary>
            /// The Connection SAtring for the Outbound database
            /// </summary>
            public string OutboundCorroGen { get { return ConfigurationManager.ConnectionStrings["OutboundCorroGen"].ConnectionString; } }

            /// <summary>
            /// The connections tring for the hangfire database
            /// </summary>
            public string HangfireDb { get { return ConfigurationManager.ConnectionStrings["Hangfire"].ConnectionString; } }
        }

    }
}
