﻿using DCS.Composition.Services.JobService.Contracts;
using System.Threading.Tasks;

namespace DCS.Composition.Services.JobService.Common
{
    public interface IHttpHelper
    {
        /// <summary>
        /// Get OTDS authentication token. This token will be required to access CCS
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns>OTDS authentication token</returns>
        Task<string> Authenticate(string userName, string password);

        /// <summary>
        /// HTTP POST to command centre with required parameters
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        //Task<string> SendRequestToCc(CCRequest request);
        Task<string> SendRequestToCc(CCRequest request, string otdsTicket);
    }
}
