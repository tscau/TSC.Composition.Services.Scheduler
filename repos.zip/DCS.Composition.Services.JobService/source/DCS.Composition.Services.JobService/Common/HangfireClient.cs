﻿using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.JobService;
using Hangfire;

namespace DCS.Composition.Services.JobService.Common
{
    public class HangfireClient : IHangfireClient
    {

        public string JobServiceHandleResponse(CompositionMsg msg, string parentJobId)
        {
            return BackgroundJob.ContinueJobWith<IJobService>(parentJobId, x => x.JobServiceHandleResponse(msg, null));
        }

        public void SendHandleResponse(CompositionMsg message)
        {
            BackgroundJob.Enqueue<IJobService>(x => x.JobServiceHandleResponse(message, null));
        }
    }
}
