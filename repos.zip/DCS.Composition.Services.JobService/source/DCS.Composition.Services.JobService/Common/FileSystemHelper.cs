﻿using DCS.Composition.Services.JobService.Config;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Threading;

namespace DCS.Composition.Services.JobService.Common
{
    public class FileSystemHelper : IFileSystemHelper
    {
        readonly ILogger<FileSystemHelper> _logger;
        readonly IAppConfig _appConfig;

        public FileSystemHelper(ILogger<FileSystemHelper> logger, IAppConfig appConfig)
        {
            _logger = logger;
            _appConfig = appConfig;
        }

        public string CreateFolder(string path)
        {
            if (Directory.Exists(path))
            {
                _logger.LogInformation($"Folder '{path}' exists, no need to create another one.");
                return path;
            }

            _logger.LogInformation($"Creating a new folder '{path}'.");
            var info = Directory.CreateDirectory(path);

            return info?.FullName;
        }

        public bool ShouldTriggerCsv(string controlFilePath)
        {
            var stringToContain = "PREPROCESSOR_OPTIONS";

            var controlFileContent = ReadFile(controlFilePath);

            if (string.IsNullOrEmpty(controlFileContent))
            {
                var errMsg = $"ShouldTriggerCsv. Cannot access config gile {controlFilePath}. Stopping the processing.";
                _logger.LogError(errMsg);
                throw new Exception(errMsg);
            }

            return controlFileContent.Contains(stringToContain);
        }

        public bool ShouldCopyCsvDriver(string controlFilePath)
        {
            var controlFileContent = ReadFile(controlFilePath);

            string defaultCsvGroup = "default_csv_group", defaultCsvPrintGroup = "default_csv_print_group";

            if (string.IsNullOrEmpty(controlFileContent))
            {
                var errMsg = $"ShouldCopyCsvDriver. Cannot access config gile {controlFilePath}. Stopping the processing.";
                _logger.LogError(errMsg);
                throw new Exception(errMsg);
            }

            return controlFileContent.ToLower().Contains(defaultCsvGroup) || controlFileContent.ToLower().Contains(defaultCsvPrintGroup);
        }

        public string WriteFile(string path, string content, bool append = false)
        {
            if (File.Exists(path) && append)
            {
                File.AppendAllText(path, content);
            }
            else
            {
                File.WriteAllText(path, content);
            }

            _logger.LogInformation($"New content was successfully written to file {path}.");
            return path;
        }

        private string ReadFile(string filePath)
        {

            int maxTries = _appConfig.AppSettings.CtlAccessMaxRetries, interwalInSeconds = _appConfig.AppSettings.CtlRetryIntervalInSeconds;
            for (int i = 0; i < maxTries; i++)
            {
                try
                {
                    return File.ReadAllText(filePath);
                }
                catch (Exception e)
                {
                    _logger.LogWarning($"Cannot access file {filePath}'. Trying again in a second. {e}");
                    Thread.Sleep(interwalInSeconds * 1000);
                }
            }

            return null;
        }
    }
}
