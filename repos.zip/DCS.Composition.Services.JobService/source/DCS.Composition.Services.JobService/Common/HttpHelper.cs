﻿using DCS.Composition.Services.JobService.Config;
using DCS.Composition.Services.JobService.Contracts;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DCS.Composition.Services.JobService.Common
{
    public class HttpHelper : IHttpHelper
    {
        private string _otdsTicket;
        readonly HttpClient _client;
        readonly ILogger<HttpHelper> _logger;
        readonly IAppConfig _appConfig;

        public HttpHelper(ILogger<HttpHelper> logger, IAppConfig appConfig)
        {
            _client = new HttpClient();
            _logger = logger;
            _appConfig = appConfig;
        }

        /// <summary>
        /// Get OTDS authentication token. This token will be required to access CCS
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns>OTDS authentication token</returns>
        public async Task<string> Authenticate(string userName, string password)
        {
            var payload = "{\"user_name\": \"" + userName + "\",\"password\": \"" + password + "\"}";

            HttpContent body = new StringContent(payload, Encoding.UTF8, "application/json");
            string result = string.Empty;
            try
            {
                HttpResponseMessage response = await _client.PostAsync(new Uri(_appConfig.AppSettings.ODTSAuthUrl), body);

                result = await response.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException e)
            {
                _logger.LogError($"Exception during the authentication: {e.Message}");
            }

            var json = JObject.Parse(result);

            _logger.LogInformation($"Authenication token obtained successfully: {json}");

            _otdsTicket = (string)json["ticket"];

            _logger.LogInformation($"Authenication token obtained successfully");

            return _otdsTicket;
        }

        public async Task<string> SendRequestToCc(CCRequest request, string otdsTicket)
        {
            var base64Payload = "PFJlcXVlc3Q+DQoJPFR5cGU+QmF0Y2hQcmltYXJ5PC9UeXBlPg0KPC9SZXF1ZXN0Pg==";

            //NOTE OT requries that the BatchLocation be encoded in a specific way. e.g. "\u005C\u005CDCSXFLS00009DE.devtest.atohdtnet.gov.au\u005CDCSCORRES_DE\u005CDEM\u005CJobs\u005CBatch\u005C1120"            
            var payload = new TestRequestParams
            {
                BatchLocation = (request.BatchFolder.Replace(@"\", "\u005C")),
                Content = new Dictionary<string, string>
                {
                    { "contentType", "text/xml"},
                    { "data", base64Payload }
                }
            };

            //Header name: OTDSTicket 
            if (string.IsNullOrEmpty(otdsTicket))
            {
                throw new InvalidOperationException("You should use Authenticate method first. OTDSTicket is null.");
            }

            string uriString = _appConfig.AppSettings.CCSRestUrl + "?name=" + _appConfig.AppSettings.CCSServiceName + "&version=" + _appConfig.AppSettings.CCSVersion + "&async=" + _appConfig.AppSettings.CCSAsync;
            Uri urlToCall = new Uri(uriString);
            _logger.LogInformation($"Calling {urlToCall.AbsoluteUri}");


            HttpContent body = new StringContent(JsonConvert.SerializeObject(payload), Encoding.UTF8, "application/json");
            string result = string.Empty;
            try
            {
                var httpRequestMessage = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = urlToCall,
                    Headers = {
                        { HttpRequestHeader.Accept.ToString(), "application/json" },
                        { "OTDSTicket", otdsTicket }
                    },
                    Content = body
                };


                ////Terry Harris forrr running locally without ssl on your dev box, otherwise will get error due to ssl 
                //try
                //{
                //    // requrired for ssl https to work otherwise you will get a "The request was aborted: Could not create SSL/TLS secure channel." error
                //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12 | (SecurityProtocolType)3072;
                //    ServicePointManager.ServerCertificateValidationCallback = null;
                //    ServicePointManager.Expect100Continue = true;
                //    using (var handler = new HttpClientHandler())
                //    {
                //        using (var _newClient = new HttpClient(handler))
                //        {
                //            HttpResponseMessage response = _newClient.SendAsync(httpRequestMessage).Result;
                //            response.EnsureSuccessStatusCode();
                //            result = response.Content.ReadAsStringAsync().ConfigureAwait(false).GetAwaiter().GetResult();
                //        }
                //    }
                //}
                //catch (Exception ex)
                //{
                //    throw ex;
                //}

                if (_appConfig.AppSettings.CCSOutputFile)
                {
                    var filePath = Path.Combine(request.BatchFolder, "CCSPayload.json.queued");
                    using (StreamWriter outputFile = new StreamWriter(filePath))
                    {
                        outputFile.WriteLine(JsonConvert.SerializeObject(payload, Formatting.Indented));
                        outputFile.Flush();
                        outputFile.Close();
                    }
                }

                var response = _client.SendAsync(httpRequestMessage).Result;

                result = await response.Content.ReadAsStringAsync();

                _logger.LogInformation($"Result from calling CGS: {result}");

                Console.WriteLine(result);
            }
            catch (HttpRequestException e)
            {
                _logger.LogError($"Exception Caught: {e.Message}: {e.StackTrace}");
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
                throw;

            }

            return result;
        }
    }

    public struct TestRequestParams
    {
        [JsonProperty("application")]
        public string Application { get; set; }

        [JsonProperty("content")]
        public Dictionary<string, string> Content { get; set; }

        [JsonProperty("BATCHLOCATION")]
        public string BatchLocation { get; set; }
    }
}
