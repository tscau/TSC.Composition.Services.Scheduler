﻿using DCS.Composition.Services.Shared.Contracts;
using DCS.Shared.DataAccess.Outbound.Database;
using DCS.Shared.DataAccess.Outbound.Enums;
using Hangfire.Server;

namespace DCS.Composition.Services.JobService.Common
{
    public interface IOutboundHelper
    {
        DbContext DbContext { get; }

        /// <summary>
        /// Handle DcsBatchHistory recording
        /// </summary>
        /// <param name="message"></param>
        /// <param name="context"></param>
        /// <param name="db"></param>
        /// <param name="statusToRecord"></param>
        void UpdateBatchHistory(CompositionMsg message, PerformContext context, DcsBatchHistoryStatusEnum statusToRecord);

        void UpdateCampaignScheduleHFCompositionSchedule(long scheduleId, long jobId, string compStatusText, string officerId);
        void UpdateCampaignScheduleBatchId(long scheduleId, long batchId, string officerId);
    }
}
