using DCS.Composition.Services.JobService.Config;
using DCS.Logging.Shared.Infrastructure;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Https;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using System;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Threading.Tasks;

namespace DCS.Composition.Services.JobService
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            Log.Logger = new LoggerConfiguration()
                    .ReadFrom.AppSettings()
                    .Enrich.WithMachineName()
                    .CreateLogger();

            AppLog.Info()(0, $"Loading Composition Job Services under user {WindowsIdentity.GetCurrent().Name} on machine {System.Environment.MachineName} from {AssemblyHelpers.GetExecutingAssemblyFullName()} Version {AssemblyHelpers.GetExecutingAssemblyVersion()} on machine {Environment.MachineName} as Process Id {AssemblyHelpers.GetExecutingProcess()}.");

            try
            {
                AppLog.Info()(0, "Starting DCS.Composition.Services.JobService Service...");
                await CreateHostBuilder(args).Build().RunAsync();
                AppLog.Info()(0, "Starting DCS.Composition.Services.JobService Service");
            }
            catch (Exception ex)
            {
                AppLog.Error()(null, 0, "DCS.Composition.Services.JobService service start-up failed! {ex}", ex);
            }
            finally
            {
                Log.CloseAndFlush();
            }

        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseWindowsService()
                .ConfigureLogging(logging =>
                {
                    logging.AddSerilog();
                })
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.ConfigureServices(services =>
                    {
                        services.AddSingleton<IAppConfig, AppConfig>();
                    });

                    webBuilder.ConfigureKestrel(configure =>
                    {
                        AppConfig cfg = new AppConfig();
                        if (cfg.Kestrel.UseCertificateForSSL)
                        {
                            configure.ListenAnyIP(cfg.Kestrel.RESTAPIPort, listOptions =>
                            {

                                listOptions.UseHttps(httpsOptions =>
                                {
                                    var location = (cfg.Kestrel.CertificateLocation.ToLower()) switch
                                    {
                                        "currentuser" => StoreLocation.CurrentUser,
                                        "localmachine" => StoreLocation.LocalMachine,
                                        _ => StoreLocation.LocalMachine,
                                    };
                                    var cert = CertificateLoader.LoadFromStoreCert(cfg.Kestrel.CertificateSubject, cfg.Kestrel.CertificateStoreName, location, cfg.Kestrel.CertificateAllowInvalid);
                                    httpsOptions.ServerCertificate = cert;
                                });
                            });
                        }
                        else
                        {
                            configure.ListenAnyIP(cfg.Kestrel.RESTAPIPort);

                        }
                    });
                    webBuilder.UseStartup<Startup>();


                });
    }
}
