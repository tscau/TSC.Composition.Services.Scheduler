﻿using DCS.Composition.Services.JobService.Config;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.JobService;
using DCS.PostComposition.Services.JobService.Common;
using Hangfire;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace DCS.Composition.Services.JobService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobServiceController : ControllerBase
    {
        readonly IAppConfig _appConfig;
        public JobServiceController(IAppConfig appConfig)
        {
            _appConfig = appConfig;
        }

        [HttpPost]
        [Route("CallStartViaHF")]
        public JsonResult CallStartViaHF(CompositionMsg message)
        {
            string hfJobId = BackgroundJob.Enqueue<IJobService>(x => x.Start(message, null));
            return new JsonResult(hfJobId);
        }


        [HttpPost]
        [Route("ContinueEnqueueViaHF")]
        public JsonResult ContinueEnqueueViaHF(CompositionMsg inputParams)
        {
            string hfJobId = BackgroundJob.Enqueue<IJobService>(x => x.ContinueEnqueue(inputParams, null));
            return new JsonResult(hfJobId);
        }


        /// <summary>
        /// Method to get the current config entries for the application. Returns as a string.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetCurrentConfig")]
        public JsonResult GetCurrentConfig()
        {
            return new JsonResult(_appConfig);
        }

        /// <summary>
        /// Method to get the heartbeat of the service. Provided so that other apps can query the service
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("Heartbeat")]
        public JsonResult Heartbeat()
        {
            return new JsonResult("running");
        }

        /// <summary>
        /// REST end point to get the version of the application and any shared components that make sense to report on
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("VersionInfo")]
        public ActionResult<Dictionary<string, AssemblyVersionDetails>> VersionInfo()
        {
            var assemblyVersions = new[]
                {
                    AssemblyVersionDetails.FromAssembly(Assembly.GetExecutingAssembly()),
                    AssemblyVersionDetails.FromAssemblyName("DCS.Composition.Services.Shared"),
                    AssemblyVersionDetails.FromAssemblyName("DCS.Shared.DataAccess.Outbound"),
                }
                .ToDictionary(x => x.name, x => x.assemblyVersionDetails);

            return new JsonResult(assemblyVersions);
        }

    }
}
