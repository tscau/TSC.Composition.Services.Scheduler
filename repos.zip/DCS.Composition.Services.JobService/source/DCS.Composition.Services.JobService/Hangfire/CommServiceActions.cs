﻿using DCS.Composition.Services.JobService.Common;
using DCS.Composition.Services.JobService.Config;
using DCS.Composition.Services.JobService.Contracts;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.JobService;
using DCS.Logging.Shared.Common;
using DCS.Logging.Shared.Infrastructure;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Database;
using DCS.Shared.DataAccess.Outbound.Documents;
using DCS.Shared.DataAccess.Outbound.Enums;
using Hangfire.JobsLogger;
using Hangfire.Server;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;

namespace DCS.Composition.Services.JobService.Hangfire
{
    public class CommServiceActions : ICommService
    {
        readonly ILogger<CommServiceActions> _logger;
        readonly IHttpHelper _httpHelper;
        readonly IAppConfig _appConfig;

        public CommServiceActions(ILogger<CommServiceActions> logger, IHttpHelper httpHelper, IAppConfig appConfig)
        {
            _logger = logger;
            _httpHelper = httpHelper;
            _appConfig = appConfig;
        }

        //[Queue(JobServiceQueues.CcsServiceQueue)]
        public void RequestCcs(CompositionMsg inputParams, PerformContext context)
        {
            DCSLogMsg logMsg = new DCSLogMsg
            {
                Application = "DCS.Composition.Services.JobService",
                Server = _appConfig.AppSettings.Server,
                ApplicationVersion = _appConfig.AppSettings.Version.ToString(),
                GSScheduleId = inputParams.GSScheduleId,
                JGScheduleId = inputParams.JGScheduleId,
                DeliveryChannel = inputParams.DeliveryChannel,
                NatDins = string.Join(",", inputParams.NatDins),
                BatchId = inputParams.BatchId,
                LogDatetime = DateTime.Now,
                LogLevel = LogLevel.Information
            };
            string messageAsJson = JsonConvert.SerializeObject(inputParams);

            //Create the job log file so we have a record in the job folder and we do not have to hunt through the central log
            var BatchLog = PerBatchLog.CreateForBatchId(inputParams.BatchId, inputParams.JobPath, _appConfig.Logging.RelativeJobLogFileLocation, _appConfig.Logging.LogFileName);


            try
            {
                if (context != null)
                {
                    context.LogInformation($"Started RequestCcs for batch = {inputParams.BatchId}");
                }
                BatchLog.Info()("Received JobService.Start job with input parameters: {inputParams}", inputParams.ParseCompositionMsgToJsonString());

                logMsg.WriteLogEntry(_logger, _appConfig.Logging.LogServiceUrl, LogLevel.Information, $"Received JobService.Start job with input parameters: {inputParams.ParseCompositionMsgToJsonString()}", null);

                if (context != null)
                {
                    context.LogInformation($"Received JobService.Start job with input parameters: {inputParams.ParseCompositionMsgToJsonString()}");
                }

                IOutbound db = new DbContext(() => new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen));
                try
                {
                    DcsBatchHistory recordToAdd = new DcsBatchHistory
                    {
                        BatchId = inputParams.BatchId,
                        CreatedDt = DateTime.Now,
                        CreatedId = "CCSSVC",
                        GSScheduleId = inputParams.GSScheduleId,
                        JSScheduleId = inputParams.JGScheduleId
                    };
                    long temp = 0;
                    if (context == null)
                    {
                        recordToAdd.HangfireJobId = 0;
                    }
                    else
                    {
                        long.TryParse(context.BackgroundJob.Id, out temp);
                        recordToAdd.HangfireJobId = temp;
                    }

                    recordToAdd.JSScheduleId = inputParams.JGScheduleId;
                    recordToAdd.NewStatusId = (int)DcsBatchHistoryStatusEnum.CompositionCalled;
                    recordToAdd.UpdateMsgTxt = "Created by CCS Service Call";
                    db.AddDcsBatchHistory(recordToAdd);


                    if (_appConfig.AppSettings.FakeCCSCall == "true")
                    {
                        if (context != null)
                        {
                            context.LogInformation($"Successfully received response from CCS - FakeCall for {inputParams.BatchId}");
                        }
                        BatchLog.Info()("Successfully received response from CCS - FakeCall for {BatchId}", inputParams.BatchId);
                        logMsg.WriteLogEntry(_logger, _appConfig.Logging.LogServiceUrl, LogLevel.Information, $"Successfully received response from CCS - FakeCall", null);

                        recordToAdd = new DcsBatchHistory
                        {
                            BatchId = inputParams.BatchId,
                            CreatedDt = DateTime.Now,
                            CreatedId = "CCSSVC",
                            GSScheduleId = inputParams.GSScheduleId,
                        };
                        if (context == null)
                        {
                            recordToAdd.HangfireJobId = 0;
                        }
                        else
                        {
                            long.TryParse(context.BackgroundJob.Id, out temp);
                            recordToAdd.HangfireJobId = temp;
                        }

                        recordToAdd.JSScheduleId = inputParams.JGScheduleId;
                        recordToAdd.NewStatusId = (int)DcsBatchHistoryStatusEnum.CompositionCompleted;
                        recordToAdd.UpdateMsgTxt = "Created by CCS Service Call";
                        db.AddDcsBatchHistory(recordToAdd);
                    }
                    else
                    {
                        if (context != null)
                        {
                            context.LogInformation($"Requesting OTDS ticket;");
                        }
                        BatchLog.Info()("ComServiceActions::Requesting OTDS ticket");
                        logMsg.WriteLogEntry(_logger, _appConfig.Logging.LogServiceUrl, LogLevel.Information, $"ComServiceActions::Requesting OTDS ticket", null);

                        var ticket = _httpHelper.Authenticate(_appConfig.AppSettings.CCSUserName, _appConfig.AppSettings.CCSPassword).Result;
                        if (string.IsNullOrEmpty(ticket))
                        {
                            if (context != null)
                            {
                                context.LogError($"Got an empty OTDS ticket for batch {inputParams.BatchId}");
                            }

                            string errorMessage = $"Got an empty OTDS ticket for batch {inputParams.BatchId}";
                            BatchLog.Error()("Got an empty OTDS ticket for batch {BatchId}", inputParams.BatchId);
                            logMsg.WriteLogEntry(_logger, _appConfig.Logging.LogServiceUrl, LogLevel.Error, errorMessage, null);
                            throw new ArgumentException(errorMessage);
                        }

                        BatchLog.Info()("Calling   _httpHelper.SendRequestToCc: {messageAsJson}", messageAsJson);
                        logMsg.WriteLogEntry(_logger, _appConfig.Logging.LogServiceUrl, LogLevel.Information, $"Calling   _httpHelper.SendRequestToCc: {messageAsJson}", null);

                        var serviceResponse = _httpHelper.SendRequestToCc(MapCompositionMsgToCCRequest(inputParams), ticket).Result;

                        if (context != null)
                        {
                            context.LogInformation($"Successfully received response from CCS: {serviceResponse}");
                        }
                        BatchLog.Info()("Successfully received response from CCS: {serviceResponse}", serviceResponse);
                        logMsg.WriteLogEntry(_logger, _appConfig.Logging.LogServiceUrl, LogLevel.Information, $"Successfully received response from CCS: {serviceResponse}", null);

                        recordToAdd = new DcsBatchHistory
                        {
                            BatchId = inputParams.BatchId,
                            CreatedDt = DateTime.Now,
                            CreatedId = "CCSSVC",
                            GSScheduleId = inputParams.GSScheduleId
                        };
                        if (context == null)
                        {
                            recordToAdd.HangfireJobId = 0;
                        }
                        else
                        {
                            long.TryParse(context.BackgroundJob.Id, out long temp2);
                            recordToAdd.HangfireJobId = temp2;
                        }

                        recordToAdd.JSScheduleId = inputParams.JGScheduleId;
                        recordToAdd.NewStatusId = (int)DcsBatchHistoryStatusEnum.CompositionCompleted;
                        recordToAdd.UpdateMsgTxt = "Created by CCS Service Call";
                        db.AddDcsBatchHistory(recordToAdd);
                    }
                }
                catch (Exception ex)
                {
                    BatchLog.Fatal()("Exception occured in RequestCcs: {errorMessage}; {stackTrace}", ex.Message, ex.StackTrace);
                    logMsg.WriteLogEntry(_logger, _appConfig.Logging.LogServiceUrl, LogLevel.Information, $"Exception occured in RequestCcs: {ex.Message}; {ex.StackTrace}", ex);

                    DcsBatchHistory recordToAdd = new DcsBatchHistory
                    {
                        BatchId = inputParams.BatchId,
                        CreatedDt = DateTime.Now,
                        CreatedId = "CCSSVC",
                        GSScheduleId = inputParams.GSScheduleId
                    };
                    if (context == null)
                    {
                        recordToAdd.HangfireJobId = 0;
                    }
                    else
                    {
                        long.TryParse(context.BackgroundJob.Id, out long temp);
                        recordToAdd.HangfireJobId = temp;
                    }

                    recordToAdd.JSScheduleId = inputParams.JGScheduleId;
                    recordToAdd.NewStatusId = (int)DcsBatchHistoryStatusEnum.CompositionFailed;
                    recordToAdd.UpdateMsgTxt = "Created by CCS Service Call";
                    db.AddDcsBatchHistory(recordToAdd);

                }
            }
            catch (Exception ex)
            {
                BatchLog.Fatal(ex, "Exception occured in RequestCcs: {errorMessage}; {stackTrace}", ex.Message, ex.StackTrace);
                logMsg.WriteLogEntry(_logger, _appConfig.Logging.LogServiceUrl, LogLevel.Information, $"Exception occured in RequestCcs: {ex.Message}; {ex.StackTrace}", ex);
                throw;
            }
            finally
            {
                BatchLog.Dispose();
            }
        }

        /// <summary>
        /// Mapping CompositionMsg to CCRequest
        /// </summary>
        /// <param name="toMap"></param>
        /// <returns></returns>
        private CCRequest MapCompositionMsgToCCRequest(CompositionMsg toMap)
        {
            return new CCRequest
            {
                BatchFolder = toMap.JobPath,
                JobId = toMap.JGScheduleId,
                NatCd = string.Join(",", toMap.NatDins),
                ServiceName = ""
            };
        }
    }
}
