﻿using DCS.Composition.Services.JobService.Common;
using DCS.Composition.Services.JobService.Config;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.CSVPreprocessor;
using DCS.Composition.Services.Shared.DataRetrieve;
using DCS.Composition.Services.Shared.JobService;
using DCS.Composition.Services.Shared.VarsService;
using DCS.Logging.Shared.Common;
using DCS.Logging.Shared.Infrastructure;
using DCS.Shared.DataAccess.Outbound.Enums;
using Hangfire;
using Hangfire.JobsLogger;
using Hangfire.Server;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace DCS.Composition.Services.JobService.Hangfire
{
    public class JobServiceActions : IJobService
    {
        readonly IPerBatchLogger _perBatchLogger;
        readonly IFileSystemHelper _fsHelper;
        readonly IAppConfig _appConfig;

        public JobServiceActions(IPerBatchLogger perBatchLogger,
                                    IFileSystemHelper fsHelper,
                                    IAppConfig appConfig)
        {
            _perBatchLogger = perBatchLogger;
            _fsHelper = fsHelper;
            _appConfig = appConfig;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="inputParams"></param>
        /// <param name="context"></param>
        public void Start(CompositionMsg inputParams, PerformContext context)
        {
            var outboundHelper = new OutboundHelper(_appConfig);

            var logMsg = BuildDcsLog(inputParams);
            string messageAsJson = inputParams.ParseCompositionMsgToJsonString();

            try
            {
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"Received JobService.Start job with input parameters: {ParseCompositionMsgToJsonString(inputParams)}", null);

                if (context != null)
                {
                    context.LogInformation($"Received JobService.Start job with input parameters: {ParseCompositionMsgToJsonString(inputParams)}");
                }

                //Logging that the service started
                outboundHelper.UpdateBatchHistory(inputParams, context, DcsBatchHistoryStatusEnum.CompJobSErviceStarted);

                //Otherwise getting self reference exception
                CompositionMsg passingParams = inputParams;

                var latestJobId = string.Empty;

                if (context != null)
                {
                    context.LogInformation($"Creating a new folder for batch = {passingParams.BatchId}");
                }
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"Creating a new folder for batch = {passingParams.BatchId}", null);


                passingParams.JobPath = CreateBatchFolder(passingParams.BatchId);

                if (!_perBatchLogger.LogFileCreated)
                {
                    _perBatchLogger.CreateForBatchId("per-batch:serilog:", "write-to:File.path", passingParams.BatchId, passingParams.JobPath, _appConfig.Logging.RelativeJobLogFileLocation, _appConfig.Logging.LogFileName);
                }

                //campaign portal check to copy the drriver mpw and csv files to the batch folder
                if (passingParams.CampaignScheduldeMsg != null && passingParams.CampaignScheduldeMsg.InputFile != null)
                {
                    var realtimeFolder = Path.GetDirectoryName(passingParams.CampaignScheduldeMsg.InputFile);

                    //copy the mpw from this folder to the Batch Folder
                    File.Copy(Path.Combine(realtimeFolder, $"DRIVER.mpw"), Path.Combine(passingParams.JobPath, "DRIVER.mpw"));

                    //copy the csv file to the batch Folder
                    File.Copy(passingParams.CampaignScheduldeMsg.InputFile, Path.Combine(passingParams.JobPath, "DRIVER.csv"));
                }

                var logEntry = $"Passing parameters to VarsService.Start for batch id = {passingParams.BatchId}";
                if (context != null)
                {
                    context.LogInformation(logEntry);
                }
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logEntry, null);
                _perBatchLogger.Info($"Passing parameters to IVarsService.Start for batch id = {passingParams.BatchId}", new object[] { });
                latestJobId = BackgroundJob.Enqueue<IVarsService>(x => x.Start(passingParams, null));

                //campaign portal set composition start
                //update the campaign scedules setting them to processing 
                if (passingParams.CampaignScheduldeMsg != null && passingParams.CampaignScheduldeMsg.ScheduleId != null)
                {
                    logEntry = $"Setting Campaign Schhedule Composition to 'Processing' for ScehduleId: {passingParams.CampaignScheduldeMsg.ScheduleId}";
                    context.LogInformation(logEntry);
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logEntry, null);
                    _perBatchLogger.Info(logEntry, new object[] { });

                    string status = "Processing";
                    string updatedBy = "UPDATECP";
                    outboundHelper.UpdateCampaignScheduleBatchId(long.Parse(passingParams.CampaignScheduldeMsg.ScheduleId), passingParams.BatchId, updatedBy);
                    outboundHelper.UpdateCampaignScheduleHFCompositionSchedule(long.Parse(passingParams.CampaignScheduldeMsg.ScheduleId), long.Parse(latestJobId), status, updatedBy);
                }

                if (passingParams.Flags == null)
                {
                    Flags flgs = new Flags()
                    {
                        AllowBdeDelivery = true,
                        AllowDatabaseRetrieve = true,
                        AllowDatabaseUpdate = true,
                        AllowEaiDelivery = true,
                        AllowMyGovDelivery = true,
                        AllowPaperDelivery = true,
                        AllowSmppDelivery = true,
                        AllowSmtpDelivery = true,
                        CorresNotInDb = false,
                        PdfConsolidationRequired = false,
                        PsConsolidationRequired = false,
                        SendPaper = true
                    };
                    passingParams.Flags = flgs;
                }

                if (passingParams.Flags.AllowDatabaseRetrieve)
                {
                    logEntry = $"Passing parameters to IDataRetrieve.Start for batch id = {passingParams.BatchId}";
                    if (context != null)
                    {
                        context.LogInformation(logEntry);
                    }
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logEntry, null);
                    _perBatchLogger.Info($"Passing parameters to IDataRetrieve.Start for batch id = {passingParams.BatchId}", new object[] { });
                    latestJobId = BackgroundJob.ContinueJobWith<IDataRetrieve>(latestJobId, x => x.Start(passingParams, null));
                }
                else
                {

                    _perBatchLogger.Info($"Skipping IDataRetrieve. No AllowDatabaseRetrieve flag for batch id = {passingParams.BatchId}", new object[] { });
                    logEntry = $"Skipping IDataRetrieve. No AllowDatabaseRetrieve flag for batch id = {passingParams.BatchId}";
                    if (context != null)
                    {
                        context.LogInformation(logEntry);
                    }
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logEntry, null);
                }

                //Enqueue the second part once the vars is done
                logEntry = $"Passing parameters to IJobServices.ContinueEnqueue for batch id = {passingParams.BatchId}";
                if (context != null)
                {
                    context.LogInformation(logEntry);
                }
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logEntry, null);
                _perBatchLogger.Info($"Passing parameters to IJobServices.ContinueEnqueue for batch id = {passingParams.BatchId}", new object[] { });
                BackgroundJob.ContinueJobWith<IJobService>(latestJobId, x => x.ContinueEnqueue(passingParams, null));
            }
            catch (Exception ex)
            {
                //Logging that the service failed
                outboundHelper.UpdateBatchHistory(inputParams, context, DcsBatchHistoryStatusEnum.CompJobServiceFailed);
                AppLog.Error()(ex, inputParams.BatchId, $"Error processing batch {inputParams.BatchId}; {ex.Message};{ex.StackTrace}; {ex}", new object[] { });
                _perBatchLogger.Error(ex, $"Error processing batch {inputParams.BatchId}; {ex.Message};{ex.StackTrace}; {ex}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Error, $"Error Processing batch {inputParams.BatchId}.", ex);
                if (context != null)
                {
                    context.LogInformation($"Error Processing batch {inputParams.BatchId}: {ex.Message}; {ex.StackTrace}");
                }
            }
            finally
            {
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{_appConfig.AppSettings.Server} - Finished processing {messageAsJson}", null);
                _perBatchLogger.Info($"{_appConfig.AppSettings.Server} - Finished processing {messageAsJson}", new object[] { });
                _perBatchLogger.Dispose();
            }
        }

        /// <summary>
        /// When VARS service done, this service should fire up
        /// </summary>
        /// <param name="inputParams"></param>
        /// <param name="context"></param>
        //[Queue(JobServiceQueues.JobServiceContinueQueue)]
        public void ContinueEnqueue(CompositionMsg inputParams, PerformContext context)
        {
            var latestJobId = string.Empty;
            var outboundHelper = new OutboundHelper(_appConfig);
            var logMsg = BuildDcsLog(inputParams);

            if (!_perBatchLogger.LogFileCreated)
            {
                _perBatchLogger.CreateForBatchId("per-batch:serilog:", "write-to:File.path", inputParams.BatchId, inputParams.JobPath, _appConfig.Logging.RelativeJobLogFileLocation, _appConfig.Logging.LogFileName);
            }

            try
            {
                _perBatchLogger.Info($"Continue flow for batch id = {inputParams.BatchId}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"Continue flow for batch id = {inputParams.BatchId}", null);

                latestJobId = ProcessCsvFlow(inputParams, context, logMsg, latestJobId);

                _perBatchLogger.Info($"Passing parameters to ICommService.ReequestCcs for batch id = {inputParams.BatchId}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"Passing parameters to ICommService.ReequestCcs for batch id = {inputParams.BatchId}", null);

                if (string.IsNullOrEmpty(latestJobId))
                {
                    latestJobId = BackgroundJob.Enqueue<ICommService>(x => x.RequestCcs(inputParams, null));
                }
                else
                {
                    latestJobId = BackgroundJob.ContinueJobWith<ICommService>(latestJobId, x => x.RequestCcs(inputParams, null));
                }

                var lMessage = $"Enqueue the final step for batch id = {inputParams.BatchId}.";
                if (context != null)
                {
                    context.LogInformation(lMessage);
                }

                _perBatchLogger.Info($"Enqueue the final step for batch id = {inputParams.BatchId}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, lMessage, null);

                BackgroundJob.ContinueJobWith<IJobService>(latestJobId, x => x.Finalize(inputParams, null));

                lMessage = $"All jobs were successfully enqueued for batch id = {inputParams.BatchId}.";
                if (context != null)
                {
                    context.LogInformation(lMessage);
                }
                _perBatchLogger.Info($"All jobs were successfully enqueued for batch id = {inputParams.BatchId}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, lMessage, null);
            }
            catch (Exception ex)
            {
                //Logging that the service failed
                outboundHelper.UpdateBatchHistory(inputParams, context, DcsBatchHistoryStatusEnum.CompJobServiceFailed);
                _perBatchLogger.Error(ex, $"Error Processing batch {inputParams.BatchId}: {ex.Message}; {ex.StackTrace}", new object[] { });
                AppLog.Error()(ex, inputParams.BatchId, $"Error Processing batch {inputParams.BatchId}: {ex.Message}; {ex.StackTrace}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Error, $"Error Processing batch {inputParams.BatchId}.", ex);
            }
            finally
            {
                _perBatchLogger.Dispose();
            }
        }

        /// <summary>
        /// The final step to write the log tha the service successully completed
        /// </summary>
        /// <param name="inputParams"></param>
        /// <param name="context"></param>
        //[Queue(JobServiceQueues.JobServiceFinalizeQueue)]
        public void Finalize(CompositionMsg inputParams, PerformContext context)
        {
            var outboundHelper = new OutboundHelper(_appConfig);
            var logMsg = BuildDcsLog(inputParams);

            if (!_perBatchLogger.LogFileCreated)
            {
                _perBatchLogger.CreateForBatchId("per-batch:serilog:", "write-to:File.path", inputParams.BatchId, inputParams.JobPath, _appConfig.Logging.RelativeJobLogFileLocation, _appConfig.Logging.LogFileName);
            }

            try
            {
                var lMessage = $"Processing for batch {inputParams.BatchId} successfully completed.";
                if (context != null)
                {
                    context.LogInformation(lMessage);
                }

                _perBatchLogger.Info($"Processing for batch {inputParams.BatchId} successfully completed.", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, lMessage, null);

                //Logging that the service successfully finished
                outboundHelper.UpdateBatchHistory(inputParams, context, DcsBatchHistoryStatusEnum.CompJobServiceCompleted);
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, inputParams.BatchId, ex.Message, new object[] { });
                throw;
            }
            finally
            {
                _perBatchLogger.Dispose();
            }
        }

        /// <summary>
        /// CSV Processor flow, if processor option trigger ICSVPreprocessor, 
        /// No options but variables ‘Default_CSV_Group’ or ‘Default_CSV_Print_Group’ then copy DRIVER.csv
        /// Otherwise - skip with a log entry
        /// </summary>
        /// <param name="passingParams"></param>
        /// <param name="context"></param>
        /// <param name="logMsg"></param>
        /// <param name="latestJobId"></param>
        /// <returns></returns>
        private string ProcessCsvFlow(CompositionMsg passingParams, PerformContext context, DCSLogMsg logMsg, string latestJobId)
        {
            if (!_perBatchLogger.LogFileCreated)
            {
                _perBatchLogger.CreateForBatchId("per-batch:serilog:", "write-to:File.path", passingParams.BatchId, passingParams.JobPath, _appConfig.Logging.RelativeJobLogFileLocation, _appConfig.Logging.LogFileName);
            }

            var driverFile = "DRIVER.csv";
            var configFileLocation = Path.Combine(passingParams.JobPath,
                        _appConfig.AppSettings.CtlControlFilesFolder, _appConfig.AppSettings.CtlJobOrchestrator);

            try
            {
                if (_fsHelper.ShouldTriggerCsv(configFileLocation))
                {
                    var logEntry = $"Passing parameters to ICSVPreprocessor.Start for batch id = {passingParams.BatchId}";
                    if (context != null)
                    {
                        context.LogInformation(logEntry);
                    }
                    _perBatchLogger.Info($"Passing parameters to ICSVPreprocessor.Start for batch id = {passingParams.BatchId}", new object[] { });
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logEntry, null);
                    latestJobId = BackgroundJob.Enqueue<ICSVPreprocessor>(x => x.Start(passingParams, null));
                }
                else
                {
                    if (_fsHelper.ShouldCopyCsvDriver(configFileLocation))
                    {
                        var logEntry = $"Skipping ICSVPreprocessor. No PREPROCESSOR_OPTIONS but copying DRIVER.csv file to the job fodler for batch id = {passingParams.BatchId}";
                        _perBatchLogger.Info($"Skipping ICSVPreprocessor. No PREPROCESSOR_OPTIONS but copying DRIVER.csv file to the job fodler for batch id = {passingParams.BatchId}", new object[] { });
                        logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logEntry, null);

                        if (string.IsNullOrEmpty(passingParams.CsvFilePathName))
                        {
                            logEntry = $"Skipping DRIVER.csv copy. No CsvFilePathName provided batch id = {passingParams.BatchId}";
                            _perBatchLogger.Error($"Skipping DRIVER.csv copy. No CsvFilePathName provided batch id = {passingParams.BatchId}");
                            logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Error, logEntry, null);
                        }
                        else
                        {
                            //Copy with overwrite
                            File.Copy(passingParams.CsvFilePathName, Path.Combine(passingParams.JobPath, driverFile), true);
                        }
                    }
                    else
                    {
                        var logEntry = $"Skipping ICSVPreprocessor. No PREPROCESSOR_OPTIONS in the control file for batch id = {passingParams.BatchId}";
                        _perBatchLogger.Info($"Skipping ICSVPreprocessor. No PREPROCESSOR_OPTIONS in the control file for batch id = {passingParams.BatchId}", new object[] { });
                        logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, logEntry, null);
                    }
                }
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, passingParams.BatchId, ex.Message, new object[] { });
                throw;
            }
            finally
            {
                _perBatchLogger.Dispose();
            }

            return latestJobId;
        }

        private string ParseCompositionMsgToJsonString(CompositionMsg inputParams)
        {
            return JsonConvert.SerializeObject(inputParams);
        }

        private string CreateBatchFolder(long batchId)
        {
            string newFolder = _fsHelper.CreateFolder(Path.Combine(_appConfig.AppSettings.FolderRootPath, batchId.ToString()));
            //_perBatchLogger.Info($"The batch ({batchId}) folder path is {newFolder}", new object[] { });
            return newFolder;
        }

        private DCSLogMsg BuildDcsLog(CompositionMsg inputParams)
        {
            return new DCSLogMsg
            {
                Application = "DCS.Composition.Services.JobService",
                Server = _appConfig.AppSettings.Server,
                ApplicationVersion = _appConfig.AppSettings.Version.ToString(),
                GSScheduleId = inputParams.GSScheduleId,
                JGScheduleId = inputParams.JGScheduleId,
                JSScheduleId = Guid.NewGuid(),
                DeliveryChannel = inputParams.DeliveryChannel,
                NatDins = string.Join(",", inputParams.NatDins),
                BatchId = inputParams.BatchId,
                LogDatetime = DateTime.Now,
                LogLevel = LogLevel.Information
            };
        }

        public void JobServiceHandleResponse(CompositionMsg message, PerformContext context)
        {
            var _outboundHelper = new OutboundHelper(_appConfig);

            if (!_perBatchLogger.LogFileCreated)
            {
                _perBatchLogger.CreateForBatchId("per-batch:serilog:", "write-to:File.path", message.BatchId, message.JobPath, _appConfig.Logging.RelativeJobLogFileLocation, _appConfig.Logging.LogFileName);
            }
            _perBatchLogger.Info($"Starting Job Service Handle Response for {message}.", null);

            try
            {
                var jobIds = new List<String>();

                _perBatchLogger.Info($"Finding Child Jobs for {message.HandleResponse.HfJobid}.", null);
                jobIds = FindChildren(message.HandleResponse.HfJobid, jobIds);

                foreach (String jobId in jobIds)
                {
                    _perBatchLogger.Info($"Deleting job {jobId}.", null);
                    BackgroundJob.Delete(jobId);
                }

                if (message.HandleResponse.HandleStatus.ToLower() == "completed")
                {
                    _perBatchLogger.Info($"Deleting Parent job {message.HandleResponse.HfJobid}.", null);
                    BackgroundJob.Delete(message.HandleResponse.HfJobid);
                    _outboundHelper.UpdateBatchHistory(message, context, DCS.Shared.DataAccess.Outbound.Enums.DcsBatchHistoryStatusEnum.CompositionCompleted);
                    _perBatchLogger.Info("Finalizing Composition JobService Completed job status stored to DcsBatchHistory.", null);
                }
                else
                {
                    _outboundHelper.UpdateBatchHistory(message, context, DCS.Shared.DataAccess.Outbound.Enums.DcsBatchHistoryStatusEnum.CompositionFailed);
                    _perBatchLogger.Info("Finalizing Composition JobService Failed job status stored to DcsBatchHistory.", null);
                }
            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, ex.Message, null);
                throw;
            }
            finally
            {
                _perBatchLogger.Dispose();
            }
        }
        public List<String> FindChildren(string parentid, List<string> list)
        {
            var api = JobStorage.Current.GetMonitoringApi();

            var properties = api.JobDetails(parentid).Properties;

            if (properties.ContainsKey("Continuations"))
            {
                // if there is still continuatiosn continue.
                var test = properties["Continuations"];
                var regexExpression = "(.*)\"([0-9]+)(.*)";
                var regex = new Regex(regexExpression);
                var match = regex.Match(test);
                var jobid = match.Groups[2].Value;
                list.Add(jobid);
                return FindChildren(jobid, list);

            }
            else
            {
                // no more continuations return
                return list;
            }
        }
    }
}
