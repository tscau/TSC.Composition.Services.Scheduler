﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DCS.Composition.Services.Shared.JobService
{
    public struct ServiceQueues
    {
        public const string JobServiceQueue = "pp_job_service";
        public const string CcsServiceQueue = "pp_ccs";

        public const string JobServiceConfirmationQueue = "pp_job_service_confirmation_queue";
    }
}
