﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using DCS.Composition.Services.Shared.JobService.Contracts;
using Hangfire;
using Hangfire.Server;

namespace DCS.Composition.Services.Shared.JobService
{
    public interface IJobService
    {
        [Queue(ServiceQueues.JobServiceQueue)]
        [JobDisplayName("JobService Start - {0}")]
        [DisplayName("JobService Start - {0}")]
        void Start(PreProcessingInputParams inputParams, PerformContext context);
    }
}
