﻿using DCS.Composition.Services.Shared.JobService.Contracts;
using System;
using System.Collections.Generic;
using System.Text;
using Hangfire;
using Hangfire.Server;
using System.ComponentModel;

namespace DCS.Composition.Services.Shared.JobService
{
    public interface ICommService
    {
        [Queue(ServiceQueues.CcsServiceQueue)]
        [JobDisplayName("CommService RequestCcs - {0}")]
        [DisplayName("CommService RequestCcs - {0}")]
        void RequestCcs(CCSInputParams inputParams, PerformContext context);
    }
}
