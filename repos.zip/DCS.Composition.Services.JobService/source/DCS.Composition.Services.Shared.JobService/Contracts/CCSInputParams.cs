﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DCS.Composition.Services.Shared.JobService.Contracts
{
    public struct CCSInputParams
    {
        public string FolderPath { get; set; }
        public string JobName { get; set; }
        public string PackageDetails { get; set; }
    }
}
