﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DCS.Composition.Services.Shared.JobService.Contracts
{
    public struct PreProcessingInputParams
    {
        public int BatchId { get; set; }
        public List<string> NatDins { get; set; }
        public string StatusCode { get; set; }
        public string FolderPath { get; set; }
        public Guid ScheduleId { get; set; }
    }
}
