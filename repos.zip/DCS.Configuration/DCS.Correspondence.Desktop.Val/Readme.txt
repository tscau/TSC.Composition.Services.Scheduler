Dialogue configs live in $/EST/ICP under specific POWs, e.g. $/EST/ICP/PoW21Q4

DCS have copied the postbuild script to this srep so we  can dynamically control the name of the pacakges generated so they can be dynamically controlled via our builds