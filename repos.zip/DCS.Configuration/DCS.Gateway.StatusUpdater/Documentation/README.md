# Introduction 
This is an empty folder, that environment.config file will be copied to Documentation/Deplopyment when built 

uses
ABDO-Build-ExtractGitBranch task in the build to copy the deployment config at build time