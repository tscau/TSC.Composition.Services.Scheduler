﻿using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.DataRetrieve;
using Hangfire;
using Hangfire.SqlServer;
using Microsoft.Extensions.Configuration;
using System;
using System.Configuration;

namespace DCS.Composition.Services.DataRetreive.IntegrationTests
{
    class Program
    {
        static void Main(string[] args)
        {
            ConfigureHangfire();
            CompositionMsg message = new CompositionMsg();
            //for (int i = 21905; i <= 22905; i++)
            for (int i = 1; i <= 413; i++)
            {
                message.JobPath = @"C:\Temp\jobs\" + i;
                message.NatDins.Add("123.123");
                message.BatchId = i;
                var response = BackgroundJob.Enqueue<IDataRetrieve>(x => x.Start(message, null));
            }

            while (true)
            {
                Run();
            }
        }

        static void ConfigureHangfire()
        {
            IConfiguration config = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", true, true)
                .Build();

            GlobalConfiguration.Configuration.UseSqlServerStorage(ConfigurationManager.ConnectionStrings["Hangfire"].ConnectionString, new SqlServerStorageOptions
            {
                CommandBatchMaxTimeout = TimeSpan.FromMinutes(5),
                SlidingInvisibilityTimeout = TimeSpan.FromMinutes(5),
                QueuePollInterval = TimeSpan.Zero,
                UseRecommendedIsolationLevel = true,
                UsePageLocksOnDequeue = true,
                DisableGlobalLocks = true,
                SchemaName = ConfigurationManager.AppSettings["Workspace"]
            });
        }

        static void Run()
        {

            string message = string.Empty;
            Console.WriteLine("Enter the message to send: batchId|OutputPath|NatDins");
            message = Console.ReadLine();
            var msg = new CompositionMsg();
            var response = BackgroundJob.Enqueue<IDataRetrieve>(x => x.Start(msg, null));
        }
    }
}
