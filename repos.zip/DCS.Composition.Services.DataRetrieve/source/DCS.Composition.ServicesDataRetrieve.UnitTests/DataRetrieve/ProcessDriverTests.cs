﻿using DCS.Composition.Services.DataRetrieve.Config;
using DCS.Logging.Shared.Infrastructure;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Documents;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using Serilog;
using Serilog.Formatting.Compact;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Abstractions.TestingHelpers;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using Xunit;

namespace DCS.Composition.Services.DataRetrieve.UnitTests
{
    public class ProcessDriverTests
    {
        

        [Fact]
        public void ProcessDriver_AddCorresRequestIdWhenNotSuppliedSuccess()
        {
            var mockFileSystem = new MockFileSystem(new Dictionary<string, MockFileData>
            {
                {@"C:\Temp\Jobs\9999\driver.xml", new MockFileData("") },
                {@"C:\Temp\Jobs\9999\data.csv", new MockFileData("") }
            });

            CorresRequestForDataRetrieve corresToProcess = new CorresRequestForDataRetrieve
            {
                CorresId = 1234567891234,
                CorresRequestId = 987654321,
                DPID = "123123123123",
                PassThroughMetadataTxt = "<?xml version=\"1.0\" encoding=\"utf-8\"?><EAIOutboundCorrespondence xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns=\"http://www.ato.gov.au/Subjects/EAI/2005/09/ATOCanonical\"><Control><MessageSourceID>054</MessageSourceID><TAFlags><NonInteractiveIndicator>1</NonInteractiveIndicator></TAFlags><MessageDatetime>2015-02-06T14:55:13+11:00</MessageDatetime><ControlRecordsCount>3</ControlRecordsCount><ControlSequenceNumber>3</ControlSequenceNumber></Control><ClientList><Client><ClientInternalID>1000013640958</ClientInternalID><RoleTypeDecode>CONTACT</RoleTypeDecode><Individual><IndividualDeceasedIndicator>N</IndividualDeceasedIndicator></Individual><ClientIdentifiers><ClientIdentifier><ClientIdentifierTypeCode>5</ClientIdentifierTypeCode><ClientIdentifierValueID>396534354</ClientIdentifierValueID></ClientIdentifier></ClientIdentifiers><ClientNames><ClientName><StructuredName><StructuredGivenName>WAYNE</StructuredGivenName><StructuredOtherGivenName></StructuredOtherGivenName><StructuredFamilyName>PIRES</StructuredFamilyName><IndividualTitleTypeCode>103</IndividualTitleTypeCode></StructuredName><UnstructuredName><UnstructuredFullName>MR SHAKEDOWN TESTING</UnstructuredFullName><UnstructuredNameLine1>MR WAYNE PIRES</UnstructuredNameLine1><UnstructuredNameLine2></UnstructuredNameLine2></UnstructuredName></ClientName></ClientNames><ClientAccount><ClientAccountRole><ClientRole /></ClientAccountRole></ClientAccount><ClientAddresses><ClientAddressSequenceNumber>7</ClientAddressSequenceNumber><AddressTypeCode>5</AddressTypeCode><ClientAddressContactName></ClientAddressContactName><ClientAddressLastUpdatedDate>2010-10-25</ClientAddressLastUpdatedDate><ClientAddressLastUpdatedTime>21:12:36+11:00</ClientAddressLastUpdatedTime><ClntAddrSendFileAccessFrmtCode></ClntAddrSendFileAccessFrmtCode><ClientAddressPrimaryIndicator>Y</ClientAddressPrimaryIndicator><Address><AddressCategoryCode>G</AddressCategoryCode><ChannelCategoryCode>5</ChannelCategoryCode><GeographicAddress><GeographicAddrDeliveryPointID>63742443</GeographicAddrDeliveryPointID><StructuredGeographicAddress><StructrdGeogrphcAddrLocaltyNme>DANDENONG</StructrdGeogrphcAddrLocaltyNme><StructrdGeographicAddrPstcd>3175</StructrdGeographicAddrPstcd><StructrdGeographicAddrStateCd>VIC</StructrdGeographicAddrStateCd><CountryCode>14</CountryCode><CountryDecode></CountryDecode><SemiStructuredGeographicAddr><SemiStructrdGeographicAddrLn1>C/- TASC CONSULTING PTY LTD</SemiStructrdGeographicAddrLn1><SemiStructrdGeographicAddrLn2></SemiStructrdGeographicAddrLn2></SemiStructuredGeographicAddr></StructuredGeographicAddress></GeographicAddress></Address></ClientAddresses><ClientSuppressionList><ClientSuppression><ClientSuppressionReleaseInd>N</ClientSuppressionReleaseInd></ClientSuppression></ClientSuppressionList></Client><Client><ClientInternalID>1000013640958</ClientInternalID><RoleTypeDecode>OFINTEREST</RoleTypeDecode><ClientIdentifiers><ClientIdentifier><ClientIdentifierTypeCode>5</ClientIdentifierTypeCode><ClientIdentifierValueID>396534354</ClientIdentifierValueID></ClientIdentifier></ClientIdentifiers><ClientNames><ClientName><StructuredName><StructuredGivenName>PIRES</StructuredGivenName><StructuredFamilyName>WAYNE</StructuredFamilyName><IndividualTitleTypeCode>103</IndividualTitleTypeCode></StructuredName><UnstructuredName /></ClientName></ClientNames><ClientAccount><ClientAccountRole><ClientRole /></ClientAccountRole></ClientAccount><ClientAddresses><Address><AddressCategoryCode>G</AddressCategoryCode><ChannelCategoryCode>5</ChannelCategoryCode><GeographicAddress><GeographicAddrDeliveryPointID>63742443</GeographicAddrDeliveryPointID><StructuredGeographicAddress><StructrdGeogrphcAddrLocaltyNme>DANDENONG</StructrdGeogrphcAddrLocaltyNme><StructrdGeographicAddrPstcd>3175</StructrdGeographicAddrPstcd><StructrdGeographicAddrStateCd>VIC</StructrdGeographicAddrStateCd><CountryCode>14</CountryCode><CountryDecode></CountryDecode><SemiStructuredGeographicAddr><SemiStructrdGeographicAddrLn1>C/- TASC CONSULTING PTY LTD</SemiStructrdGeographicAddrLn1><SemiStructrdGeographicAddrLn2></SemiStructrdGeographicAddrLn2></SemiStructuredGeographicAddr></StructuredGeographicAddress></GeographicAddress></Address></ClientAddresses></Client><Client><ClientInternalID>1000013640958</ClientInternalID><RoleTypeDecode>CORRESPONDENT</RoleTypeDecode><ClientIdentifiers><ClientIdentifier><ClientIdentifierTypeCode>5</ClientIdentifierTypeCode><ClientIdentifierValueID>396534354</ClientIdentifierValueID></ClientIdentifier></ClientIdentifiers><ClientNames><ClientName><StructuredName><StructuredGivenName>PIRES</StructuredGivenName><StructuredFamilyName>WAYNE</StructuredFamilyName></StructuredName><UnstructuredName /></ClientName></ClientNames><ClientAccount><ClientAccountRole><ClientRole /></ClientAccountRole></ClientAccount><ClientAddresses><Address><ElectronicAddress><InternetAddress><EmailAddressType /></InternetAddress><TelephoneAddress /></ElectronicAddress><GeographicAddress><StructuredGeographicAddress><SemiStructuredGeographicAddr /></StructuredGeographicAddress></GeographicAddress></Address></ClientAddresses></Client></ClientList><InteractionActivity><ActivityTypes><BusinessEventReceiptID>4013061544764</BusinessEventReceiptID><TaxOfficeCapabilityName>Debt and Lodgment</TaxOfficeCapabilityName><ActivityContactCategoryName>TPALS</ActivityContactCategoryName><ActivityContactTypeName>Lodgment Requested</ActivityContactTypeName></ActivityTypes></InteractionActivity><CorrespondenceTemplate><OutboundCorrespondenceTmpltID>70571.368595</OutboundCorrespondenceTmpltID></CorrespondenceTemplate><Context><PassThroughData><![CDATA[   <OPM><Client><ClientResidentIndicator>N</ClientResidentIndicator><TotalBalanceAmount>0</TotalBalanceAmount></Client><Assessment><AccountPeriodAccountingYear>2016</AccountPeriodAccountingYear></Assessment></OPM>]]></PassThroughData></Context></EAIOutboundCorrespondence>",
                RUCExceptionCd = 1
            };

            int numFound = Regex.Matches(corresToProcess.PassThroughMetadataTxt, "<CorresRequestId>987654321</CorresRequestId>").Count;
            Assert.Equal<int>(0, numFound);

            var mockAppConfig = new Mock<IAppConfig>();
            mockAppConfig.Setup(x => x.Logging.LogServiceUrl).Returns(string.Empty);
            mockAppConfig.Setup(x => x.AppSettings.FlushDataToFilesBatchSize).Returns(1000);
            mockAppConfig.Setup(x => x.AppSettings.CustomersNamespace).Returns("http://www.ato.gov.au/Subjects/EAI/2005/09/ATOCanonical");

            var mockDbContext = new Mock<IOutbound>();
            mockDbContext.Setup(x => x.GetCorresRequestsDetailsForDataRetrieve(It.IsAny<long>())).Returns(corresToProcess);

            var mockPerBatchLogger = new Mock<IPerBatchLogger>();

            Common.DataRetrieve dr = new Common.DataRetrieve(mockPerBatchLogger.Object, mockFileSystem, mockDbContext.Object, mockAppConfig.Object);
            StringBuilder driverBuilder = new StringBuilder();
            StringBuilder csvBuilder = new StringBuilder();
            List<long> corresList = new List<long>() { 4013061544764 };
            string driverOutputFile = @"C:\Temp\Jobs\9999\driver.xml";
            string dataOutputFile = @"C:\Temp\Jobs\9999\data.csv";

            long numberProcessed = dr.ProcessDriver(driverOutputFile, dataOutputFile, 9999, driverBuilder, csvBuilder, corresList);
            Assert.Equal<long>(1, numberProcessed);


            string fileContentsAfter = mockFileSystem.GetFile(@"C:\Temp\Jobs\9999\driver.xml").TextContents;
            numFound = Regex.Matches(fileContentsAfter, "<CorresRequestId>987654321</CorresRequestId>").Count;
            Assert.Equal<int>(1, numFound);


        }

        [Fact]
        public void ProcessDriver_AddCorresRequestIdWhenSuppliedSuccess()
        {

            var mockFileSystem = new MockFileSystem(new Dictionary<string, MockFileData>
            {
                {@"C:\Temp\Jobs\9999\driver.xml", new MockFileData("") },
                {@"C:\Temp\Jobs\9999\data.csv", new MockFileData("") }
            });

            CorresRequestForDataRetrieve corresToProcess = new CorresRequestForDataRetrieve
            {
                CorresId = 1234567891234,
                CorresRequestId = 987654321,
                DPID = "123123123123",
                PassThroughMetadataTxt = "<?xml version=\"1.0\" encoding=\"utf-8\"?><EAIOutboundCorrespondence xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns=\"http://www.ato.gov.au/Subjects/EAI/2005/09/ATOCanonical\"><Control><MessageSourceID>054</MessageSourceID><TAFlags><NonInteractiveIndicator>1</NonInteractiveIndicator></TAFlags><MessageDatetime>2015-02-06T14:55:13+11:00</MessageDatetime><ControlRecordsCount>3</ControlRecordsCount><ControlSequenceNumber>3</ControlSequenceNumber></Control><ClientList><Client><ClientInternalID>1000013640958</ClientInternalID><RoleTypeDecode>CONTACT</RoleTypeDecode><Individual><IndividualDeceasedIndicator>N</IndividualDeceasedIndicator></Individual><ClientIdentifiers><ClientIdentifier><ClientIdentifierTypeCode>5</ClientIdentifierTypeCode><ClientIdentifierValueID>396534354</ClientIdentifierValueID></ClientIdentifier></ClientIdentifiers><ClientNames><ClientName><StructuredName><StructuredGivenName>WAYNE</StructuredGivenName><StructuredOtherGivenName></StructuredOtherGivenName><StructuredFamilyName>PIRES</StructuredFamilyName><IndividualTitleTypeCode>103</IndividualTitleTypeCode></StructuredName><UnstructuredName><UnstructuredFullName>MR SHAKEDOWN TESTING</UnstructuredFullName><UnstructuredNameLine1>MR WAYNE PIRES</UnstructuredNameLine1><UnstructuredNameLine2></UnstructuredNameLine2></UnstructuredName></ClientName></ClientNames><ClientAccount><ClientAccountRole><ClientRole /></ClientAccountRole></ClientAccount><ClientAddresses><ClientAddressSequenceNumber>7</ClientAddressSequenceNumber><AddressTypeCode>5</AddressTypeCode><ClientAddressContactName></ClientAddressContactName><ClientAddressLastUpdatedDate>2010-10-25</ClientAddressLastUpdatedDate><ClientAddressLastUpdatedTime>21:12:36+11:00</ClientAddressLastUpdatedTime><ClntAddrSendFileAccessFrmtCode></ClntAddrSendFileAccessFrmtCode><ClientAddressPrimaryIndicator>Y</ClientAddressPrimaryIndicator><Address><AddressCategoryCode>G</AddressCategoryCode><ChannelCategoryCode>5</ChannelCategoryCode><GeographicAddress><GeographicAddrDeliveryPointID>63742443</GeographicAddrDeliveryPointID><StructuredGeographicAddress><StructrdGeogrphcAddrLocaltyNme>DANDENONG</StructrdGeogrphcAddrLocaltyNme><StructrdGeographicAddrPstcd>3175</StructrdGeographicAddrPstcd><StructrdGeographicAddrStateCd>VIC</StructrdGeographicAddrStateCd><CountryCode>14</CountryCode><CountryDecode></CountryDecode><SemiStructuredGeographicAddr><SemiStructrdGeographicAddrLn1>C/- TASC CONSULTING PTY LTD</SemiStructrdGeographicAddrLn1><SemiStructrdGeographicAddrLn2></SemiStructrdGeographicAddrLn2></SemiStructuredGeographicAddr></StructuredGeographicAddress></GeographicAddress></Address></ClientAddresses><ClientSuppressionList><ClientSuppression><ClientSuppressionReleaseInd>N</ClientSuppressionReleaseInd></ClientSuppression></ClientSuppressionList></Client><Client><ClientInternalID>1000013640958</ClientInternalID><RoleTypeDecode>OFINTEREST</RoleTypeDecode><ClientIdentifiers><ClientIdentifier><ClientIdentifierTypeCode>5</ClientIdentifierTypeCode><ClientIdentifierValueID>396534354</ClientIdentifierValueID></ClientIdentifier></ClientIdentifiers><ClientNames><ClientName><StructuredName><StructuredGivenName>PIRES</StructuredGivenName><StructuredFamilyName>WAYNE</StructuredFamilyName><IndividualTitleTypeCode>103</IndividualTitleTypeCode></StructuredName><UnstructuredName /></ClientName></ClientNames><ClientAccount><ClientAccountRole><ClientRole /></ClientAccountRole></ClientAccount><ClientAddresses><Address><AddressCategoryCode>G</AddressCategoryCode><ChannelCategoryCode>5</ChannelCategoryCode><GeographicAddress><GeographicAddrDeliveryPointID>63742443</GeographicAddrDeliveryPointID><StructuredGeographicAddress><StructrdGeogrphcAddrLocaltyNme>DANDENONG</StructrdGeogrphcAddrLocaltyNme><StructrdGeographicAddrPstcd>3175</StructrdGeographicAddrPstcd><StructrdGeographicAddrStateCd>VIC</StructrdGeographicAddrStateCd><CountryCode>14</CountryCode><CountryDecode></CountryDecode><SemiStructuredGeographicAddr><SemiStructrdGeographicAddrLn1>C/- TASC CONSULTING PTY LTD</SemiStructrdGeographicAddrLn1><SemiStructrdGeographicAddrLn2></SemiStructrdGeographicAddrLn2></SemiStructuredGeographicAddr></StructuredGeographicAddress></GeographicAddress></Address></ClientAddresses></Client><Client><ClientInternalID>1000013640958</ClientInternalID><RoleTypeDecode>CORRESPONDENT</RoleTypeDecode><ClientIdentifiers><ClientIdentifier><ClientIdentifierTypeCode>5</ClientIdentifierTypeCode><ClientIdentifierValueID>396534354</ClientIdentifierValueID></ClientIdentifier></ClientIdentifiers><ClientNames><ClientName><StructuredName><StructuredGivenName>PIRES</StructuredGivenName><StructuredFamilyName>WAYNE</StructuredFamilyName></StructuredName><UnstructuredName /></ClientName></ClientNames><ClientAccount><ClientAccountRole><ClientRole /></ClientAccountRole></ClientAccount><ClientAddresses><Address><ElectronicAddress><InternetAddress><EmailAddressType /></InternetAddress><TelephoneAddress /></ElectronicAddress><GeographicAddress><StructuredGeographicAddress><SemiStructuredGeographicAddr /></StructuredGeographicAddress></GeographicAddress></Address></ClientAddresses></Client></ClientList><InteractionActivity><ActivityTypes><BusinessEventReceiptID>4013061544764</BusinessEventReceiptID><TaxOfficeCapabilityName>Debt and Lodgment</TaxOfficeCapabilityName><ActivityContactCategoryName>TPALS</ActivityContactCategoryName><ActivityContactTypeName>Lodgment Requested</ActivityContactTypeName><CorresRequestId>987654321</CorresRequestId></ActivityTypes></InteractionActivity><CorrespondenceTemplate><OutboundCorrespondenceTmpltID>70571.368595</OutboundCorrespondenceTmpltID></CorrespondenceTemplate><Context><PassThroughData><![CDATA[   <OPM><Client><ClientResidentIndicator>N</ClientResidentIndicator><TotalBalanceAmount>0</TotalBalanceAmount></Client><Assessment><AccountPeriodAccountingYear>2016</AccountPeriodAccountingYear></Assessment></OPM>]]></PassThroughData></Context></EAIOutboundCorrespondence>",
                RUCExceptionCd = 1
            };

            int numFound = Regex.Matches(corresToProcess.PassThroughMetadataTxt, "<CorresRequestId>987654321</CorresRequestId>").Count;
            Assert.Equal<int>(1, numFound);

            var mockAppConfig = new Mock<IAppConfig>();
            mockAppConfig.Setup(x => x.Logging.LogServiceUrl).Returns(string.Empty);
            mockAppConfig.Setup(x => x.AppSettings.FlushDataToFilesBatchSize).Returns(1000);
            mockAppConfig.Setup(x => x.AppSettings.CustomersNamespace).Returns("http://www.ato.gov.au/Subjects/EAI/2005/09/ATOCanonical");

            var mockDbContext = new Mock<IOutbound>();
            mockDbContext.Setup(x => x.GetCorresRequestsDetailsForDataRetrieve(It.IsAny<long>())).Returns(corresToProcess);

            var mockPerBatchLogger = new Mock<IPerBatchLogger>();

            Common.DataRetrieve dr = new Common.DataRetrieve(mockPerBatchLogger.Object, mockFileSystem, mockDbContext.Object, mockAppConfig.Object);
            StringBuilder driverBuilder = new StringBuilder();
            StringBuilder csvBuilder = new StringBuilder();
            List<long> corresList = new List<long>() { 4013061544764 };
            string driverOutputFile = @"C:\Temp\Jobs\9999\driver.xml";
            string dataOutputFile = @"C:\Temp\Jobs\9999\data.csv";

            long numberProcessed = dr.ProcessDriver(driverOutputFile, dataOutputFile, 9999, driverBuilder, csvBuilder, corresList);
            Assert.Equal<long>(1, numberProcessed);


            string fileContentsAfter = mockFileSystem.GetFile(@"C:\Temp\Jobs\9999\driver.xml").TextContents;
            numFound = Regex.Matches(fileContentsAfter, "<CorresRequestId>987654321</CorresRequestId>").Count;
            Assert.Equal<int>(1, numFound);


        }

        [Fact]
        public void ProcessDriver_AddCorresRequestIdWhenSupplied_UnescapedXmlCharsInPassThrough()
        {
            var mockFileSystem = new MockFileSystem(new Dictionary<string, MockFileData>
            {
                {@"C:\Temp\Jobs\9999\driver.xml", new MockFileData("") },
                {@"C:\Temp\Jobs\9999\data.csv", new MockFileData("") }
            });

            CorresRequestForDataRetrieve corresToProcess = new CorresRequestForDataRetrieve
            {
                CorresId = 1234567891234,
                CorresRequestId = 987654321,
                DPID = "123123123123",
                PassThroughMetadataTxt = "<?xml version=\"1.0\" encoding=\"utf-8\"?><EAIOutboundCorrespondence xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns=\"http://www.ato.gov.au/Subjects/EAI/2005/09/ATOCanonical\"><Control><MessageSourceID>054</MessageSourceID><TAFlags><NonInteractiveIndicator>1</NonInteractiveIndicator></TAFlags><MessageDatetime>2015-02-06T14:55:13+11:00</MessageDatetime><ControlRecordsCount>3</ControlRecordsCount><ControlSequenceNumber>3</ControlSequenceNumber></Control><ClientList><Client><ClientInternalID>1000013640958</ClientInternalID><RoleTypeDecode>CONTACT</RoleTypeDecode><Individual><IndividualDeceasedIndicator>N</IndividualDeceasedIndicator></Individual><ClientIdentifiers><ClientIdentifier><ClientIdentifierTypeCode>5</ClientIdentifierTypeCode><ClientIdentifierValueID>396534354</ClientIdentifierValueID></ClientIdentifier></ClientIdentifiers><ClientNames><ClientName><StructuredName><StructuredGivenName>WAYNE</StructuredGivenName><StructuredOtherGivenName></StructuredOtherGivenName><StructuredFamilyName>PIRES</StructuredFamilyName><IndividualTitleTypeCode>103</IndividualTitleTypeCode></StructuredName><UnstructuredName><UnstructuredFullName>MR SHAKEDOWN TESTING</UnstructuredFullName><UnstructuredNameLine1>MR WAYNE PIRES</UnstructuredNameLine1><UnstructuredNameLine2></UnstructuredNameLine2></UnstructuredName></ClientName></ClientNames><ClientAccount><ClientAccountRole><ClientRole /></ClientAccountRole></ClientAccount><ClientAddresses><ClientAddressSequenceNumber>7</ClientAddressSequenceNumber><AddressTypeCode>5</AddressTypeCode><ClientAddressContactName></ClientAddressContactName><ClientAddressLastUpdatedDate>2010-10-25</ClientAddressLastUpdatedDate><ClientAddressLastUpdatedTime>21:12:36+11:00</ClientAddressLastUpdatedTime><ClntAddrSendFileAccessFrmtCode></ClntAddrSendFileAccessFrmtCode><ClientAddressPrimaryIndicator>Y</ClientAddressPrimaryIndicator><Address><AddressCategoryCode>G</AddressCategoryCode><ChannelCategoryCode>5</ChannelCategoryCode><GeographicAddress><GeographicAddrDeliveryPointID>63742443</GeographicAddrDeliveryPointID><StructuredGeographicAddress><StructrdGeogrphcAddrLocaltyNme>DANDENONG</StructrdGeogrphcAddrLocaltyNme><StructrdGeographicAddrPstcd>3175</StructrdGeographicAddrPstcd><StructrdGeographicAddrStateCd>VIC</StructrdGeographicAddrStateCd><CountryCode>14</CountryCode><CountryDecode></CountryDecode><SemiStructuredGeographicAddr><SemiStructrdGeographicAddrLn1>C/- TASC CONSULTING PTY LTD</SemiStructrdGeographicAddrLn1><SemiStructrdGeographicAddrLn2></SemiStructrdGeographicAddrLn2></SemiStructuredGeographicAddr></StructuredGeographicAddress></GeographicAddress></Address></ClientAddresses><ClientSuppressionList><ClientSuppression><ClientSuppressionReleaseInd>N</ClientSuppressionReleaseInd></ClientSuppression></ClientSuppressionList></Client><Client><ClientInternalID>1000013640958</ClientInternalID><RoleTypeDecode>OFINTEREST</RoleTypeDecode><ClientIdentifiers><ClientIdentifier><ClientIdentifierTypeCode>5</ClientIdentifierTypeCode><ClientIdentifierValueID>396534354</ClientIdentifierValueID></ClientIdentifier></ClientIdentifiers><ClientNames><ClientName><StructuredName><StructuredGivenName>PIRES</StructuredGivenName><StructuredFamilyName>WAYNE</StructuredFamilyName><IndividualTitleTypeCode>103</IndividualTitleTypeCode></StructuredName><UnstructuredName /></ClientName></ClientNames><ClientAccount><ClientAccountRole><ClientRole /></ClientAccountRole></ClientAccount><ClientAddresses><Address><AddressCategoryCode>G</AddressCategoryCode><ChannelCategoryCode>5</ChannelCategoryCode><GeographicAddress><GeographicAddrDeliveryPointID>63742443</GeographicAddrDeliveryPointID><StructuredGeographicAddress><StructrdGeogrphcAddrLocaltyNme>DANDENONG</StructrdGeogrphcAddrLocaltyNme><StructrdGeographicAddrPstcd>3175</StructrdGeographicAddrPstcd><StructrdGeographicAddrStateCd>VIC</StructrdGeographicAddrStateCd><CountryCode>14</CountryCode><CountryDecode></CountryDecode><SemiStructuredGeographicAddr><SemiStructrdGeographicAddrLn1>C/- TASC CONSULTING PTY LTD</SemiStructrdGeographicAddrLn1><SemiStructrdGeographicAddrLn2></SemiStructrdGeographicAddrLn2></SemiStructuredGeographicAddr></StructuredGeographicAddress></GeographicAddress></Address></ClientAddresses></Client><Client><ClientInternalID>1000013640958</ClientInternalID><RoleTypeDecode>CORRESPONDENT</RoleTypeDecode><ClientIdentifiers><ClientIdentifier><ClientIdentifierTypeCode>5</ClientIdentifierTypeCode><ClientIdentifierValueID>396534354</ClientIdentifierValueID></ClientIdentifier></ClientIdentifiers><ClientNames><ClientName><StructuredName><StructuredGivenName>PIRES</StructuredGivenName><StructuredFamilyName>WAYNE</StructuredFamilyName></StructuredName><UnstructuredName /></ClientName></ClientNames><ClientAccount><ClientAccountRole><ClientRole /></ClientAccountRole></ClientAccount><ClientAddresses><Address><ElectronicAddress><InternetAddress><EmailAddressType /></InternetAddress><TelephoneAddress /></ElectronicAddress><GeographicAddress><StructuredGeographicAddress><SemiStructuredGeographicAddr /></StructuredGeographicAddress></GeographicAddress></Address></ClientAddresses></Client></ClientList><InteractionActivity><ActivityTypes><BusinessEventReceiptID>4013061544764</BusinessEventReceiptID><TaxOfficeCapabilityName>Debt and Lodgment</TaxOfficeCapabilityName><ActivityContactCategoryName>TPALS</ActivityContactCategoryName><ActivityContactTypeName>Lodgment Requested</ActivityContactTypeName><CorresRequestId>987654321</CorresRequestId></ActivityTypes></InteractionActivity><CorrespondenceTemplate><OutboundCorrespondenceTmpltID>70571.368595</OutboundCorrespondenceTmpltID></CorrespondenceTemplate><Context><PassThroughData><![CDATA[   <OPM><Client><ClientResidentIndicator>N</ClientResidentIndicator><TotalBalanceAmount>0</TotalBalanceAmount></Client><Assessment><AccountPeriodAccountingYear>2016&</AccountPeriodAccountingYear></Assessment></OPM>]]></PassThroughData></Context></EAIOutboundCorrespondence>",
                RUCExceptionCd = 1
            };

            int numFound = Regex.Matches(corresToProcess.PassThroughMetadataTxt, "<CorresRequestId>987654321</CorresRequestId>").Count;
            Assert.Equal<int>(1, numFound);

            var mockAppConfig = new Mock<IAppConfig>();
            mockAppConfig.Setup(x => x.Logging.LogServiceUrl).Returns(string.Empty);
            mockAppConfig.Setup(x => x.AppSettings.FlushDataToFilesBatchSize).Returns(1000);
            mockAppConfig.Setup(x => x.AppSettings.CustomersNamespace).Returns("http://www.ato.gov.au/Subjects/EAI/2005/09/ATOCanonical");

            var mockDbContext = new Mock<IOutbound>();
            mockDbContext.Setup(x => x.GetCorresRequestsDetailsForDataRetrieve(It.IsAny<long>())).Returns(corresToProcess);

            var mockPerBatchLogger = new Mock<IPerBatchLogger>();
            Common.DataRetrieve dr = new Common.DataRetrieve(mockPerBatchLogger.Object, mockFileSystem, mockDbContext.Object, mockAppConfig.Object);
            StringBuilder driverBuilder = new StringBuilder();
            StringBuilder csvBuilder = new StringBuilder();
            List<long> corresList = new List<long>() { 4013061544764 };
            string driverOutputFile = @"C:\Temp\Jobs\9999\driver.xml";
            string dataOutputFile = @"C:\Temp\Jobs\9999\data.csv";

            long numberProcessed = dr.ProcessDriver(driverOutputFile, dataOutputFile, 9999, driverBuilder, csvBuilder, corresList);
            Assert.Equal<long>(1, numberProcessed);


            string fileContentsAfter = mockFileSystem.GetFile(@"C:\Temp\Jobs\9999\driver.xml").TextContents;
            numFound = Regex.Matches(fileContentsAfter, "<CorresRequestId>987654321</CorresRequestId>").Count;
            Assert.Equal<int>(1, numFound);


        }
    }
}
