﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Text;

namespace DCS.Composition.Services.DataRetrieve.Common
{
    /// <summary>
    /// 
    /// </summary>
    public static class RegexHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <param name="RegexPattern"></param>
        /// <param name="groupName"></param>
        /// <param name="replacement"></param>
        /// <param name="RegexOptions"></param>
        /// <returns></returns>
        public static string ReplaceGroup(this string input, string RegexPattern, string groupName, string replacement, RegexOptions RegexOptions = RegexOptions.None)
        {
            var regex = new Regex(RegexPattern, RegexOptions);
            return regex.Replace(input, m =>
            {
                return ReplaceNamedGroup(input, groupName, replacement, m);
            });
        }

        private static string ReplaceNamedGroup(string input, string groupName, string replacement, Match m)
        {
            var capt = m.Groups[groupName].Captures.OfType<Capture>().FirstOrDefault();
            if (capt == null) return m.Value;

            var sb = new StringBuilder(m.Value);
            sb.Remove(m.Groups[groupName].Index - m.Index, m.Groups[groupName].Length);
            sb.Insert(m.Groups[groupName].Index - m.Index, replacement);
            return sb.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        /// <param name="RegexPattern"></param>
        /// <param name="RegexOptions"></param>
        /// <returns></returns>
        public static bool ContainsRegex(this string input, string RegexPattern, RegexOptions RegexOptions = RegexOptions.None)
        {
            var match = Regex.Match(input, RegexPattern, RegexOptions);

            return match.Success;
        }

    }
}
