﻿using DCS.Composition.Services.DataRetrieve.Config;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.DataRetrieve;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Database;
using DCS.Shared.DataAccess.Outbound.Documents;
using DCS.Shared.DataAccess.Outbound.Enums;
using DCS.Logging.Shared.Common;
using Hangfire.JobsLogger;
using Hangfire.Server;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Formatting.Compact;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Abstractions;
using System.Reflection;
using System.Text.Json;
using DCS.Logging.Shared.Infrastructure;

namespace DCS.Composition.Services.DataRetrieve.Common
{
    /// <summary>
    /// Implementation of the IDataRetrieve interface.
    /// </summary>
    public class DataRetrieveImplementation : IDataRetrieve
    {
        readonly IPerBatchLogger _perBatchLogger;
        private readonly IFileSystem _fileSystem;

        readonly List<string> cachedTemplatesConfig = new List<string>();
        readonly IAppConfig _appConfig;


        /// <summary>
        /// Constructor that sets up the initial object
        /// </summary>
        /// <remarks>
        /// The following objects are created/managed in this constructor:
        ///   The configuration is read from the appsettings.json file
        ///   The Serilog Event Log logger is set up to write overall service messages to the event log
        ///   Reads the tempaltes.config file and stores in a cached object. This cached object will be re-loaded based on a config value, and can also be reloaded from a message sent from HangFire
        ///     OpMode=ReloadTemplatesConfig
        ///     OpMode=ReloadConfig
        /// </remarks>
        public DataRetrieveImplementation(IPerBatchLogger perBatchLogger, IAppConfig appConfig)
        {
            _perBatchLogger = perBatchLogger;
            _appConfig = appConfig;

            //Load the templatesconfig file

            using (StreamReader reader = new StreamReader(_appConfig.AppSettings.TemplatesConfigPath))
            {
                //If any Nat/Cds to be processed are in the templates.config file then they follow the old driver way
                while (reader.Peek() >= 0)
                {
                    string strNatCd = reader.ReadLine().Trim();
                    cachedTemplatesConfig.Add(strNatCd);

                }
            }
            _fileSystem = new FileSystem();
        }


        /// <summary>
        /// Method to start the DataRetreive process in response to a message received from HangFire on the dataretrieve_read_queue
        /// </summary>
        /// <param name="message">The message to process. For DataRetreive this is composed of:
        ///   BatchId
        ///   Output Folder Path
        ///   Comma seperate list of NatDins to be processed
        /// </param>
        /// <param name="context">The HJangFire context passed to the method by Hangfire</param>
        /// <remarks>
        /// This methid will write to the Application Event Log when an Exception occurs. This will be sent back to HangFire as a failed job, which will then be managed by the orchestrator
        /// It will also write to a log file in the specified Job folder
        /// </remarks>
        public void Start(CompositionMsg message, PerformContext context)
        {
            DoDataRetrieve(message, context);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="context"></param>
        private void DoDataRetrieve(CompositionMsg message, PerformContext context)
        {
            DCSLogMsg logMsg = new DCSLogMsg
            {
                Application = "DCS.Composition.Services.DataRetrieve",
                Server = _appConfig.AppSettings.Server,
                ApplicationVersion = _appConfig.AppSettings.Versions[Assembly.GetExecutingAssembly().GetName().Name].ToString(),
                GSScheduleId = message.GSScheduleId,
                JGScheduleId = message.JGScheduleId,
                DeliveryChannel = message.DeliveryChannel,
                NatDins = string.Join(",", message.NatDins),
                BatchId = message.BatchId,
                LogDatetime = DateTime.Now,
                LogLevel = LogLevel.Information
            };
            string messageAsJson = JsonSerializer.Serialize(message);

            IOutbound db = new DbContext(() => new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen));

            if (!_perBatchLogger.LogFileCreated)
            {
                _perBatchLogger.CreateForBatchId("per-batch:serilog:", "write-to:File.path", message.BatchId, message.JobPath, _appConfig.Logging.RelativeJobLogFileLocation, _appConfig.Logging.LogFileName);
            }

            try
            {
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{_appConfig.AppSettings.Server} - Processing {messageAsJson}", null);
                context.LogInformation($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Processing {messageAsJson}");
                // Check appConfig for debug info - in case we want to dump the message 
                _perBatchLogger.Info($"Assembly Version = {_appConfig.AppSettings.Versions[Assembly.GetExecutingAssembly().GetName().Name]}", new object[] { });
                _perBatchLogger.Info($"Processing = {messageAsJson}", new object[] { });


                UpdateBatchHistory(message, context, db, DcsBatchHistoryStatusEnum.CompDataRetrieveServiceStarted);

                DataRetrieve dr = new DataRetrieve(_perBatchLogger, _fileSystem, null, _appConfig);

                // Process the data
                bool wrapDriverWithCustomerTag = true;
                foreach (string natCd in message.NatDins)
                {
                    if (cachedTemplatesConfig.Contains(natCd))
                    {
                        wrapDriverWithCustomerTag = false;
                    }
                }

                dr.ExecuteDataRetrieve(message, wrapDriverWithCustomerTag);

                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{_appConfig.AppSettings.Server} - Finished processing {messageAsJson} - Success", null);
                _perBatchLogger.Info($"Finished processing {messageAsJson} - Success", new object[] { });
                context.LogInformation($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - Finished processing {messageAsJson} - Success");

                UpdateBatchHistory(message, context, db, DcsBatchHistoryStatusEnum.CompDataRetrieveServiceCompleted);

            }
            catch (Exception ex)
            {
                AppLog.Error()(ex, message.BatchId, $"Exception in Start for  {messageAsJson} - {ex.Message}; {ex.StackTrace}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Error, $"{_appConfig.AppSettings.Server} - Exception in Start for  {messageAsJson} - {ex.Message}; {ex.StackTrace}", ex);
                context.LogError($"{DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} - {_appConfig.AppSettings.Server} - {_appConfig.AppSettings.Server} - Exception in Start for  {messageAsJson} - {ex.Message}; {ex.StackTrace}");
                _perBatchLogger.Error(ex, $"Exception in Start for  {messageAsJson} - {ex.Message}; {ex.StackTrace}", new object[] { });

                UpdateBatchHistory(message, context, db, DcsBatchHistoryStatusEnum.CompDataRetrieveServiceFailed);

                throw;
            }
            finally
            {
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{_appConfig.AppSettings.Server} - Finished processing {messageAsJson}", null);
                _perBatchLogger.Info($"{_appConfig.AppSettings.Server} - Finished processing {messageAsJson}", new object[] { });
                _perBatchLogger.Dispose();
            }
        }

        private void UpdateBatchHistory(CompositionMsg message, PerformContext context, IOutbound db, DcsBatchHistoryStatusEnum statusToRecord)
        {
            DcsBatchHistory recordToAdd;

            recordToAdd = new DcsBatchHistory
            {
                BatchId = message.BatchId,
                CreatedDt = DateTime.Now,
                CreatedId = _appConfig.AppSettings.UserToRecordAgainst,
                GSScheduleId = message.GSScheduleId
            };
            long.TryParse(context.BackgroundJob.Id, out long temp);
            recordToAdd.HangfireJobId = temp;
            recordToAdd.JSScheduleId = message.JGScheduleId;
            recordToAdd.NewStatusId = (int)statusToRecord;
            recordToAdd.UpdateMsgTxt = "Created by DataRetrieve";

            db.AddDcsBatchHistory(recordToAdd);
        }

    }
}
