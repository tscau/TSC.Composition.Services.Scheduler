﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Reflection;
using System.Text;

namespace DCS.Composition.Services.DataRetrieve.Common
{
    /// <summary>
    /// Helper class to assist with getting config entries from an app,config file
    /// </summary>
    public class _AppConfig
    {
        private const int DEFAULT_FLUSHDATABATCHSIZE = 1000;

        public AppSettings AppSettingsSection { get; set; }
        public LoggingSettings LoggingSettingsSection { get; set; }
        public KestrelSettings KestrelSettingsSection { get; set; }

        public ConnectionStrings ConnectionStringsSection { get; set; }

        public _AppConfig()
        {
            AppSettingsSection = new AppSettings();
            LoggingSettingsSection = new LoggingSettings();
            KestrelSettingsSection = new KestrelSettings();
            ConnectionStringsSection = new ConnectionStrings();
        }

        /// <summary>
        /// COntaisn the appSettings section from the config file. Since we are using app.config and not the preferred apsetttings.json we are trying to make it look like IOptions
        /// like an IOptions section
        /// </summary>
        public class AppSettings
        {
            public string Env
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("Env");
                }
            }
            public int FlushDataToFilesBatchSize
            {
                get
                {
                    int.TryParse(ConfigurationManager.AppSettings.Get("FlushDataToFilesBatchSize"), out int flushDataToFilesBatchSize);
                    if (flushDataToFilesBatchSize == 0)
                    {
                        flushDataToFilesBatchSize = DEFAULT_FLUSHDATABATCHSIZE;
                    }

                    return flushDataToFilesBatchSize;
                }
            }

            /// <summary>
            /// The CustomerNamespace to use for the newer driver files
            /// </summary>
            public string CustomersNamespace => ConfigurationManager.AppSettings.Get("CustomersNamespace");

            /// <summary>
            /// Location of the tempaltes.config file. The Nat/Dins specified in this file will NOT have a Customers tag around the final driver XML
            /// </summary>
            public string TemplatesConfigPath => ConfigurationManager.AppSettings.Get("TemplatesConfigPath");

            /// <summary>
            /// Locatiojn of the service log file
            /// </summary>
            public string RelativeJobLogFileLocation => ConfigurationManager.AppSettings.Get("RelativeJobLogFileLocation");

            /// <summary>
            /// Base name for the driver
            /// </summary>
            public string DriverFileName => ConfigurationManager.AppSettings.Get("DriverFileName");

            /// <summary>
            /// Base name for th4e data.csv file
            /// </summary>
            public string DataFileName => ConfigurationManager.AppSettings.Get("DataFileName");

            public int HangfireWorkerCount
            {
                get
                {
                    int.TryParse(ConfigurationManager.AppSettings.Get("HangfireWorkerCount"), out int hangfireWorkerCount);
                    if (hangfireWorkerCount == 0)
                    {
                        hangfireWorkerCount = 10;
                    }

                    return hangfireWorkerCount;
                }
            }
            public string UserToRecordAgainst
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("UserToRecordAgainst");
                }
            }
            /// <summary>
            /// Returns the version of the application
            /// </summary>
            public Version Version => Assembly.GetExecutingAssembly().GetName().Version;

            /// <summary>
            /// Returns the name of the server that is currently executing the code
            /// </summary>
            public string Server => Environment.MachineName;

        }

        public class LoggingSettings
        {
            public string EventLogServiceName
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("EventLogServiceName");
                }
            }
            public string LogFilePath
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("LogFilePath");
                }
            }

            public LogLevel MinimumLevel
            {
                get
                {
                    LogLevel tempLevel = LogLevel.Information;
                    string minLevel = ConfigurationManager.AppSettings.Get("MinimumLevel");
                    if (!string.IsNullOrWhiteSpace(minLevel))
                    {
                        switch (minLevel.ToLower())
                        {
                            case "debug":
                                tempLevel = LogLevel.Debug;
                                break;
                            case "trace":
                                tempLevel = LogLevel.Trace;
                                break;

                            case "critical":
                                tempLevel = LogLevel.Critical;
                                break;
                            case "error":
                                tempLevel = LogLevel.Error;
                                break;
                            case "warning":
                                tempLevel = LogLevel.Warning;
                                break;
                            case "information":
                                tempLevel = LogLevel.Information;
                                break;
                            default:
                                break;
                        }
                    }
                    return tempLevel;
                }
            }

            public Dictionary<string, LogLevel> LevelOverrides
            {
                get
                {
                    Dictionary<string, LogLevel> logLevels = new Dictionary<string, LogLevel>();
                    string logLevelsFromConfigFile = ConfigurationManager.AppSettings.Get("LevelOverrides");
                    if (!string.IsNullOrWhiteSpace(logLevelsFromConfigFile))
                    {
                        string[] overrideLevels = logLevelsFromConfigFile.Split(",");
                        foreach (string overrideLevel in overrideLevels)
                        {
                            string[] level = overrideLevel.Split("|");
                            switch (level[1].ToLower())
                            {
                                case "debug":
                                    logLevels.Add(level[0], LogLevel.Debug);
                                    break;
                                case "trace":
                                    logLevels.Add(level[0], LogLevel.Trace);
                                    break;

                                case "critical":
                                    logLevels.Add(level[0], LogLevel.Critical);
                                    break;
                                case "error":
                                    logLevels.Add(level[0], LogLevel.Error);
                                    break;
                                case "warning":
                                    logLevels.Add(level[0], LogLevel.Warning);
                                    break;
                                case "information":
                                    logLevels.Add(level[0], LogLevel.Information);
                                    break;
                                default:
                                    break;
                            }

                        }
                    }
                    return logLevels;
                }
            }
            public bool IsJson
            {
                get
                {
                    bool.TryParse(ConfigurationManager.AppSettings.Get("IsJson"), out bool isJson);
                    return isJson;
                }
            }
            public long FileSizeLimitBytes
            {
                get
                {
                    long.TryParse(ConfigurationManager.AppSettings.Get("FileSizeLimitBytes"), out long fileSizeLimitBytes);
                    if (fileSizeLimitBytes == 0)
                    {
                        fileSizeLimitBytes = 536870912;
                    }
                    return fileSizeLimitBytes;
                }
            }
            public int RetainedFileCountLimit
            {
                get
                {
                    int.TryParse(ConfigurationManager.AppSettings.Get("RetainedFileCountLimit"), out int retainedFileCountLimit);
                    if (retainedFileCountLimit == 0)
                    {
                        retainedFileCountLimit = 31;
                    }
                    return retainedFileCountLimit;
                }
            }

            public string OutputTemplate
            {
                get
                {
                    string outputTemplate = ConfigurationManager.AppSettings.Get("OutputTemplate");
                    if (string.IsNullOrWhiteSpace(outputTemplate))
                    {
                        outputTemplate = "{Timestamp:o} {RequestId,13} [{Level:u3}] {Message} ({EventId:x8}){NewLine}{Exception}";
                    }
                    return outputTemplate;
                }
            }
            public string LogServiceUrl
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("LogServiceUrl"); ;
                }
            }
        }

        public class KestrelSettings
        {
            public int RESTAPIPort
            {
                get
                {
                    int.TryParse(ConfigurationManager.AppSettings.Get("RESTAPIPort"), out int port);
                    return port;
                }
            }

            public bool UseCertificateForSSL
            {
                get
                {
                    bool.TryParse(ConfigurationManager.AppSettings.Get("UseCertificateForSSL"), out bool useSSL);
                    return useSSL;
                }
            }
            public string CertificateSubject
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("CertificateSubject");
                }
            }
            public string CertificateStoreName
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("CertificateStoreName");
                }
            }

            public string CertificateLocation
            {
                get
                {
                    return ConfigurationManager.AppSettings.Get("CertificateLocation");
                }
            }
            public bool CertificateAllowInvalid
            {
                get
                {
                    bool.TryParse(ConfigurationManager.AppSettings.Get("CertificateAllowInvalid"), out bool allowInvalid);
                    return allowInvalid;
                }
            }
        }


        public class ConnectionStrings
        {

            /// <summary>
            /// The Connection SAtring for the Outbound database
            /// </summary>
            public string OutboundCorroGen { get { return ConfigurationManager.ConnectionStrings["OutboundCorroGen"].ConnectionString; } }

            /// <summary>
            /// The connections tring for the hangfire database
            /// </summary>
            public string HangfireDb { get { return ConfigurationManager.ConnectionStrings["Hangfire"].ConnectionString; } }
        }

        ///// <summary>
        ///// Database connection string for the Outbound database
        ///// </summary>
        //public string OutboundCorroGen => ConfigurationManager.ConnectionStrings["OutboundCorroGen"].ConnectionString;

        ///// <summary>
        ///// Database connection string for the Hangfire database
        ///// </summary>
        //public string HangfireDb => ConfigurationManager.ConnectionStrings["Hangfire"].ConnectionString;

        
        ///// <summary>
        ///// Current environment to use for logging purposes
        ///// </summary>
        //public string Env => ConfigurationManager.AppSettings.Get("Env");

        ///// <summary>
        ///// HJow often to flush the river and data,csv file
        ///// </summary>
        //public string FlushDataToFilesBatchSize => ConfigurationManager.AppSettings.Get("FlushDataToFilesBatchSize");

        ///// <summary>
        ///// How many Hangfire worker threads will runa t once
        ///// </summary>
        //public string HangfireWorkerCount => ConfigurationManager.AppSettings.Get("HangfireWorkerCount");

        ///// <summary>
        ///// The event source name for events written to the windows event log
        ///// </summary>
        //public string EventLogServiceName  => ConfigurationManager.AppSettings.Get("EventLogServiceName");

        ///// <summary>
        ///// Path to the log files
        ///// </summary>
        //public string LogFilePath => ConfigurationManager.AppSettings.Get("LogFilePath");

        ///// <summary>
        ///// The API URL to use for the RESET api
        ///// </summary>
        //public string APIURL => ConfigurationManager.AppSettings.Get("APIURL");

        ///// <summary>
        ///// The user name that is recorded against any OutboundDatabase operations that require a user name
        ///// </summary>
        //public string UserToRecordAs => ConfigurationManager.AppSettings.Get("UserToRecordAs");

        //public Version AppVersion => Assembly.GetExecutingAssembly().GetName().Version;

        //public string Server => Environment.MachineName;

        //public string LogServiceUrl => ConfigurationManager.AppSettings.Get("LogServiceUrl");

        ///// <summary>
        ///// Method to display the configuration settings as a string
        ///// </summary>
        ///// <returns></returns>
        //public string DisplayConfig()
        //{
        //    StringBuilder sb = new StringBuilder();
        //    sb.Append("OutboundCorroGen = ");
        //    sb.AppendLine(OutboundCorroGen);
        //    sb.Append("HangfireDb = ");
        //    sb.AppendLine(HangfireDb);
        //    sb.Append("CustomersNamespace = ");
        //    sb.AppendLine(CustomersNamespace);
        //    sb.Append("TemplatesConfigPath = ");
        //    sb.AppendLine(TemplatesConfigPath);
        //    sb.Append("RelativeJobLogFileLocation = ");
        //    sb.AppendLine(RelativeJobLogFileLocation);
        //    sb.Append("DriverFileName = ");
        //    sb.AppendLine(DriverFileName);
        //    sb.Append("DataFileName = ");
        //    sb.AppendLine(DataFileName);
        //    sb.Append("Env = ");
        //    sb.AppendLine(Env);
        //    sb.Append("FlushDataToFilesBatchSize = ");
        //    sb.AppendLine(FlushDataToFilesBatchSize);
        //    sb.Append("HangfireWorkerCount = ");
        //    sb.AppendLine(HangfireWorkerCount);
        //    sb.Append("EventLogServiceName = ");
        //    sb.AppendLine(EventLogServiceName);
        //    sb.Append("LogFilePath = ");
        //    sb.AppendLine(LogFilePath);
        //    sb.Append("APIURL = ");
        //    sb.AppendLine(APIURL);
        //    sb.Append("UserToRecordAs = ");
        //    sb.AppendLine(UserToRecordAs);


        //    return sb.ToString();
        //}
    }
}


