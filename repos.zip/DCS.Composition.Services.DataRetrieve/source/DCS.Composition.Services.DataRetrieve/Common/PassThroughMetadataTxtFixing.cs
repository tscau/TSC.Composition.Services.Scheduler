﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Xml;
using DCS.Logging.Shared.Infrastructure;

namespace DCS.Composition.Services.DataRetrieve.Common
{
    /// <summary>
    /// 
    /// </summary>
    public static class PassThroughMetadataTxtFixing
    {

        /// <summary>
        /// Checks and adds a ClientPreference Tag if it is missing from the OfInterest Client block
        /// </summary>
        /// <param name="PassThroughMetadataTxt">the PassThroughMetadataTxt that needs to be checked and corrected</param>
        /// <param name="perBatchLogger"></param>
        /// <returns>A string representing the corrected PassThroughMetadataTxt.</returns>
        /// <remarks>This code corrects TFS Bug 2289300 where the pub file requires the ClientPreference, even if it is blank, so that it can correctly map the Client IDs</remarks>
        public static string CheckandAddOfInterestClientPreferenceTag(string PassThroughMetadataTxt, IPerBatchLogger perBatchLogger = null)
        {

            //var BlankClientPreferenceAndClientInternalIDTag = @"<ClientPreference><ClientInternalID>0</ClientInternalID></ClientPreference>";


            XmlDocument doc = new XmlDocument();
            try
            {
                doc.LoadXml(PassThroughMetadataTxt);
            }
            catch (XmlException ex)
            {
                if (perBatchLogger != null) 
                { 
                    perBatchLogger.Verbose($"Could not load the XML. PassThroughMetadataTxt had some invalid XML. Ignoring rest of this block and continuing.", new object[] { }); 
                }
                return PassThroughMetadataTxt;
            }
            

            var namespaceName = "ns";
            var namespacePrefix = string.Empty;
            XmlNamespaceManager nameSpaceManager = null;
            if (doc.FirstChild.Attributes != null)
            {
                var xmlns = doc.FirstChild.Attributes["xmlns"];
                if (xmlns != null)
                {
                    nameSpaceManager = new XmlNamespaceManager(doc.NameTable);
                    nameSpaceManager.AddNamespace(namespaceName, xmlns.Value);
                    namespacePrefix = namespaceName + ":";
                }
            }

            var ContactNodes = doc.SelectNodes($"//{namespacePrefix}ClientList/{namespacePrefix}Client[{namespacePrefix}RoleTypeDecode/text() = \"CONTACT\"]", nameSpaceManager);
            if (ContactNodes.Count == 1)
            {
                perBatchLogger.Verbose($"PassThroughMetadataTxt Client CONTACT found.", new object[] { });

                var ContactNode = ContactNodes[0];
                var ClientPreferenceNode = ContactNode.SelectSingleNode($"{namespacePrefix}ClientPreference", nameSpaceManager);
                if (ClientPreferenceNode == null)
                {

                    perBatchLogger.Verbose($"PassThroughMetadataTxt Client CONTACT block missing a ClientPreference Block. Adding ClientPreference block with ClientInternalID block.", new object[] { });
                    var ClientInternalIDTag = doc.CreateElement("ClientInternalID", doc.DocumentElement.NamespaceURI);    //Creates <ClientInternalID></ClientInternalID>
                    ClientInternalIDTag.InnerText = "0";                                //Puts a zero in the tag <ClientInternalID>0</ClientInternalID>
                    var ClientPreferenceTag = doc.CreateElement("ClientPreference", doc.DocumentElement.NamespaceURI);    //Creates <ClientPreference></ClientPreference>
                    ClientPreferenceTag.AppendChild(ClientInternalIDTag);
                    ContactNode.AppendChild(ClientPreferenceTag);
                }
                else
                {
                    perBatchLogger.Verbose($"{Environment.MachineName} - PassThroughMetadataTxt Client CONTACT block has ClientPreference Block. Won't do anything.", new object[] { });
                    return PassThroughMetadataTxt;
                }
            }
            else {
                if (ContactNodes.Count == 0) 
                { 
                    perBatchLogger.Verbose($"PassThroughMetadataTxt does not contain any Client CONTACT block.", new object[] { }); 
                } 
                if (ContactNodes.Count > 1) 
                { 
                    perBatchLogger.Verbose($"PassThroughMetadataTxt contains more than one Client CONTACT block. Only one allowed.", new object[] { }); 
                } 
                return PassThroughMetadataTxt;
            }


            return doc.OuterXml;
        }

    }
}
