﻿using System.Collections.Generic;

namespace DCS.Composition.Services.DataRetrieve.Common
{
    /// <summary>
    /// Class to hold the result of executing the DataRetreive. Useful for autoamted testing
    /// </summary>
    public class ExecuteDataRetrieveResult
    {
        /// <summary>
        /// Any log messages that occured during the run
        /// </summary>
        public List<string> LogMessages { get; set; }

        /// <summary>
        /// The number of records that were written to the driver
        /// </summary>
        public long NumberRecordsWrittenToDriver { get; set; }

        /// <summary>
        /// The full filename and path of trhe driver
        /// </summary>
        public string DriverFileNameAndPath { get; set; }

        /// <summary>
        /// The full filename and path of the data.csv file that holds the CorresId's of the data retrieved
        /// </summary>
        public string DataFileNameAndPath { get; set; }

        /// <summary>
        /// The time take to process the data retrieve
        /// </summary>
        public long TimeTakenInSeconds { get; set; }

        /// <summary>
        /// Public constructor
        /// </summary>
        public ExecuteDataRetrieveResult()
        {
            LogMessages = new List<string>();
            NumberRecordsWrittenToDriver = 0;
        }

    }
}