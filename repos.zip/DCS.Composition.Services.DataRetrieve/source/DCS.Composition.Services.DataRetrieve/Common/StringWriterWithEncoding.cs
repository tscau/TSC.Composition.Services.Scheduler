﻿using System.IO;
using System.Text;

namespace DCS.Composition.Services.DataRetrieve.Common
{
    /// <summary>
    /// Class to wrap the .NET StringWriter class so that we can use a specific encoding. By default a StringBuilder will use UTF-16. If this is
    /// used to write to an XSML file, the XML will be written with a UTF-16 which will cause downstream issues
    /// </summary>
    public class StringWriterWithEncoding : StringWriter
    {
        /// <summary>
        /// Method to ensure that the supplied StringBuilder has the specified encoding. By default, a StringBuilder will default to UTF-16, which may not be desirable
        /// </summary>
        /// <param name="sb"></param>
        /// <param name="encoding"></param>
        public StringWriterWithEncoding(StringBuilder sb, Encoding encoding) : base(sb)
        {
            this.m_Encoding = encoding;
        }


        private readonly Encoding m_Encoding;
        /// <summary>
        /// The encoding to define the StringBuilder as
        /// </summary>
        public override Encoding Encoding
        {
            get
            {
                return this.m_Encoding;
            }
        }
    }
}
