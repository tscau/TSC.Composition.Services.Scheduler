﻿using DCS.Composition.Services.DataRetrieve.Config;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Shared.DataAccess.Outbound;
using DCS.Shared.DataAccess.Outbound.Database;
using DCS.Shared.DataAccess.Outbound.Documents;
using DCS.Logging.Shared.Common;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Abstractions;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Xml;
using DCS.Logging.Shared.Infrastructure;

namespace DCS.Composition.Services.DataRetrieve.Common
{
    /// <summary>
    /// Performs the actual DataRetrieve.
    /// </summary>
    public class DataRetrieve
    {
        readonly IAppConfig _appConfig;

        DCSLogMsg logMsg = null;

        private const string XML_CDATA_START = "<![CDATA[";
        private const string XML_CDATA_END = "]]>";
        private const string DPID_START_TAG = "<GeographicAddrDeliveryPointID>";
        private const string DPID_END_TAG = "</GeographicAddrDeliveryPointID>";
        private const string DPID_EMPTY_TAG = "<GeographicAddrDeliveryPointID />";
        private const string DEFAULT_DATA_FILE_NAME = "Data.csv";
        private const string DEFAULT_DATA_FILE_EXT = "csv";
        private const string EAI_OPENING_TAG = "<EAIOutboundCorrespondence";

        readonly IOutbound _db;
        readonly string server = Environment.MachineName;

        readonly IPerBatchLogger _perBatchLogger;
        readonly IFileSystem _fileSystem;

        /// <summary>
        /// Constructor to setup the database connection and the logging infrastructure
        /// </summary>
        /// <param name="perBatchLogger"></param>
        /// <param name="fileSystem"></param>
        /// <param name="dbContext"></param>
        /// <param name="appConfig"></param>
        public DataRetrieve(IPerBatchLogger perBatchLogger, IFileSystem fileSystem, IOutbound dbContext, IAppConfig appConfig)
        {
            _perBatchLogger = perBatchLogger;
            _fileSystem = fileSystem;
            _appConfig = appConfig;

            if (dbContext == null)
            {
                _db = new DbContext(() => new SqlConnection(_appConfig.ConnectionStrings.OutboundCorroGen));
            }
            else
            {
                _db = dbContext;
            }
        }


        /// <summary>
        /// Method to actually do the DataRetrieve
        /// </summary>
        /// <param name="message"></param>
        /// <param name="wrapDriverWithCustomerTag"></param>
        /// <returns>A completed Task</returns>
        //public Task ExecuteDataRetrieve(CompositionMsg message, bool wrapDriverWithCustomerTag)
        public ExecuteDataRetrieveResult ExecuteDataRetrieve(CompositionMsg message, bool wrapDriverWithCustomerTag)
        {
            logMsg = new DCSLogMsg
            {
                Application = "DCS.Composition.Services.DataRetrieve",
                Server = _appConfig.AppSettings.Server,
                ApplicationVersion = _appConfig.AppSettings.Versions[Assembly.GetExecutingAssembly().GetName().Name].ToString(),
                GSScheduleId = message.GSScheduleId,
                JGScheduleId = message.JGScheduleId,
                DeliveryChannel = message.DeliveryChannel,
                NatDins = string.Join(",", message.NatDins),
                BatchId = message.BatchId,
                LogDatetime = DateTime.Now,
                LogLevel = LogLevel.Information
            };

            string messageAsJson = JsonSerializer.Serialize(message);
            ExecuteDataRetrieveResult result = new ExecuteDataRetrieveResult();

            Stopwatch stp = new Stopwatch();
            stp.Start();

            long numRecordsRetreived = 0;
            //Parse the message - currently a string
            try
            {

                string outputFile = Path.Combine(message.JobPath, _appConfig.AppSettings.DriverFileName);
                string dir = Path.GetDirectoryName(outputFile);
                if (_fileSystem.File.Exists(outputFile))
                {
                    string fName = Path.GetFileNameWithoutExtension(outputFile);
                    string ext = Path.GetExtension(outputFile);
                    string backupFname = string.Format("{0}_{1}.{2}", fName, DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss"), ext);
                    string backupFile = Path.Combine(dir, backupFname);
                    _fileSystem.File.Move(outputFile, backupFile);
                }

                result.DriverFileNameAndPath = outputFile;

                //Check if the Data file also exists and rename that as well
                string csvData = _appConfig.AppSettings.DataFileName;
                if (string.IsNullOrWhiteSpace(csvData))
                {
                    csvData = DEFAULT_DATA_FILE_NAME;
                }
                string csvDataAndPath = Path.Combine(dir, csvData);
                string csvDataExt = Path.GetExtension(csvDataAndPath);
                if (string.IsNullOrWhiteSpace(csvDataExt))
                {
                    csvDataExt = DEFAULT_DATA_FILE_EXT;
                }
                if (_fileSystem.File.Exists(csvDataAndPath))
                {
                    string backupCsvData = string.Format("{0}_{1}.{2}", csvData, DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss"), csvDataExt);
                    string backupCsvDataAndPath = Path.Combine(dir, backupCsvData);
                    _fileSystem.File.Move(csvDataAndPath, backupCsvDataAndPath);
                }

                result.DataFileNameAndPath = csvDataAndPath;

                //Process Request
                _perBatchLogger.Info($"Processing records for batchId {message.BatchId}", new object[] { });
                result.LogMessages.Add($"{server} - Processing records for batchId {message.BatchId}");

                if (message.BatchId > 0)
                {
                    List<long> corresInBatch = _db.GetCorresRequestsForDataRetrieve((int)message.BatchId);

                    StringBuilder driverBuilder = new StringBuilder();
                    StringBuilder csvBuilder = new StringBuilder();
                    csvBuilder.AppendFormat("Batch,{0}{1}", message.BatchId, Environment.NewLine);

                    if (wrapDriverWithCustomerTag)
                    {
                        //the new flow - wrap the final XML document with a Customers tag
                        numRecordsRetreived = ProcessNewDriver(outputFile, csvDataAndPath, (int)message.BatchId, csvBuilder, corresInBatch);
                    }

                    else
                    {
                        //the old flow
                        numRecordsRetreived = ProcessDriver(outputFile, csvDataAndPath, (int)message.BatchId, driverBuilder, csvBuilder, corresInBatch);
                    }
                }
                else
                {
                    _perBatchLogger.Info($"No BatchId supplied. BatchId = {message.BatchId}", new object[] { });
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{server} - No BatchId supplied. BatchId = {message.BatchId}", null);
                    result.LogMessages.Add($"{server} - No BatchId supplied. BatchId = {message.BatchId}");
                }

                _perBatchLogger.Info($"{numRecordsRetreived} records retrieved for batchId {message.BatchId}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{server} - {numRecordsRetreived} records retrieved for batchId {message.BatchId}", null);
                result.LogMessages.Add($"{server} - {numRecordsRetreived} records retrieved for batchId {message.BatchId}");
                result.NumberRecordsWrittenToDriver = numRecordsRetreived;

                return result;
            }
            catch (Exception ex)
            {
                _perBatchLogger.Error(ex, $"Error occured processing {messageAsJson}", new object[] { });
                AppLog.Error()(ex, message.BatchId,  $"Error occured processing {messageAsJson}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Error, $"{server} - Eror occured processing {messageAsJson}", ex);
                return result;
            }
            finally
            {
                stp.Stop();
                _perBatchLogger.Info($"DataRetrieve completed in {stp.ElapsedMilliseconds / 1000}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{server} - DataRetrieve completed in {stp.ElapsedMilliseconds / 1000}", null);
                result.LogMessages.Add($"{server} - DataRetrieve completed in {stp.ElapsedMilliseconds / 1000}");
                result.TimeTakenInSeconds = stp.ElapsedMilliseconds / 1000;
            }


        }

        /// <summary>
        /// Generates 'Old' style driver file. The final XML is NOT wrapped in a Customers tag so that the PUB files can process the driver as a plain text file.
        /// </summary>
        /// <param name="driverOutputFile">The full name and path to the final driver file</param>
        /// <param name="dataOutputFile"></param>
        /// <param name="batchId">The BatchID to retrieve the correspondence for.</param>
        /// <param name="driverBuilder"></param>
        /// <param name="csvBuilder">The full name and path of the file that holds the batchID|BETID list. THis file is used in later orchestration steps</param>
        /// <param name="corresList">The list of CorresId's that will be processed.</param>
        /// <returns>The count of records that were written to the <paramref name="driverOutputFile"/></returns>
        /// <remarks>Any exceptions that occur in this method will be thrown and it is the responsibility of the calling method to handle the exception.
        /// THis method will flush every OutputChunkLimit (from Configuration) or 1000 if not supplied in configuration. 
        /// </remarks>
        public long ProcessDriver(string driverOutputFile, string dataOutputFile, int batchId, StringBuilder driverBuilder, StringBuilder csvBuilder, List<long> corresList)
        {
            string outputFolder = Path.GetDirectoryName(driverOutputFile);
            long i = 0;
            XmlWriterSettings settings = new XmlWriterSettings
            {
                OmitXmlDeclaration = true,
                Indent = true,
                Encoding = Encoding.UTF8
            };
            Stopwatch sp = new Stopwatch();
            sp.Start();

            foreach (var corresId in corresList)
            {
                CorresRequestForDataRetrieve corresToProcess = _db.GetCorresRequestsDetailsForDataRetrieve(corresId);

                corresToProcess = ProcessLetter(corresToProcess);

                //Add the CorresRequestId to the cXML
                TextReader tr = new StringReader(corresToProcess.PassThroughMetadataTxt);
                XmlDocument doc = new XmlDocument();
                doc.Load(tr);

                //Load the namespaces
                XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
                nsmgr.AddNamespace("ns", _appConfig.AppSettings.CustomersNamespace);
                var activityTypesNode = doc.SelectSingleNode("//ns:ActivityTypes", nsmgr);

                var corresRequestIdNode = doc.SelectSingleNode("//ns:CorresRequestId", nsmgr);

                if (corresRequestIdNode == null)
                {
                    XmlNode corresRequstIdNodeToAdd = doc.CreateElement("CorresRequestId", doc.DocumentElement.NamespaceURI);
                    corresRequstIdNodeToAdd.InnerText = corresToProcess.CorresRequestId.ToString();
                    activityTypesNode.AppendChild(corresRequstIdNodeToAdd);
                }

                //NOTE:Need to do this otherwise the string builder will output a UTF-16 string which will break Exstream
                StringBuilder tempStringBuilder = new StringBuilder();
                StringWriterWithEncoding tempStringWriter = new StringWriterWithEncoding(tempStringBuilder, Encoding.UTF8);
                using (var xmlWriter = XmlWriter.Create(tempStringWriter, settings))
                {
                    doc.Save(xmlWriter);
                    xmlWriter.Flush();
                    corresToProcess.PassThroughMetadataTxt = tempStringWriter.GetStringBuilder().ToString();
                }

                //Save the XML as a string so we can manipulate it and save the string to the driver
                //Remove all instances of CDATA Start XML
                if (corresToProcess.PassThroughMetadataTxt.Contains(XML_CDATA_START))
                {
                    corresToProcess.PassThroughMetadataTxt = corresToProcess.PassThroughMetadataTxt.Replace(XML_CDATA_START, String.Empty);
                }

                //Add the corresToProcess.CorresRequestId if it is not already there
                //Search fro 

                //Remove all instances ofCDATA End XML
                if (corresToProcess.PassThroughMetadataTxt.Contains(XML_CDATA_END))
                {
                    corresToProcess.PassThroughMetadataTxt = corresToProcess.PassThroughMetadataTxt.Replace(XML_CDATA_END, String.Empty);
                }

                //Strip any extraneous XML from the PassThrough to ensure that the PUB file has a clean record to use
                corresToProcess.PassThroughMetadataTxt = corresToProcess.PassThroughMetadataTxt.Substring(corresToProcess.PassThroughMetadataTxt.IndexOf(EAI_OPENING_TAG));

                //Add the EAIOutboundCorrespondence.InteractionActivity.ActivityTypes.CorresRequestId if it does not exist in the cXML - means we have to load the cXML and add a new node

                _perBatchLogger.Verbose($"Starting CheckandAddOfInterestClientPreferenceTag", new object[] { } );
                corresToProcess.PassThroughMetadataTxt = PassThroughMetadataTxtFixing.CheckandAddOfInterestClientPreferenceTag(corresToProcess.PassThroughMetadataTxt, _perBatchLogger);
                _perBatchLogger.Verbose($"Finished CheckandAddOfInterestClientPreferenceTag", new object[] { });

                //Add record to driver
                driverBuilder.Append(corresToProcess.PassThroughMetadataTxt);
                driverBuilder.AppendLine();

                //Add record to csv file
                csvBuilder.AppendFormat("Request,{0},{1}{2}", corresToProcess.CorresId, batchId, Environment.NewLine);
                if (i % _appConfig.AppSettings.FlushDataToFilesBatchSize == 0)
                {
                    _perBatchLogger.Info($"Flushing records to driver & data files in {outputFolder}", new object[] { });
                    if (logMsg != null)
                    {
                        logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{server} - Flushing records to driver & data files in {outputFolder}", null);
                    }

                    //Driver flush
                    _fileSystem.File.AppendAllText(driverOutputFile, driverBuilder.ToString(), Encoding.UTF8);
                    driverBuilder.Clear();

                    //Data file flush
                    _fileSystem.File.AppendAllText(dataOutputFile, csvBuilder.ToString(), Encoding.UTF8);
                    csvBuilder.Clear();
                }

                i += 1;

            }

            //Flush any remaining driver records
            if (driverBuilder.Length > 0)
            {
                _perBatchLogger.Info($"Flushing records to driver file {driverOutputFile}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{server} - Flushing records to driver file {driverOutputFile}", null);

                _fileSystem.File.AppendAllText(driverOutputFile, driverBuilder.ToString(), Encoding.UTF8);
                driverBuilder.Clear();
            }

            //Flush any remaining csv records
            if (csvBuilder.Length > 0)
            {
                _perBatchLogger.Info($"Flushing records to data file {dataOutputFile}", new object[] { });
                logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{server} - Flushing records to data file {dataOutputFile}", null);

                _fileSystem.File.AppendAllText(dataOutputFile, csvBuilder.ToString(), Encoding.UTF8);
                csvBuilder.Clear();
            }


            sp.Stop();
            _perBatchLogger.Info($"Time taken (minutes) to process batch {batchId}: {sp.Elapsed.TotalMinutes }", new object[] { });

            return i;
        }

        /// <summary>
        /// Generates 'New' style driver file. The final XML is wrapped in a Customers tag so that the PUB files can process the driver as an XML file as opposed to a plain text file
        /// </summary>
        /// <param name="driverOutputFile">The full name and path to the final driver file</param>
        /// <param name="dataOutputFile"></param>
        /// <param name="batchId">The BatchID to retrieve the correspondence for.</param>
        /// <param name="csvBuilder">The full name and path of the file that holds the batchID|BETID list. THis file is used in later orchestration steps</param>
        /// <param name="corresList">The list of CorresId's that will be processed.</param>
        /// <returns>The count of records that were written to the <paramref name="driverOutputFile"/></returns>
        /// <remarks>Any exceptions that occur in this method will be thrown and it is the responsibility of the calling method to handle the exception.
        /// THis method will flush every OutputChunkLimit (from Configuration) or 1000 if not supplied in configuration. 
        /// </remarks>
        public long ProcessNewDriver(string driverOutputFile, string dataOutputFile, int batchId, StringBuilder csvBuilder, List<long> corresList)
        {
            string ns = _appConfig.AppSettings.CustomersNamespace;
            var outputFolder = Path.GetDirectoryName(driverOutputFile);
            long i = 0;
            XmlWriterSettings settings = new XmlWriterSettings() { Indent = true, Encoding = Encoding.UTF8 };
            Stopwatch sp = new Stopwatch();
            sp.Start();

            using (XmlWriter xmlWriter = XmlWriter.Create(driverOutputFile, settings))
            {
                //start element
                xmlWriter.WriteStartDocument();
                xmlWriter.WriteStartElement("Customers", ns);
                xmlWriter.WriteRaw(Environment.NewLine);
                xmlWriter.Flush();

                foreach (var corresId in corresList)
                {
                    CorresRequestForDataRetrieve corresToProcess = _db.GetCorresRequestsDetailsForDataRetrieve(corresId);

                    corresToProcess = ProcessLetter(corresToProcess);

                    //Add the CorresRequestId to the cXML
                    TextReader tr = new StringReader(corresToProcess.PassThroughMetadataTxt);
                    XmlDocument doc = new XmlDocument();
                    doc.Load(tr);

                    //Load the namespaces
                    XmlNamespaceManager nsmgr = new XmlNamespaceManager(doc.NameTable);
                    nsmgr.AddNamespace("ns", _appConfig.AppSettings.CustomersNamespace);
                    var activityTypesNode = doc.SelectSingleNode("//ns:ActivityTypes", nsmgr);

                    var corresRequestIdNode = doc.SelectSingleNode("//ns:CorresRequestId", nsmgr);

                    if (corresRequestIdNode == null)
                    {
                        XmlNode corresRequstIdNodeToAdd = doc.CreateElement("CorresRequestId", doc.DocumentElement.NamespaceURI);
                        corresRequstIdNodeToAdd.InnerText = corresToProcess.CorresRequestId.ToString();
                        activityTypesNode.AppendChild(corresRequstIdNodeToAdd);
                    }

                    StringBuilder sb = new StringBuilder();
                    XmlWriterSettings xws = new XmlWriterSettings
                    {
                        OmitXmlDeclaration = true,
                        Indent = false
                    };
                    using (XmlWriter xw = XmlWriter.Create(sb, xws))
                    {
                        doc.WriteTo(xw);
                    }
                    corresToProcess.PassThroughMetadataTxt = sb.ToString();

                    //Remove all instances of CDATA Start XML
                    if (corresToProcess.PassThroughMetadataTxt.Contains(XML_CDATA_START))
                    {
                        corresToProcess.PassThroughMetadataTxt = corresToProcess.PassThroughMetadataTxt.Replace(XML_CDATA_START, String.Empty);
                    }

                    //Remove all instances of CDATA End XML
                    if (corresToProcess.PassThroughMetadataTxt.Contains(XML_CDATA_END))
                    {
                        corresToProcess.PassThroughMetadataTxt = corresToProcess.PassThroughMetadataTxt.Replace(XML_CDATA_END, String.Empty);
                    }

                    corresToProcess.PassThroughMetadataTxt = corresToProcess.PassThroughMetadataTxt.Substring(corresToProcess.PassThroughMetadataTxt.IndexOf(EAI_OPENING_TAG));
                    
                    _perBatchLogger.Verbose($"Starting CheckandAddOfInterestClientPreferenceTag", new object[] { });
                    corresToProcess.PassThroughMetadataTxt = PassThroughMetadataTxtFixing.CheckandAddOfInterestClientPreferenceTag(corresToProcess.PassThroughMetadataTxt, _perBatchLogger);
                    _perBatchLogger.Verbose($"Finished CheckandAddOfInterestClientPreferenceTag", new object[] { });


                    xmlWriter.WriteRaw(corresToProcess.PassThroughMetadataTxt + Environment.NewLine);
                    xmlWriter.Flush();

                    csvBuilder.AppendFormat("Request,{0},{1}{2}", corresToProcess.CorresId, batchId, Environment.NewLine);
                    if (i % _appConfig.AppSettings.FlushDataToFilesBatchSize == 0)
                    {
                        _perBatchLogger.Info($"Flushing records in data file {outputFolder}", new object[] { });
                        _perBatchLogger.Info($"Flushing records in data file {dataOutputFile}", new object[] { });
                        logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{server} - Flushing records in data file {outputFolder}", null);
                        logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{server} - Flushing records in data file {dataOutputFile}", null);

                        //Data file flush
                        _fileSystem.File.AppendAllText(dataOutputFile, csvBuilder.ToString(), Encoding.UTF8);
                        csvBuilder.Clear();
                    }

                    i += 1;

                }

                //end element
                xmlWriter.WriteEndElement();
                xmlWriter.WriteEndDocument();
                xmlWriter.Flush();
                xmlWriter.Close();

                //Delete the file if no record found
                if (i == 0 && _fileSystem.File.Exists(driverOutputFile))
                {
                    _fileSystem.File.Delete(driverOutputFile);

                }

                //Flush any remaining csv records
                if (csvBuilder.Length > 0)
                {
                    _perBatchLogger.Info($"Flushing records in data file {dataOutputFile}", new object[] { });
                    logMsg.LogToService(_appConfig.Logging.LogServiceUrl, LogLevel.Information, $"{server} - Flushing records in data file {dataOutputFile}", null);
                    _fileSystem.File.AppendAllText(dataOutputFile, csvBuilder.ToString(), Encoding.UTF8);
                    csvBuilder.Clear();
                }
            }

            sp.Stop();
            _perBatchLogger.Info($"Time taken (minutes) to process batch {batchId}: {sp.Elapsed.TotalMinutes}", new object[] { });
            return i;

        }

        /// <summary>
        /// Method to generate the DPID for the client based ont he DPI, CorresId and the RUCExceptionCode for a piece of correspondence.
        /// </summary>
        /// <param name="corresToProcess">A populated <seealso cref="CorresRequestForDataRetrieve"/></param>
        /// <returns><para>The modified <paramref name="corresToProcess"/> parameter. The following parts of the PasthrougMetadataTxt fields are modified by this method</para>
        /// <list type="table">
        /// <item>Removes spaces from the empty GeographicAddrDeliveryPointID tag if it exists</item>
        /// <item>Replaces an empty GeographicAddrDeliveryPointID with a start and end GeographicAddrDeliveryPointID tag</item>
        /// <item>Replaces an empty GeographicAddrDeliveryPointID with a start and end GeographicAddrDeliveryPointID tag</item>
        /// <item>Places a GeographicAddrDeliveryPointID tag with the DPID and spaces removed</item>
        /// </list>
        /// </returns>
        /// <remarks>Example of before and after tags:
        /// </remarks>
        private CorresRequestForDataRetrieve ProcessLetter(CorresRequestForDataRetrieve corresToProcess)
        {
            //Always generate barcode
            string dpid = GenerateBarcodeString(corresToProcess.DPID, corresToProcess.CorresId.ToString(), corresToProcess.RUCExceptionCd.ToString());
            corresToProcess.PassThroughMetadataTxt = corresToProcess.PassThroughMetadataTxt.Replace(DPID_EMPTY_TAG, DPID_EMPTY_TAG.Replace(" ", ""));
            corresToProcess.PassThroughMetadataTxt = corresToProcess.PassThroughMetadataTxt.Replace(DPID_EMPTY_TAG.Replace(" ", ""), String.Concat(DPID_START_TAG, DPID_END_TAG));
            corresToProcess.PassThroughMetadataTxt = corresToProcess.PassThroughMetadataTxt.Replace(String.Concat(DPID_START_TAG, corresToProcess.DPID).Replace(" ", ""), String.Concat(DPID_START_TAG, dpid));
            return corresToProcess;
        }

        /// <summary>
        /// Generates the barcode string using the dpid, bet and ruc exception code
        /// </summary>
        /// <param name="dpid">The delivery point id of the address</param>
        /// <param name="BET">The Business Event Tracking number</param>
        /// <param name="RucExceptionCode">The Return Unclaimed Exception Code associtated with the template in the db</param>
        /// <returns>A string representing the barcode. If an exception is thrown by Ato.CD.Outbound.CorroGen.RS.RS.BuildUpBarcodeString, it will need to be handled by the calling code.</returns>
        /// <remarks>This calls the Ato.CD.Outbound.CorroGen.RS.RS.BuildUpBarcodString to generate the barcode from the parameters.</remarks>
        private string GenerateBarcodeString(string dpid, string BET, string RucExceptionCode)
        {
            Ato.CD.Outbound.CorroGen.RS.RS RS = new Ato.CD.Outbound.CorroGen.RS.RS();
            //CustomerInfo string is BET plus RUC exceptionCode 
            string customerInfo = BET + RucExceptionCode;
            return RS.BuildUpBarcodeString(Ato.CD.Outbound.CorroGen.RS.RS.FCCDecimal.CustomerThree, dpid, customerInfo);
        }



    }
}