﻿namespace DCS.Composition.Services.DataRetrieve.Config
{
    /// <summary>
    /// Interface that defines the applikcation configuration
    /// </summary>
    public interface IAppConfig
    {
        /// <summary>
        /// Contains the general app settings config data
        /// </summary>
        public IAppSettings AppSettings { get; set; }

        /// <summary>
        /// Contains the logging config data
        /// </summary>
        public ILoggingSettings Logging { get; set; }

        /// <summary>
        /// Contains the Kestrel config data
        /// </summary>
        public IKestrelSettings Kestrel { get; set; }

        /// <summary>
        /// Contains the connection string config data
        /// </summary>
        public IConnectionStrings ConnectionStrings { get; set; }
    }
}
