﻿namespace DCS.Composition.Services.DataRetrieve.Config
{
    /// <summary>
    /// Interface that defines the Kesterl settings to read from the XML config file
    /// </summary>
    public interface IKestrelSettings
    {
        /// <summary>
        /// The Port to use when accessing the REST end pointgs
        /// </summary>
        public int RESTAPIPort { get; }

        /// <summary>
        /// Whether to use SSL or not
        /// </summary>
        public bool UseCertificateForSSL { get; }

        /// <summary>
        /// The subject name of the SSL certificate that is stored in the Certificate store of the server. e.g. localhost
        /// </summary>
        public string CertificateSubject { get; }

        /// <summary>
        /// The name of the certificate store. e.g. LocalMachine
        /// </summary>
        public string CertificateStoreName { get; }

        /// <summary>
        /// The location in the certificate store to retrive the certificate with the subject name from. e.g. MY
        /// </summary>
        public string CertificateLocation { get; }

        /// <summary>
        /// Whetgher to allow invalid certificates
        /// </summary>
        public bool CertificateAllowInvalid { get; }
    }
}
