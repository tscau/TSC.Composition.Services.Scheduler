﻿using System.Configuration;

namespace DCS.Composition.Services.DataRetrieve.Config
{
    /// <summary>
    /// Class that defines the Kesterl settings to read from the XML config file
    /// </summary>
    public class KestrelSettings : IKestrelSettings
    {
        /// <summary>
        /// The Port to use when accessing the REST end pointgs
        /// </summary>
        public int RESTAPIPort
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("RESTAPIPort"), out int port);
                return port;
            }
        }

        /// <summary>
        /// Whether to use SSL or not. WIll default to false if not present
        /// </summary>
        public bool UseCertificateForSSL
        {
            get
            {
                bool.TryParse(ConfigurationManager.AppSettings.Get("UseCertificateForSSL"), out bool useSSL);
                return useSSL;
            }
        }

        /// <summary>
        /// The subject name of the SSL certificate that is stored in the Certificate store of the server. e.g. localhost
        /// </summary>
        public string CertificateSubject
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CertificateSubject");
            }
        }

        /// <summary>
        /// The name of the certificate store. e.g. LocalMachine
        /// </summary>
        public string CertificateStoreName
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CertificateStoreName");
            }
        }

        /// <summary>
        /// The location in the certificate store to retrive the certificate with the subject name from. e.g. MY
        /// </summary>
        public string CertificateLocation
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("CertificateLocation");
            }
        }

        /// <summary>
        /// Whetgher to allow invalid certificates
        /// </summary>
        public bool CertificateAllowInvalid
        {
            get
            {
                bool.TryParse(ConfigurationManager.AppSettings.Get("CertificateAllowInvalid"), out bool allowInvalid);
                return allowInvalid;
            }
        }
    }
}
