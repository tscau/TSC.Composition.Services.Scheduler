﻿namespace DCS.Composition.Services.DataRetrieve.Config
{
    /// <summary>
    /// Interface that defines what connections trings are int eh config file
    /// </summary>
    public interface IConnectionStrings
    {
        /// <summary>
        /// COnnection string to use when accessing the Outbound database
        /// </summary>
        public string OutboundCorroGen { get; }

        /// <summary>
        /// Connection string to use when accessing the HangFire database
        /// </summary>
        public string HangfireDb { get; }
    }
}
