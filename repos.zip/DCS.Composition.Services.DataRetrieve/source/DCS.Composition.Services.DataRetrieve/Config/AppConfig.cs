﻿namespace DCS.Composition.Services.DataRetrieve.Config
{
    /// <summary>
    /// Class to hold the AppConfig data for the application
    /// </summary>
    public class AppConfig : IAppConfig
    {

        /// <summary>
        /// Public constructor to initialise the object
        /// </summary>
        public AppConfig()
        {
            AppSettings = new AppSettings();
            Logging = new LoggingSettings();
            Kestrel = new KestrelSettings();
            ConnectionStrings = new ConnectionStrings();
        }

        /// <summary>
        /// Holds the AppSettings config
        /// </summary>
        public IAppSettings AppSettings { get; set; }

        /// <summary>
        /// Holds the Logging config data
        /// </summary>
        public ILoggingSettings Logging { get; set; }

        /// <summary>
        /// Holds the Kestrel config data
        /// </summary>
        public IKestrelSettings Kestrel { get; set; }

        /// <summary>
        /// Holds the conenctions tring information
        /// </summary>
        public IConnectionStrings ConnectionStrings { get; set; }
    }
}
