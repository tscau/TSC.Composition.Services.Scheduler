﻿using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Configuration;

namespace DCS.Composition.Services.DataRetrieve.Config
{
    /// <summary>
    /// Class that defines the Logging entries in the app.config file. Used for local log files as opposed to the service log file which
    /// uses the serilog entries
    /// </summary>
    public class LoggingSettings : ILoggingSettings
    {
        /// <summary>
        /// Name of the local log file to use. Will have appended using serilog rolling file appender
        /// </summary>
        public string LogFileName
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("LogFileName");
            }
        }

        /// <summary>
        /// Folder relative to the job folder for writing batch logs
        /// </summary>
        public string RelativeJobLogFileLocation
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("RelativeJobLogFileLocation");
            }
        }

        /// <summary>
        /// The URL of the central DCS Log Service to write log entries to
        /// </summary>
        public string LogServiceUrl
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("LogServiceUrl");
            }
        }
    }
}
