﻿using System.Collections.Generic;

namespace DCS.Composition.Services.DataRetrieve.Config
{
    /// <summary>
    /// Interface that defines the general AppSettings configuration entries
    /// </summary>
    public interface IAppSettings
    {
        /// <summary>
        /// The environment we are currently in
        /// </summary>
        public string Environment { get; }

        /// <summary>
        /// How many records to batch up before flushing to disk for the driver and csv files
        /// </summary>
        public int FlushDataToFilesBatchSize { get; }

        /// <summary>
        /// The namespace to use for the customer tags. Usxed for XPath queries and writing the driver file
        /// </summary>
        public string CustomersNamespace { get; }

        /// <summary>
        /// TGhe full name and path to the templates.config file that contains teh nat/dins that will NOT have a customer tag around the entries
        /// </summary>
        public string TemplatesConfigPath { get; }

        /// <summary>
        /// TGhe default name of the driver file to create
        /// </summary>
        public string DriverFileName { get; }

        /// <summary>
        /// The default name of the csv file to create
        /// </summary>
        public string DataFileName { get; }

        /// <summary>
        /// How many Jangfire threads will be used to process HangFire requests. Defaults to 10 if no entrries
        /// </summary>
        public int HangfireWorkerCount { get; }

        /// <summary>
        /// The name of the user to record Batch History status updates
        /// </summary>
        public string UserToRecordAgainst { get; }

        /// <summary>
        /// The version of the application abd dependent assemblies
        /// </summary>
        public Dictionary<string, AssemblyVersionDetails> Versions { get; }


        /// <summary>
        /// What server we are runing on
        /// </summary>
        public string Server { get; }
    }
}
