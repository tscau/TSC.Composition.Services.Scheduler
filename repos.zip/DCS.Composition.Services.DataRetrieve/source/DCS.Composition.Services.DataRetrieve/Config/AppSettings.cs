﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Reflection;

namespace DCS.Composition.Services.DataRetrieve.Config
{
    /// <summary>
    /// Class to hold the AppSettings config data
    /// </summary>
    public class AppSettings : IAppSettings
    {
        private const int DEFAULT_FLUSHDATABATCHSIZE = 1000;

        /// <summary>
        /// The number of records to write before forcing a flush to disk. If an invalid entry is found in the config file then it will default to 1000
        /// </summary>
        public int FlushDataToFilesBatchSize
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("FlushDataToFilesBatchSize"), out int flushDataToFilesBatchSize);
                if (flushDataToFilesBatchSize == 0)
                {
                    flushDataToFilesBatchSize = DEFAULT_FLUSHDATABATCHSIZE;
                }

                return flushDataToFilesBatchSize;
            }
        }

        /// <summary>
        /// The CustomerNamespace to use for the newer driver files
        /// </summary>
        public string CustomersNamespace => ConfigurationManager.AppSettings.Get("CustomersNamespace");

        /// <summary>
        /// Location of the tempaltes.config file. The Nat/Dins specified in this file will NOT have a Customers tag around the final driver XML
        /// </summary>
        public string TemplatesConfigPath => ConfigurationManager.AppSettings.Get("TemplatesConfigPath");

        /// <summary>
        /// The NameSpace to use when using XPath queries against the cXML
        /// </summary>
        public string ATOCanonicalNamespace {
          get
            {
                string temp = ConfigurationManager.AppSettings.Get("ATOCanonicalNamespace");
                if (string.IsNullOrWhiteSpace(temp))
                {
                    temp = "http://www.ato.gov.au/Subjects/EAI/2005/09/ATOCanonical";
                }

                return temp;
            }
        } 

        /// <summary>
        /// Base name for the driver
        /// </summary>
        public string DriverFileName => ConfigurationManager.AppSettings.Get("DriverFileName");

        /// <summary>
        /// The name of the file that will hyold the data.csv data
        /// </summary>
        public string DataFileName
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("DataFileName");
            }
        }

        /// <summary>
        /// the current environment
        /// </summary>
        public string Environment
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("Env");
            }
        }

        /// <summary>
        /// How many Hangfire Work Threads are to be used for processing data retriev requests. If an invalid entry is found in the config then a default of 10 is used
        /// </summary>
        public int HangfireWorkerCount
        {
            get
            {
                int.TryParse(ConfigurationManager.AppSettings.Get("HangfireWorkerCount"), out int hangfireWorkerCount);
                if (hangfireWorkerCount == 0)
                {
                    hangfireWorkerCount = 10;
                }

                return hangfireWorkerCount;
            }
        }

        /// <summary>
        /// The name of the user to record any updates against
        /// </summary>
        public string UserToRecordAgainst
        {
            get
            {
                return ConfigurationManager.AppSettings.Get("UserToRecordAgainst");
            }
        }

        /// <summary>
        /// Returns the version of the application
        /// </summary>
        public Dictionary<string, AssemblyVersionDetails> Versions {
            get 
            {
                Dictionary<string, AssemblyVersionDetails> versions = new Dictionary<string, AssemblyVersionDetails>();
                AssemblyVersionDetails details = new AssemblyVersionDetails();
                details.ReleaseBuild = Assembly.GetExecutingAssembly().GetName().Version.ToString();
                details.ReleaseVersion = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyFileVersionAttribute>().Version;
                details.BuildNumber = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion;
                details.ReleaseName = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyProductAttribute>().Product;
                versions.Add(Assembly.GetExecutingAssembly().GetName().Name, details);

                Assembly sharedAssembly = Assembly.Load("DCS.Composition.Services.Shared");
                details = new AssemblyVersionDetails();
                details.ReleaseBuild = sharedAssembly.GetName().Version.ToString();
                details.ReleaseVersion = sharedAssembly.GetCustomAttribute<AssemblyFileVersionAttribute>().Version;
                details.BuildNumber = sharedAssembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion;
                details.ReleaseName = sharedAssembly.GetCustomAttribute<AssemblyProductAttribute>().Product;
                versions.Add(sharedAssembly.GetName().Name, details);

                //add the shared assemblies as well
                sharedAssembly = Assembly.Load("DCS.Shared.DataAccess.Outbound");
                details = new AssemblyVersionDetails();
                details.ReleaseBuild = sharedAssembly.GetName().Version.ToString();
                details.ReleaseVersion = sharedAssembly.GetCustomAttribute<AssemblyFileVersionAttribute>().Version;
                details.BuildNumber = sharedAssembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>().InformationalVersion;
                details.ReleaseName = sharedAssembly.GetCustomAttribute<AssemblyProductAttribute>().Product;
                versions.Add(sharedAssembly.GetName().Name, details);
                return versions;
            }
        }

        /// <summary>
        /// Returns the name of the server that is currently executing the code
        /// </summary>
        public string Server => System.Environment.MachineName;

    }
}
