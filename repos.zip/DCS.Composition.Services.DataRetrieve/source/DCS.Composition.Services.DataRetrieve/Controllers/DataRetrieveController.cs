﻿using DCS.Composition.Services.DataRetrieve.Common;
using DCS.Composition.Services.DataRetrieve.Config;
using DCS.Composition.Services.Shared.Contracts;
using DCS.Composition.Services.Shared.DataRetrieve;
using DCS.Logging.Shared.Infrastructure;
using Hangfire;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Formatting.Compact;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Abstractions;

namespace DCS.Composition.Services.DataRetrieve.Controllers
{
    /// <summary>
    /// Controller to allow for low volume access to the service implementation
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class DataRetrieveController : ControllerBase
    {
        readonly IAppConfig _appConfig;
        readonly IPerBatchLogger _perBatchLogger;

        /// <summary>
        /// Default constructor for the REST end point. 
        /// </summary>
        /// <param name="appConfig"></param>
        /// <param name="perBatchLogger"></param>
        public DataRetrieveController(IPerBatchLogger perBatchLogger, IAppConfig appConfig)
        {
            _perBatchLogger = perBatchLogger;
            _appConfig = appConfig;
        }


        /// <summary>
        /// REST call to perform a data retrieve based on the input parameters. 
        /// </summary>
        /// <param name="message">The <seealso cref="CompositionMsg"></seealso>/> containing the message sent.</param>
        /// <returns></returns>
        [Route("CallDataRetrieveViaHangfire")]
        [HttpPost]
        public ActionResult<string> CallDataRetrieveViaHangfire(CompositionMsg message)
        {
            var jobId = BackgroundJob.Enqueue<IDataRetrieve>(x => x.Start(message, null));
            return "DataRetrieve message placed on Hangfire Queue. JobID: " + jobId;
        }

        /// <summary>
        /// REST call to perform a data retrieve based on the input parameters. 
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        [Route("CallDataRetrieve")]
        [HttpPost]
        public JsonResult CallDataRetrieve(CompositionMsg message)
        {
            try
            {
                if (!_perBatchLogger.LogFileCreated)
                {
                    _perBatchLogger.CreateForBatchId("per-batch:serilog:", "write-to:File.path", message.BatchId, message.JobPath, _appConfig.Logging.RelativeJobLogFileLocation, _appConfig.Logging.LogFileName);
                }

                //Load the templatesconfig file
                List<string> cachedTemplatesConfig = new List<string>();
                using (StreamReader reader = new StreamReader(_appConfig.AppSettings.TemplatesConfigPath))
                {
                    while (reader.Peek() >= 0)
                    {
                        string strNatCd = reader.ReadLine().Trim();
                        cachedTemplatesConfig.Add(strNatCd);

                    }
                }

                //If any Nat/Cds to be processed are in the templates.config file then they follow the old driver way
                bool wrapDriverWithCustomerTag = true;
                foreach (string natCd in message.NatDins)
                {
                    if (cachedTemplatesConfig.Contains(natCd))
                    {
                        wrapDriverWithCustomerTag = false;
                    }
                }

                IFileSystem _fileSystem = new FileSystem();

                Common.DataRetrieve dr = new Common.DataRetrieve(_perBatchLogger, _fileSystem, null, _appConfig);
                ExecuteDataRetrieveResult result = dr.ExecuteDataRetrieve(message, wrapDriverWithCustomerTag);

                return new JsonResult(result);
            }
            catch 
            {
                throw;
            }
            finally
            {
                if (_perBatchLogger != null)
                {
                    _perBatchLogger.Dispose();
                }
            }
        }

        /// <summary>
        /// Method to get the current config entries for the application. Returns as a string.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetCurrentConfig")]
        public JsonResult GetCurrentConfig()
        {
            return new JsonResult(_appConfig);
        }

        /// <summary>
        /// REST end point to get the version of the application and any shared components that make sense to report on
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("VersionInfo")]
        public JsonResult VersionInfo()
        {
            return new JsonResult(_appConfig.AppSettings.Versions);
        }
    }
}
