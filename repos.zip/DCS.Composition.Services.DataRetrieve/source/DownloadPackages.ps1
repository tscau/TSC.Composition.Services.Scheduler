#First run dotnet list <sln name> package --include-transitive ? PackageFiles.txt
# Edit this file so taht only the packages remain . e.g. hangfire.sqlserver.1.7.11.nupkg
$packages = Get-Content C:\repos\ATO_2020-08-29\DCS.Composition.DataRetrieve\source\NuGetDependancies_Cleaned.txt
$client = new-object System.Net.WebClient
foreach ($line in $packages) {
    $url = "https://globalcdn.nuget.org/packages/" + $line
    $folder = "C:\\repos\\Packages\\PackagesForDataRetrieve\\" + $line
    Write-Host "Downloading " $url " - to " $folder
    $client.DownloadFile($url,$folder)
}